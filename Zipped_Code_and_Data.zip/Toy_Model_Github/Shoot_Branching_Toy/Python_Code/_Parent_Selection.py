#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import sys # Imported to read input from command line.
import numpy as np
import os
import time
import netCDF4 as nc

from G2P_Equations import cytokinin_eq
from G2P_Equations import strigonlactone_eq
from G2P_Equations import signal_integrator_eq
from G2P_Equations import bud_outgrowth_time_eq

from G2P_Model_Cases import Bertheloot_coeffs


import tensorflow as tf
tf.keras.backend.set_floatx('float64')

from G2PNet_Architecture import sucrose_activation
from G2PNet_Architecture import auxin_activation
from G2PNet_Architecture import ick_activation
from G2PNet_Architecture import isl_activation
from G2PNet_Architecture import cka_activation
from G2PNet_Architecture import is_activation




def UQ_Parent_Selection(genomes,T_mean,T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model):
    
    Phi0 = 0.10
    Tcond  = np.zeros((Ng,Ngt),dtype=float)
    Tcond2 = np.zeros((Ng,Ngt,Ngt),dtype=float)
    Tcond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    Tcond4 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    std_cond = np.zeros((Ng,Ngt),dtype=float)
    Ncond = np.zeros((Ng,Ngt),dtype=int)
    Ncond2 = np.zeros((Ng,Ngt,Ngt),dtype=int)
    Ncond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=int)
    Ncond4 = np.zeros((Ng,Ngt,Ngt,Ngt,Ngt),dtype=int)
    
    Np_fake = int(1000)
    genomes_fake = np.zeros(Ng,dtype=int)
    genes_per_coeff = int(10)
    coeffs_min = [0.0, 0.0, 0.0, 0.0]
    Ncoeffs = int(4)
    Ucoeffs_fake = np.zeros(2,dtype=float)
    
    #G_picks   = [[] for ii in range(0,max_nonlinearity)]
    #G_effects = [[] for ii in range(0,max_nonlinearity)]
    
    G2_picks = []
    G2_best  = []
    G3_picks = []
    G3_best  = []
    G4_picks = []
    counter2 = int(0)
    Phi_abs_prev = 0.0
    Phi_max_prev4 = []
    Phi_max_prev3 = []
    Phi_max_prev2 = []
    max_flags2 = []
    max_flags3 = []
    max_flags4 = []
    counter3 = int(0)
    counter4 = int(0)
    
    flag_output = np.zeros( (ensemble_size,Np,1),dtype=np.float64)
    flag_genome = np.zeros( (Np_fake,Ng),dtype=np.float64)
    genomes_flag = np.zeros( (Np_fake,Ng), dtype=int )
    
#    A_fake = np.zeros(Np,dtype=float)
#    S_fake = np.zeros(Np,dtype=float)
#    CK_fake = np.zeros(Np,dtype=float)
#    SL_fake = np.zeros(Np,dtype=float)
    T_fake = np.zeros(Np,dtype=float)
    
    
    #------------------------------------------------------------------
    #--------------- 2.ca Compute population mean ---------------------
    Tpop = 0.0 # Initialize population mean
    for pp in range(0,Np):
        Tpop += T_mean[pp]
    Tpop = Tpop/float(Np)
    
    std_pop = 0.0
    for pp in range(0,Np):
        std_pop += T_std[pp]
    std_pop = np.sqrt(std_pop/float(Np-1))
    
    #------------------------------------------------------------------
    #--------- 2.cb Compute conditional means & variances -------------
    repeats = int(1)
    Tcond[:,:] = 0.0
    std_cond[:,:] = 1.0
    Ncond[:,:] = int(0)
    not_chosen = [True for mm in range(0,Np)]
    max_idx = []
    Phimax_list = []
    
    best_alleles_list = np.zeros(Ng,dtype=int)
    best_alleles_coeff = np.zeros(Ng,dtype=float)
    plants_score = np.zeros(Np,dtype=float)
    for pp in range(0,Np):
        plants_score[pp] = Tpop-T_mean[pp]
        #plants_score[pp] = (T_mean[pp]-Tpop)/std_pop
    
    for gg in range(0,Ng):
        
        for ll1 in range(0,Ngt):
            for pp in range(0,Np_fake):
                for gg1 in range(0,Ng):
                    genomes_fake[gg1] = genomes[pp,gg1,cycles]
                genomes_fake[gg] = ll1
                genomes_flag[pp,:] = genomes_fake[:]
            
            if (model == "G2PNet"):
                flag_genome[:,:] = np.float64(genomes_flag)
                for nn in range(0,ensemble_size):
                    flag_output[nn,:,:] = models[nn].predict(flag_genome)
                T_fake[:] = 0.0
                for pp in range(0,Np_fake):
                    for nn in range(0,ensemble_size):
                        T_fake[pp] = T_fake[pp] +flag_output[nn,pp,0]/float(ensemble_size)
            else:
                for pp in range(0,Np_fake):
                    genomes_fake[:] = genomes_flag[pp,:]
                    A_fake = coeffs_min[0]
                    S_fake = coeffs_min[1]
                    for cc in range(0,Ncoeffs-2):
                        Ucoeffs_fake[cc] = coeffs_min[cc+2]
                    for gg2 in range(0,genes_per_coeff):
                        A_fake = A_fake +UU[genomes_fake[gg2],gg2]
                        S_fake = S_fake +UU[genomes_fake[gg2+genes_per_coeff],gg2+genes_per_coeff]
                        for kk in range(0,Ncoeffs-2):
                            Ucoeffs_fake[kk] = Ucoeffs_fake[kk] +UU[genomes_fake[gg2+(kk+2)*genes_per_coeff],gg2+(kk+2)*genes_per_coeff]
                    
                    if (max_nonlinearity > 0):
                        for nn in range(0,Nnonlin):
                            val_flag = 0.0
                            val_pos = 0
                            for pp2 in range(0,AAnonlinear[nn,0]):
                                val_pos += genomes_fake[GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                            val_flag = UUnonlinear[nn,val_pos]
                        
                            if (GGnonlinear[nn,0] < genes_per_coeff):
                                A_fake = A_fake +val_flag
                            elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                                S_fake = S_fake +val_flag
                            elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                                Ucoeffs_fake[0] = Ucoeffs_fake[0] +val_flag
                            else:
                                Ucoeffs_fake[1] = Ucoeffs_fake[1] +val_flag
                    ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs_fake[:],"case2","Ref")
                    CK_fake = cytokinin_eq(A_fake,S_fake,ck_input)
                    SL_fake = strigonlactone_eq(A_fake,S_fake,sl_input)
                    I_fake  = signal_integrator_eq(A_fake,S_fake,CK_fake,SL_fake,signal_input)
                    T_fake[pp]  = bud_outgrowth_time_eq(I_fake)+(aleatoric_noise+0.5)*np.random.randn(1)
            for pp in range(0,Np_fake):
                genomes_fake[:] = genomes_flag[pp,:]
                if (genomes_fake[gg] == ll1):
                    Tcond[gg,ll1] = Tcond[gg,ll1] +T_fake[pp]
                    Ncond[gg,ll1] = Ncond[gg,ll1] +int(1)
                    if (gg < Ng-1):
                        Tcond2[gg,ll1,genomes_fake[gg+1]] = Tcond2[gg,ll1,genomes_fake[gg+1]] +T_fake[pp]
                        Ncond2[gg,ll1,genomes_fake[gg+1]] = Ncond2[gg,ll1,genomes_fake[gg+1]] +int(1)
            if (Ncond[gg,ll1] > 0):
                Tcond[gg,ll1] = Tcond[gg,ll1]/float(Ncond[gg,ll1])
            
        Phi_max = -100000.0
        Phi_abs =  -100000.0
        max_flag = -2
        for ll in range(0,Ngt):
            if (Phi_max < (Tpop-Tcond[gg,ll]) and Ncond[gg,ll] > 0 ):
                Phi_max = (Tpop-Tcond[gg,ll])
                max_flag = ll
            if (Phi_abs < np.abs(Tpop-Tcond[gg,ll]) and Ncond[gg,ll] > 0 ):
                Phi_abs = np.abs(Tpop-Tcond[gg,ll])
                    
        
        for pp in range(0,Np):
            if (genomes[pp,gg,cycles] == max_flag and Ncond[gg,max_flag] > 0 and Phi_max > 0.05 ):
                plants_score[pp] = plants_score[pp] +Phi_max
    
    
    
    # Locate potential dyads
#    for gg in range(0,Ng-1):
#        
#        Phi_max = -10000.0
#        Phi_abs = -10000.0
#        max_flag1 = -2
#        max_flag2 = -2
#        for ll1 in range(0,Ngt):
#            for ll2 in range(0,Ngt):
#                
#                if (Ncond2[gg,ll1,ll2] > 0):
#                    Tcond2[gg,ll1,ll2] = Tcond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2])
#                
#                flag_val = (Tpop-Tcond2[gg,ll1,ll2]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2])
#                if (Phi_abs < np.abs(flag_val) and Ncond2[gg,ll1,ll2] > 0):
#                    Phi_abs = np.abs(flag_val)
#                if (Phi_max < (Tpop-Tcond2[gg,ll1,ll2]) and Ncond2[gg,ll1,ll2] > 0):
#                    Phi_max = (Tpop-Tcond2[gg,ll1,ll2])
#                    max_flag1 = ll1
#                    max_flag2 = ll2
#        
#        if (Phi_abs > 0.50):
#            G2_picks.append(gg)
#            
#            if (counter2 > 0 and G2_picks[-1] == gg-1):
#                if (Phi_max_prev2[-1] < Phi_abs):
#                    G2_picks[-1] = gg
#                    Phi_max_prev2[-1] = Phi_abs
#                    max_flags2[-1][:] = [max_flag1,max_flag2]
#            else:
#                G2_picks.append(gg)
#                Phi_max_prev2.append(Phi_abs)
#                max_flags2.append([max_flag1,max_flag2])
#                counter2 = counter2+1
            
            
    
            
                
    
    
    
    # Locate potential triads
#    for gg in range(0,Ng-2):
#        if ( (gg in G2_picks) ):
#        #if (np.max(UU[:,gg]) < 0.0001 and np.max(UU[:,gg+1]) < 0.0001 and np.max(UU[:,gg+2]) < 0.0001 ):
#            for ll1 in range(0,Ngt):
#                for ll2 in range(0,Ngt):
#                    for ll3 in range(0,Ngt):
#                    
#                        for pp in range(0,Np_fake):
#                            for gg1 in range(0,Ng):
#                                genomes_fake[gg1] = genomes[pp,gg1,cycles]
#                            genomes_fake[gg] = ll1
#                            genomes_fake[gg+1] = ll2
#                            genomes_fake[gg+2] = ll3
#                            genomes_flag[pp,:] = genomes_fake[:]
#                        
#                        if (model == "G2PNet"):
#                            flag_genome[:,:] = np.float64(genomes_flag)
#                            for nn in range(0,ensemble_size):
#                                flag_output[nn,:,:] = models[nn].predict(flag_genome)
#                            T_fake[:] = 0.0
#                            for pp in range(0,Np_fake):
#                                for nn in range(0,ensemble_size):
#                                    T_fake[pp] = T_fake[pp] +flag_output[nn,pp,0]/float(ensemble_size)
#                            
#                        else:
#                            for pp in range(0,Np_fake):
#                                genomes_fake[:] = genomes_flag[pp,:]
#                                A_fake = coeffs_min[0]
#                                S_fake = coeffs_min[1]
#                                for cc in range(0,Ncoeffs-2):
#                                    Ucoeffs_fake[cc] = coeffs_min[cc+2]
#                                for gg2 in range(0,genes_per_coeff):
#                                    A_fake = A_fake +UU[genomes_fake[gg2],gg2]
#                                    S_fake = S_fake +UU[genomes_fake[gg2+genes_per_coeff],gg2+genes_per_coeff]
#                                    for kk in range(0,Ncoeffs-2):
#                                        Ucoeffs_fake[kk] = Ucoeffs_fake[kk] +UU[genomes_fake[gg2+(kk+2)*genes_per_coeff],gg2+(kk+2)*genes_per_coeff]
#                                
#                                if (max_nonlinearity > 0):
#                                    for nn in range(0,Nnonlin):
#                                        val_flag = 0.0
#                                        val_pos = 0
#                                        for pp2 in range(0,AAnonlinear[nn,0]):
#                                            val_pos += genomes_fake[GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
#                                        val_flag = UUnonlinear[nn,val_pos]
#                        
#                                        if (GGnonlinear[nn,0] < genes_per_coeff):
#                                            A_fake = A_fake +val_flag
#                                        elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
#                                            S_fake = S_fake +val_flag
#                                        elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
#                                            Ucoeffs_fake[0] = Ucoeffs_fake[0] +val_flag
#                                        else:
#                                            Ucoeffs_fake[1] = Ucoeffs_fake[1] +val_flag
#                                ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs_fake[:],"case2","Ref")
#                                CK_fake = cytokinin_eq(A_fake,S_fake,ck_input)
#                                SL_fake = strigonlactone_eq(A_fake,S_fake,sl_input)
#                                I_fake  = signal_integrator_eq(A_fake,S_fake,CK_fake,SL_fake,signal_input)
#                                T_fake[pp]  = bud_outgrowth_time_eq(I_fake)+(aleatoric_noise+0.5)**np.random.randn(1)
#                            
#                        for pp in range(0,Np_fake):
#                            genomes_fake[:] = genomes_flag[pp,:]
#                            if (genomes_fake[gg] == ll1 and genomes_fake[gg+1] == ll2 and genomes_fake[gg+2] == ll3):
#                                Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3] +T_fake[pp]
#                                Ncond3[gg,ll1,ll2,ll3] = Ncond3[gg,ll1,ll2,ll3] +int(1)
#                        if (Ncond3[gg,ll1,ll2,ll3] > 0):
#                            Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
#            Phi_max = -1000.0
#            Phi_abs = -1000.0
#            max_flag1 = -2
#            max_flag2 = -2
#            max_flag3 = -2
#            for ll1 in range(0,Ngt):
#                for ll2 in range(0,Ngt):
#                    for ll3 in range(0,Ngt):
#                        if (Phi_max < (Tpop-Tcond3[gg,ll1,ll2,ll3]) and Ncond3[gg,ll1,ll2,ll3] > 0):
#                            Phi_max = Tpop-Tcond3[gg,ll1,ll2,ll3]
#                            max_flag1 = ll1
#                            max_flag2 = ll2
#                            max_flag3 = ll3
#                        flag_val = (Tpop-Tcond3[gg,ll1,ll2,ll3]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]) -(Tpop-Tcond[gg+2,ll3])
#                        if (Phi_abs < np.abs(flag_val) and Ncond3[gg,ll1,ll2,ll3] > 0):
#                            Phi_abs = np.abs(flag_val)
#                            
#            
#            
#            if (counter3 > 0 and (G3_picks[-1] == gg-1 or G3_picks[-1] == gg-2)):
#                if (Phi_max_prev3[-1] < Phi_abs):
#                    G3_picks[-1] = gg
#                    Phi_max_prev3[-1] = Phi_abs
#                    max_flags3[-1][:] = [max_flag1,max_flag2,max_flag3]
#            else:
#                G3_picks.append(gg)
#                Phi_max_prev3.append(Phi_abs)
#                max_flags3.append([max_flag1,max_flag2,max_flag3])
#                counter3 = counter3+1
            
        

    
    
    
    
    
    
#    counter = int(0)
#    for ii in range(0,counter2):
#        if (G2_picks[ii] in G3_picks or G2_picks[ii]+1 in G3_picks or G2_picks[ii]-1 in G3_picks ):
#            G2_picks[ii] = -1
#    
#      
#    
#    counter = int(0)
#    for nn in range(0,counter2):
#        if (G2_picks[nn] >  -1):
#            gg = G2_picks[nn]
#            for pp in range(0,Np):
#                if (genomes[pp,gg,cycles] == max_flags2[nn][0] and genomes[pp,gg+1,cycles] == max_flags2[nn][1]):
#                    plants_score[pp] = plants_score[pp] +10.0*(Tpop-Tcond2[gg,max_flags2[nn][0],max_flags2[nn][1]])
#    
#    
#
#    
#    counter = int(0)
#    for gg in G3_picks:
#        for pp in range(0,Np):
#            if (genomes[pp,gg,cycles] == max_flags3[counter][0] and genomes[pp,gg+1,cycles] == max_flags3[counter][1] and genomes[pp,gg+2,cycles] == max_flags3[counter][2]):
#                plants_score[pp] = plants_score[pp] +10.0*(Tpop-Tcond3[gg,max_flags3[counter][0],max_flags3[counter][1],max_flags3[counter][2]])
#        counter = counter+1
    

    
    
    
    max_idx = np.argsort(-plants_score)[:]
    
    return max_idx




















def UQ_Parent_Selection_Ref(genomes,T_mean,T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model):
    
    Phi0 = 0.0
    Tcond  = np.zeros((Ng,Ngt),dtype=float)
    Tcond2 = np.zeros((Ng,Ngt,Ngt),dtype=float)
    Tcond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    Tcond4 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    std_cond = np.zeros((Ng,Ngt),dtype=float)
    std_cond2 = np.zeros((Ng,Ngt,Ngt),dtype=float)
    std_cond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    Ncond = np.zeros((Ng,Ngt),dtype=int)
    Ncond2 = np.zeros((Ng,Ngt,Ngt),dtype=int)
    Ncond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=int)
    Ncond4 = np.zeros((Ng,Ngt,Ngt,Ngt,Ngt),dtype=int)
    
    Np_fake = Np//5
    genomes_fake = np.zeros(Ng,dtype=int)
    genes_per_coeff = int(10)
    coeffs_min = [0.0, 0.0, 0.0, 0.0]
    Ncoeffs = int(4)
    Ucoeffs_fake = np.zeros(2,dtype=float)
    
    #G_picks   = [[] for ii in range(0,max_nonlinearity)]
    #G_effects = [[] for ii in range(0,max_nonlinearity)]
    
    G2_picks = []
    G2_best  = []
    G3_picks = []
    G3_best  = []
    G4_picks = []
    counter2 = int(0)
    Phi_abs_prev = 0.0
    Phi_max_prev4 = []
    Phi_max_prev3 = []
    Phi_max_prev2 = []
    max_flags2 = []
    max_flags3 = []
    max_flags4 = []
    counter3 = int(0)
    counter4 = int(0)
    
    flag_output = np.zeros( (ensemble_size,Np,1),dtype=np.float64)
    flag_genome = np.zeros( (Np_fake,Ng),dtype=np.float64)
    genomes_flag = np.zeros( (Np_fake,Ng), dtype=int )
    
#    A_fake = np.zeros(Np,dtype=float)
#    S_fake = np.zeros(Np,dtype=float)
#    CK_fake = np.zeros(Np,dtype=float)
#    SL_fake = np.zeros(Np,dtype=float)
    T_fake = np.zeros(Np,dtype=float)
    
    
    
    counter2 = int(0)
    counter3 = int(0)
    Phi0 = 0.0
    Phi2 = 0.0
    Phi3 = 0.50
    
    Gopt = np.zeros(Ng,dtype=int)
    Phiopt = np.zeros(Ng,dtype=float)
    
    
    fake_genomes = np.zeros( (Np_fake*Ng*Ngt,Ng),dtype=int)
    fake_genomes_real = np.zeros( (Np_fake*Ng*Ngt,Ng),dtype=np.float64)
    Tfake_preds = np.zeros( (ensemble_size,Np_fake*Ng*Ngt,1), dtype=float )
    #Tfake_mean = np.zeros(Np_fake*Ng*Ngt, dtype=float)
    #Tfake_std  = np.zeros(Np_fake*Ng*Ngt, dtype=float)
    
    G1_picks = []
    Phi_max1 = np.zeros(Ng,dtype=float)
    
    G2_picks = []
    max_flags2 = []
    Phi_max_prev2 = []
    
    
    G3_picks = []
    max_flags3 = []
    Phi_max_prev3 = []
    
    
    
    
    
    
    
    #------------------------------------------------------------------
    #--------------- 2.ca Compute population mean ---------------------
    Tpop = 0.0 # Initialize population mean
    for pp in range(0,Np):
        Tpop += T_mean[pp]
    Tpop = Tpop/float(Np)
    
    std_pop = 0.0
    for pp in range(0,Np):
        std_pop += T_std[pp]
    std_pop = np.sqrt(std_pop/float(Np-1))
    
    #------------------------------------------------------------------
    #--------- 2.cb Compute conditional means & variances -------------
    repeats = int(1)
    Tcond[:,:] = 0.0
    std_cond[:,:] = 1.0
    Ncond[:,:] = int(0)
    not_chosen = [True for mm in range(0,Np)]
    max_idx = []
    Phimax_list = []
    
    best_alleles_list = np.zeros(Ng,dtype=int)
    best_alleles_coeff = np.zeros(Ng,dtype=float)
    plants_score = np.zeros(Np,dtype=float)
    for pp in range(0,Np):
        plants_score[pp] = Tpop-T_mean[pp]
        #plants_score[pp] = (T_mean[pp]-Tpop)/std_pop
    
    for gg in range(0,Ng):
        for ll1 in range(0,Ngt):
            for pp in range(0,Np_fake):
                for gg1 in range(0,Ng):
                    genomes_fake[gg1] = genomes[pp,gg1,cycles]
                genomes_fake[gg] = ll1
                genomes_flag[pp,:] = genomes_fake[:]
                
                
            for pp in range(0,Np_fake):
                genomes_fake[:] = genomes_flag[pp,:]
                A_fake = coeffs_min[0]
                S_fake = coeffs_min[1]
                for cc in range(0,Ncoeffs-2):
                    Ucoeffs_fake[cc] = coeffs_min[cc+2]
                for gg2 in range(0,genes_per_coeff):
                    A_fake = A_fake +UU[genomes_fake[gg2],gg2]
                    S_fake = S_fake +UU[genomes_fake[gg2+genes_per_coeff],gg2+genes_per_coeff]
                    for kk in range(0,Ncoeffs-2):
                        Ucoeffs_fake[kk] = Ucoeffs_fake[kk] +UU[genomes_fake[gg2+(kk+2)*genes_per_coeff],gg2+(kk+2)*genes_per_coeff]
                
                if (max_nonlinearity > 0):
                    for nn in range(0,Nnonlin):
                        val_flag = 0.0
                        val_pos = 0
                        for pp2 in range(0,AAnonlinear[nn,0]):
                            val_pos += genomes_fake[GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                        val_flag = UUnonlinear[nn,val_pos]
                    
                        if (GGnonlinear[nn,0] < genes_per_coeff):
                            A_fake = A_fake +val_flag
                        elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                            S_fake = S_fake +val_flag
                        elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                            Ucoeffs_fake[0] = Ucoeffs_fake[0] +val_flag
                        else:
                            Ucoeffs_fake[1] = Ucoeffs_fake[1] +val_flag
                ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs_fake[:],"case8","Ref")
                CK_fake = cytokinin_eq(A_fake,S_fake,ck_input)
                SL_fake = strigonlactone_eq(A_fake,S_fake,sl_input)
                I_fake  = signal_integrator_eq(A_fake,S_fake,CK_fake,SL_fake,signal_input)
                T_fake[pp]  = bud_outgrowth_time_eq(I_fake)+(aleatoric_noise)*np.random.randn(1)
            for pp in range(0,Np_fake):
                genomes_fake[:] = genomes_flag[pp,:]
                if (genomes_fake[gg] == ll1):
                    Tcond[gg,ll1] = Tcond[gg,ll1] +T_fake[pp]
                    Ncond[gg,ll1] = Ncond[gg,ll1] +int(1)
                    if (gg < Ng-1):
                        Tcond2[gg,ll1,genomes_fake[gg+1]] = Tcond2[gg,ll1,genomes_fake[gg+1]] +T_fake[pp]
                        Ncond2[gg,ll1,genomes_fake[gg+1]] = Ncond2[gg,ll1,genomes_fake[gg+1]] +int(1)
            if (Ncond[gg,ll1] > 0):
                Tcond[gg,ll1] = Tcond[gg,ll1]/float(Ncond[gg,ll1])
            
        Phi_max = -100000.0
        Phi_abs =  -100000.0
        max_flag = -2
        for ll in range(0,Ngt):
            if (Phi_max < (Tpop-Tcond[gg,ll]) and Ncond[gg,ll] > 0 ):
                Phi_max = (Tpop-Tcond[gg,ll])
                max_flag = ll
            if (Phi_abs < np.abs(Tpop-Tcond[gg,ll]) and Ncond[gg,ll] > 0 ):
                Phi_abs = np.abs(Tpop-Tcond[gg,ll])
        if (max_flag > -1 and Phi_abs > Phi0):
            G1_picks.append(gg)
            Phi_max1[gg] = Phi_max
            Gopt[gg] = max_flag
            Phiopt[gg] = Phi_max
            
        # for pp in range(0,Np):
        #     if (genomes[pp,gg,cycles] == Gopt[gg]):
        #         plants_score[pp] = plants_score[pp] +Phiopt[gg]
                    
        
        # for pp in range(0,Np):
        #     if (genomes[pp,gg,cycles] == max_flag and Ncond[gg,max_flag] > 0 and Phi_max > 0.0 ):
        #         plants_score[pp] = plants_score[pp] +Phi_max
    
    
    
    
    
    
    
    for gg in range(0,Ng-2):
        Tpop_flag = 0.0
        Tcond_flag = np.zeros((Ng,Ngt),dtype=float)
        for ll1 in range(0,Ngt):
            for ll2 in range(0,Ngt):
                for ll3 in range(0,Ngt):
                    for pp in range(0,Np_fake):
                        for gg1 in range(0,Ng):
                            genomes_fake[gg1] = genomes[pp,gg1,cycles]
                        genomes_fake[gg] = ll1
                        genomes_fake[gg+1] = ll2
                        genomes_fake[gg+2] = ll3
                        genomes_flag[pp,:] = genomes_fake[:]
                        
                    for pp in range(0,Np_fake):
                        genomes_fake[:] = genomes_flag[pp,:]
                        A_fake = coeffs_min[0]
                        S_fake = coeffs_min[1]
                        for cc in range(0,Ncoeffs-2):
                            Ucoeffs_fake[cc] = coeffs_min[cc+2]
                        for gg2 in range(0,genes_per_coeff):
                            A_fake = A_fake +UU[genomes_fake[gg2],gg2]
                            S_fake = S_fake +UU[genomes_fake[gg2+genes_per_coeff],gg2+genes_per_coeff]
                            for kk in range(0,Ncoeffs-2):
                                Ucoeffs_fake[kk] = Ucoeffs_fake[kk] +UU[genomes_fake[gg2+(kk+2)*genes_per_coeff],gg2+(kk+2)*genes_per_coeff]
                        
                        if (max_nonlinearity > 0):
                            for nn in range(0,Nnonlin):
                                val_flag = 0.0
                                val_pos = 0
                                for pp2 in range(0,AAnonlinear[nn,0]):
                                    val_pos += genomes_fake[GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                                val_flag = UUnonlinear[nn,val_pos]
                
                                if (GGnonlinear[nn,0] < genes_per_coeff):
                                    A_fake = A_fake +val_flag
                                elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                                    S_fake = S_fake +val_flag
                                elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                                    Ucoeffs_fake[0] = Ucoeffs_fake[0] +val_flag
                                else:
                                    Ucoeffs_fake[1] = Ucoeffs_fake[1] +val_flag
                        ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs_fake[:],"case2","Ref")
                        CK_fake = cytokinin_eq(A_fake,S_fake,ck_input)
                        SL_fake = strigonlactone_eq(A_fake,S_fake,sl_input)
                        I_fake  = signal_integrator_eq(A_fake,S_fake,CK_fake,SL_fake,signal_input)
                        T_fake[pp]  = bud_outgrowth_time_eq(I_fake)+(aleatoric_noise)*np.random.randn(1)
    
                    for pp in range(0,Np_fake):
                        genomes_fake[:] = genomes_flag[pp,:]
                        if (genomes_fake[gg] == ll1 and genomes_fake[gg+1] == ll2 and genomes_fake[gg+2] == ll3):
                            Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3] +T_fake[pp]
                            Ncond3[gg,ll1,ll2,ll3] = Ncond3[gg,ll1,ll2,ll3] +int(1)
                    if (Ncond3[gg,ll1,ll2,ll3] > 0):
                        Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
                    Tpop_flag += np.sum(T_fake[:])/float(Np_fake*Ngt*Ngt*Ngt)
                    Tcond_flag[gg,ll1]   += np.sum(T_fake[:])/float(Np_fake*Ngt*Ngt)
                    Tcond_flag[gg+1,ll2] += np.sum(T_fake[:])/float(Np_fake*Ngt*Ngt)
                    Tcond_flag[gg+2,ll3] += np.sum(T_fake[:])/float(Np_fake*Ngt*Ngt)
                        
        Phi_max = -1000.0
        Phi_abs = -1000.0
        max_flag1 = -2
        max_flag2 = -2
        max_flag3 = -2
        for ll1 in range(0,Ngt):
            for ll2 in range(0,Ngt):
                for ll3 in range(0,Ngt):
                    if (Phi_max < (Tpop_flag-Tcond3[gg,ll1,ll2,ll3]) and Ncond3[gg,ll1,ll2,ll3] > 0):
                        Phi_max = Tpop_flag-Tcond3[gg,ll1,ll2,ll3]
                        max_flag1 = ll1
                        max_flag2 = ll2
                        max_flag3 = ll3
                    flag_val = (Tpop_flag-Tcond3[gg,ll1,ll2,ll3]) -(Tpop_flag-Tcond_flag[gg,ll1]) -(Tpop_flag-Tcond_flag[gg+1,ll2]) -(Tpop_flag-Tcond_flag[gg+2,ll3])
                    if (Phi_abs < np.abs(flag_val) and Ncond3[gg,ll1,ll2,ll3] > 0):
                        Phi_abs = np.abs(flag_val)
                        
        if (counter3 > 0 and G3_picks[counter3-1] == gg-1 and Phi_abs > Phi3):
            if (Phi_max_prev3[counter3-1] < Phi_max):
                G3_picks[counter3-1] = gg
                Phi_max_prev3[counter3-1] = Phi_max
                max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
        if (counter3 > 0 and G3_picks[counter3-1] == gg-2 and Phi_abs > Phi3):
            if (Phi_max_prev3[counter3-1] < Phi_max ):
                G3_picks[counter3-1] = gg
                Phi_max_prev3[counter3-1] = Phi_max
                max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
        elif (Phi_abs > Phi3):
            G3_picks.append(gg)
            Phi_max_prev3.append(Phi_max)
            max_flags3.append([max_flag1,max_flag2,max_flag3])
            counter3 = counter3+1
    
    
    counter = int(0)
    for gg in G3_picks:
        for pp in range(0,Np):
            if (genomes[pp,gg,cycles] == max_flags3[counter][0] and genomes[pp,gg+1,cycles] == max_flags3[counter][1] and genomes[pp,gg+2,cycles] == max_flags3[counter][2]):
                plants_score[pp] = plants_score[pp] +2.0
        counter = counter+1
    
    
    # for gg in range(0,Ng):
    #     if (np.max(UU[:,gg]) < 0.0001 and np.max(UUall[:,gg]) > 0.0001):
    #         for pp in range(0,Np):
    #             if (   UUall[genomes[pp,gg,cycles],gg] > 0.0001 and gg >  0 and gg < 10 ):
    #                 plants_score[pp] = plants_score[pp] +5.0
    #             elif ( UUall[genomes[pp,gg,cycles],gg] < 0.0001 and gg >  9 and gg < 20 ):
    #                 plants_score[pp] = plants_score[pp] +1.0
    #             elif ( UUall[genomes[pp,gg,cycles],gg] < 0.0001 and gg > 19 and gg < 30 ):
    #                 plants_score[pp] = plants_score[pp] +1.0
    #             elif ( UUall[genomes[pp,gg,cycles],gg] > 0.0001 and gg > 29 and gg < 40 ):
    #                 plants_score[pp] = plants_score[pp] +1.0
    
    # for gg in range(0,Ng):
    #     for pp in range(0,Np):
    #         if (   np.max(UU[:,gg]) < 0.0001 and np.max(UUall[:,gg]) < 0.0001 and UUall[genomes[pp,gg,cycles],gg] > 0.0001 and gg >  0 and gg < 10 ):
    #             plants_score[pp] = plants_score[pp] +1.0
    #         elif ( np.max(UU[:,gg]) < 0.0001 and np.max(UUall[:,gg]) < 0.0001 and UUall[genomes[pp,gg,cycles],gg] < 0.0001 and gg >  9 and gg < 20 ):
    #             plants_score[pp] = plants_score[pp] +1.0
    #         elif ( np.max(UU[:,gg]) < 0.0001 and np.max(UUall[:,gg]) < 0.0001 and UUall[genomes[pp,gg,cycles],gg] < 0.0001 and gg > 19 and gg < 30 ):
    #             plants_score[pp] = plants_score[pp] +1.0
    #         elif ( np.max(UU[:,gg]) < 0.0001 and np.max(UUall[:,gg]) < 0.0001 and UUall[genomes[pp,gg,cycles],gg] > 0.0001 and gg > 29 and gg < 40 ):
    #             plants_score[pp] = plants_score[pp] +1.0
                    
                    
                    
    
    
    
    #--------------------------------------------------------------------------
    #--------------------------- Look for Dyads -------------------------------
    # counter = int(0) # Count the number of possible dyads
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks):
    #         counter += int(1)
    
    
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks and gg < Ng-1):
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 if (Ncond2[gg,ll1,ll2] > 0):
    #                     Tcond2[gg,ll1,ll2] = Tcond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2])
    #                     std_cond2[gg,ll1,ll2] = np.sqrt(std_cond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2]))
    #                 else:
    #                     Tcond2[gg,ll1,ll2] = Tpop
    #                     std_cond2[gg,ll1,ll2] = std_pop
            
    #         Phi_max = -100.0
    #         Phi_abs = -100.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 flag_val = np.abs((Tpop-Tcond2[gg,ll1,ll2]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]))/std_cond2[gg,ll1,ll2]
    #                 if (Phi_abs < flag_val ):
    #                     Phi_abs = np.abs(flag_val)
    #                 if (Phi_max < (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2] ):
    #                     Phi_max = (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2]
    #                     max_flag1 = ll1
    #                     max_flag2 = ll2

    #         if (counter2 > 0 and G2_picks[counter2-1] == gg-1 and Phi_abs > Phi2):
    #             if (Phi_max_prev2[counter2-1] < Phi_max):
    #                 G2_picks[counter2-1] = gg
    #                 Phi_max_prev2[counter2-1] = Phi_max
    #                 max_flags2[counter2-1][:] = [max_flag1,max_flag2]
    #         elif (Phi_abs > Phi2):
    #             G2_picks.append(gg)
    #             Phi_max_prev2.append(Phi_max)
    #             max_flags2.append([max_flag1,max_flag2])
    #             counter2 = counter2+1
    
    
    
    
    
    
    
    
    
    
    
    
    
    # # Locate potential dyads
    # for gg in range(0,Ng-1):
        
    #     Phi_max = -10000.0
    #     Phi_abs = -10000.0
    #     max_flag1 = -2
    #     max_flag2 = -2
    #     for ll1 in range(0,Ngt):
    #         for ll2 in range(0,Ngt):
                
    #             if (Ncond2[gg,ll1,ll2] > 0):
    #                 Tcond2[gg,ll1,ll2] = Tcond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2])
                
    #             flag_val = (Tpop-Tcond2[gg,ll1,ll2]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2])
    #             if (Phi_abs < np.abs(flag_val) and Ncond2[gg,ll1,ll2] > 0):
    #                 Phi_abs = np.abs(flag_val)
    #             if (Phi_max < (Tpop-Tcond2[gg,ll1,ll2]) and Ncond2[gg,ll1,ll2] > 0):
    #                 Phi_max = (Tpop-Tcond2[gg,ll1,ll2])
    #                 max_flag1 = ll1
    #                 max_flag2 = ll2
        
    #     if (Phi_abs > 0.10):
    #         G2_picks.append(gg)
            
    #         if (counter2 > 0 and G2_picks[-1] == gg-1):
    #             if (Phi_max_prev2[-1] < Phi_abs):
    #                 G2_picks[-1] = gg
    #                 Phi_max_prev2[-1] = Phi_abs
    #                 max_flags2[-1][:] = [max_flag1,max_flag2]
    #         else:
    #             G2_picks.append(gg)
    #             Phi_max_prev2.append(Phi_abs)
    #             max_flags2.append([max_flag1,max_flag2])
    #             counter2 = counter2+1
            
            
    
            
                
    
    
    
    #Locate potential triads
    # for gg in range(0,Ng-2):
    #     if ( (gg in G2_picks) ):
    #     #if (np.max(UU[:,gg]) < 0.0001 and np.max(UU[:,gg+1]) < 0.0001 and np.max(UU[:,gg+2]) < 0.0001 ):
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
                    
    #                     for pp in range(0,Np_fake):
    #                         for gg1 in range(0,Ng):
    #                             genomes_fake[gg1] = genomes[pp,gg1,cycles]
    #                         genomes_fake[gg] = ll1
    #                         genomes_fake[gg+1] = ll2
    #                         genomes_fake[gg+2] = ll3
    #                         genomes_flag[pp,:] = genomes_fake[:]
                        
    #                     if (model == "G2PNet"):
    #                         flag_genome[:,:] = np.float64(genomes_flag)
    #                         for nn in range(0,ensemble_size):
    #                             flag_output[nn,:,:] = models[nn].predict(flag_genome)
    #                         T_fake[:] = 0.0
    #                         for pp in range(0,Np_fake):
    #                             for nn in range(0,ensemble_size):
    #                                 T_fake[pp] = T_fake[pp] +flag_output[nn,pp,0]/float(ensemble_size)
                            
    #                     else:
    #                         for pp in range(0,Np_fake):
    #                             genomes_fake[:] = genomes_flag[pp,:]
    #                             A_fake = coeffs_min[0]
    #                             S_fake = coeffs_min[1]
    #                             for cc in range(0,Ncoeffs-2):
    #                                 Ucoeffs_fake[cc] = coeffs_min[cc+2]
    #                             for gg2 in range(0,genes_per_coeff):
    #                                 A_fake = A_fake +UU[genomes_fake[gg2],gg2]
    #                                 S_fake = S_fake +UU[genomes_fake[gg2+genes_per_coeff],gg2+genes_per_coeff]
    #                                 for kk in range(0,Ncoeffs-2):
    #                                     Ucoeffs_fake[kk] = Ucoeffs_fake[kk] +UU[genomes_fake[gg2+(kk+2)*genes_per_coeff],gg2+(kk+2)*genes_per_coeff]
                                
    #                             if (max_nonlinearity > 0):
    #                                 for nn in range(0,Nnonlin):
    #                                     val_flag = 0.0
    #                                     val_pos = 0
    #                                     for pp2 in range(0,AAnonlinear[nn,0]):
    #                                         val_pos += genomes_fake[GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
    #                                     val_flag = UUnonlinear[nn,val_pos]
                        
    #                                     if (GGnonlinear[nn,0] < genes_per_coeff):
    #                                         A_fake = A_fake +val_flag
    #                                     elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
    #                                         S_fake = S_fake +val_flag
    #                                     elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
    #                                         Ucoeffs_fake[0] = Ucoeffs_fake[0] +val_flag
    #                                     else:
    #                                         Ucoeffs_fake[1] = Ucoeffs_fake[1] +val_flag
    #                             ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs_fake[:],"case2","Ref")
    #                             CK_fake = cytokinin_eq(A_fake,S_fake,ck_input)
    #                             SL_fake = strigonlactone_eq(A_fake,S_fake,sl_input)
    #                             I_fake  = signal_integrator_eq(A_fake,S_fake,CK_fake,SL_fake,signal_input)
    #                             T_fake[pp]  = bud_outgrowth_time_eq(I_fake)+(aleatoric_noise+0.5)**np.random.randn(1)
                            
    #                     for pp in range(0,Np_fake):
    #                         genomes_fake[:] = genomes_flag[pp,:]
    #                         if (genomes_fake[gg] == ll1 and genomes_fake[gg+1] == ll2 and genomes_fake[gg+2] == ll3):
    #                             Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3] +T_fake[pp]
    #                             Ncond3[gg,ll1,ll2,ll3] = Ncond3[gg,ll1,ll2,ll3] +int(1)
    #                     if (Ncond3[gg,ll1,ll2,ll3] > 0):
    #                         Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
    #         Phi_max = -1000.0
    #         Phi_abs = -1000.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         max_flag3 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     if (Phi_max < (Tpop-Tcond3[gg,ll1,ll2,ll3]) and Ncond3[gg,ll1,ll2,ll3] > 0):
    #                         Phi_max = Tpop-Tcond3[gg,ll1,ll2,ll3]
    #                         max_flag1 = ll1
    #                         max_flag2 = ll2
    #                         max_flag3 = ll3
    #                     flag_val = (Tpop-Tcond3[gg,ll1,ll2,ll3]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]) -(Tpop-Tcond[gg+2,ll3])
    #                     if (Phi_abs < np.abs(flag_val) and Ncond3[gg,ll1,ll2,ll3] > 0):
    #                         Phi_abs = np.abs(flag_val)
                            
            
            
    #         if (counter3 > 0 and (G3_picks[-1] == gg-1 or G3_picks[-1] == gg-2)):
    #             if (Phi_max_prev3[-1] < Phi_abs):
    #                 G3_picks[-1] = gg
    #                 Phi_max_prev3[-1] = Phi_abs
    #                 max_flags3[-1][:] = [max_flag1,max_flag2,max_flag3]
    #         else:
    #             G3_picks.append(gg)
    #             Phi_max_prev3.append(Phi_abs)
    #             max_flags3.append([max_flag1,max_flag2,max_flag3])
    #             counter3 = counter3+1
            
        

    
    
    
    
    
    
    # counter = int(0)
    # for ii in range(0,counter2):
    #     if (G2_picks[ii] in G3_picks or G2_picks[ii]+1 in G3_picks or G2_picks[ii]-1 in G3_picks ):
    #         G2_picks[ii] = -1
    
      
    
    # counter = int(0)
    # for nn in range(0,counter2):
    #     if (G2_picks[nn] >  -1):
    #         gg = G2_picks[nn]
    #         for pp in range(0,Np):
    #             if (genomes[pp,gg,cycles] == max_flags2[nn][0] and genomes[pp,gg+1,cycles] == max_flags2[nn][1]):
    #                 plants_score[pp] = plants_score[pp] +10.0*(Tpop-Tcond2[gg,max_flags2[nn][0],max_flags2[nn][1]])
    
    

    
    # counter = int(0)
    # for gg in G3_picks:
    #     for pp in range(0,Np):
    #         if (genomes[pp,gg,cycles] == max_flags3[counter][0] and genomes[pp,gg+1,cycles] == max_flags3[counter][1] and genomes[pp,gg+2,cycles] == max_flags3[counter][2]):
    #             plants_score[pp] = plants_score[pp] +10.0*(Tpop-Tcond3[gg,max_flags3[counter][0],max_flags3[counter][1],max_flags3[counter][2]])
    #     counter = counter+1
    
    
    

    
    # counter = int(0)
    # for nn in range(0,counter2):
    #     if (G2_picks[nn] >  -1):
    #         gg = G2_picks[nn]
    #         for pp in range(0,Np):
    #             if (genomes[pp,gg,cycles] == max_flags2[nn][0] and genomes[pp,gg+1,cycles] == max_flags2[nn][1]):
    #                 plants_score[pp] = plants_score[pp] +1.0
    
    max_idx = np.argsort(-plants_score)[:]
    
    return max_idx









def UQ_Parent_Selection_G2PNet(genomes,T_mean,T_std,cycles,Ngt,Ng,Np,Npi,models,ensemble_size,aleatoric_noise):
    
    counter1 = int(0)
    counter2 = int(0)
    counter3 = int(0)
    Phi0 = 0.0
    Phi2 = 0.0
    Phi3 = 0.25
    
    Gopt = np.zeros(Ng,dtype=int)
    Phiopt = np.zeros(Ng,dtype=float)
    
    Tcond = np.zeros((Ng,Ngt),dtype=float)
    std_cond = np.zeros((Ng,Ngt),dtype=float)
    Ncond = np.zeros((Ng,Ngt),dtype=int)
    
    Tcond2 = np.zeros((Ng,Ngt,Ngt),dtype=float)
    std_cond2 = np.zeros((Ng,Ngt,Ngt),dtype=float)
    Ncond2 = np.zeros((Ng,Ngt,Ngt),dtype=int)
    
    Tcond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    std_cond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=float)
    Ncond3 = np.zeros((Ng,Ngt,Ngt,Ngt),dtype=int)
    
    Np_fake = Np//5
    fake_genomes = np.zeros( (Np_fake*Ng*Ngt,Ng),dtype=int)
    fake_genomes_real = np.zeros( (Np_fake*Ng*Ngt,Ng),dtype=np.float64)
    Tfake_preds = np.zeros( (ensemble_size,Np_fake*Ng*Ngt,1), dtype=float )
    #Tfake_mean = np.zeros(Np_fake*Ng*Ngt, dtype=float)
    #Tfake_std  = np.zeros(Np_fake*Ng*Ngt, dtype=float)
    
    G1_picks = []
    max_flags1 = []
    Phi_max_prev1 = np.zeros(Ng,dtype=float)
    
    G2_picks = []
    max_flags2 = []
    Phi_max_prev2 = []
    
    
    G3_picks = []
    max_flags3 = []
    Phi_max_prev3 = []
    
    #--------------------------------------------------------------------------
    #--------- 1. Compute current cultivar predicted mean and variance --------
    Tpop = 0.0 # Initialize population mean
    for pp in range(0,Np):
        Tpop += T_mean[pp]
    Tpop = Tpop/float(Np)
    
    std_pop = 0.0
    for pp in range(0,Np):
        std_pop += T_std[pp]
    std_pop = np.sqrt(std_pop/float(Np-1))
    
    #------------------------------------------------------------------
    #--------- 2.cb Compute conditional means & variances -------------
    repeats = int(1)
    Tcond[:,:] = 0.0
    std_cond[:,:] = 1.0
    Ncond[:,:] = int(0)
    not_chosen = [True for mm in range(0,Np)]
    max_idx = []
    Phimax_list = []
    
    best_alleles_list = np.zeros(Ng,dtype=int)
    best_alleles_coeff = np.zeros(Ng,dtype=float)
    plants_score = np.zeros(Np,dtype=float)
    if (cycles > 5):
        for pp in range(0,Np):
            #plants_score[pp] = (T_mean[pp]-Tpop)/std_pop
            plants_score[pp] = (Tpop-T_mean[pp])
    
    
    # Search gene effects independently
    for gg in range(0,Ng):
        
        for ll1 in range(0,Ngt):
            for pp in range(0,Np_fake):
                counter_gg = Np_fake*(Ngt*gg+ll1)+pp
                fake_genomes[counter_gg,:] = genomes[pp,:,cycles]
                fake_genomes[counter_gg,gg] = ll1
                for gg2 in range(0,Ng):
                    fake_genomes_real[counter_gg,gg2] = np.float64(fake_genomes[counter_gg,gg2])
    
    for nn in range(0,ensemble_size):
        Tfake_preds[nn,:,:] = models[nn].predict(fake_genomes_real)
    
    
    for gg in range(0,Ng):
        for ll1 in range(0,Ngt):
            for pp in range(0,Np_fake):
                Tfake_mean = 0.0
                Tfake_std  = 0.0
                counter_gg = Np_fake*(Ngt*gg+ll1)+pp
                for nn in range(0,ensemble_size):
                    Tfake_mean += Tfake_preds[nn,counter_gg,0]/float(ensemble_size)
                for nn in range(0,ensemble_size):
                    Tfake_std  += (Tfake_preds[nn,counter_gg,0]-Tfake_mean)*(Tfake_preds[nn,counter_gg,0]-Tfake_mean)
                Tcond[gg,fake_genomes[counter_gg,gg]] += Tfake_mean
                std_cond[gg,fake_genomes[counter_gg,gg]] += Tfake_std
                Ncond[gg,fake_genomes[counter_gg,gg]] += int(1)
            if (Ncond[gg,ll1] > 0):
                Tcond[gg,ll1] = Tcond[gg,ll1]/float(Ncond[gg,ll1])
        
        Phi_max = -1000.0
        Phi_abs = -1000.0
        max_flag1 = -2
        for ll1 in range(0,Ngt):
            if (Phi_max < (Tpop-Tcond[gg,ll1]) and Ncond[gg,ll1] > 0):
                Phi_max = Tpop-Tcond[gg,ll1]
                max_flag1 = ll1
        
        if (Phi_max > Phi0):
            G1_picks.append(gg)
            Phi_max_prev1.append(Phi_max)
            max_flags1.append(max_flag)
            counter1 = counter1+1
    
    
    
    
    
    
    
    
    
    
    
    fake_genomes = np.zeros( (Np_fake*Ng*Ngt*Ngt*Ngt,Ng),dtype=int)
    fake_genomes_real = np.zeros( (Np_fake*Ng*Ngt*Ngt*Ngt,Ng),dtype=np.float64)
    Tfake_preds = np.zeros( (ensemble_size,Np_fake*Ng*Ngt*Ngt*Ngt,1), dtype=float )
    # Look for triads
    for gg in range(0,Ng-2):
        
        for ll1 in range(0,Ngt):
            for ll2 in range(0,Ngt):
                for ll3 in range(0,Ngt):
                    for pp in range(0,Np_fake):
                        counter_gg = Np_fake*(Ngt*Ngt*Ngt*gg+Ngt*Ngt*ll1+Ngt*ll2+ll3)+pp
                        fake_genomes[counter_gg,:]  = genomes[pp,:,cycles]
                        fake_genomes[counter_gg,gg] = ll1
                        fake_genomes[counter_gg,gg+1] = ll2
                        fake_genomes[counter_gg,gg+2] = ll3
                        for gg2 in range(0,Ng):
                            fake_genomes_real[counter_gg,gg2] = np.float64(fake_genomes[counter_gg,gg2])
                        
    

    for nn in range(0,ensemble_size):
        Tfake_preds[nn,:,:] = models[nn].predict(fake_genomes_real)
    
    
    for gg in range(0,Ng-2):
        Tpop_flag = 0.0
        Tcond_flag = np.zeros((Ng,Ngt),dtype=float)
        for ll1 in range(0,Ngt):
            for ll2 in range(0,Ngt):
                for ll3 in range(0,Ngt):
                    for pp in range(0,Np_fake):
                        Tfake_mean = 0.0
                        Tfake_std  = 0.0
                        counter_gg = Np_fake*(Ngt*Ngt*Ngt*gg+Ngt*Ngt*ll1+Ngt*ll2+ll3)+pp
                        for nn in range(0,ensemble_size):
                            Tfake_mean += Tfake_preds[nn,counter_gg,0]/float(ensemble_size)
                        for nn in range(0,ensemble_size):
                            Tfake_std  += (Tfake_preds[nn,counter_gg,0]-Tfake_mean)*(Tfake_preds[nn,counter_gg,0]-Tfake_mean)
                        Tcond3[gg,fake_genomes[counter_gg,gg],fake_genomes[counter_gg,gg+1],fake_genomes[counter_gg,gg+2]] += Tfake_mean
                        std_cond3[gg,fake_genomes[counter_gg,gg],fake_genomes[counter_gg,gg+1],fake_genomes[counter_gg,gg+2]] += Tfake_std
                        Ncond3[gg,fake_genomes[counter_gg,gg],fake_genomes[counter_gg,gg+1],fake_genomes[counter_gg,gg+2]] += int(1)
                        Tpop_flag += Tfake_mean/float(Np_fake*Ngt*Ngt*Ngt)
                        Tcond_flag[gg,ll1]   += Tfake_mean/float(Np_fake*Ngt*Ngt)
                        Tcond_flag[gg+1,ll2] += Tfake_mean/float(Np_fake*Ngt*Ngt)
                        Tcond_flag[gg+2,ll3] += Tfake_mean/float(Np_fake*Ngt*Ngt)
                        
                    if (Ncond3[gg,ll1,ll2,ll3] > 0):
                        Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
        
        
        Phi_max = -1000.0
        Phi_abs = -1000.0
        max_flag1 = -2
        max_flag2 = -2
        max_flag3 = -2
        for ll1 in range(0,Ngt):
            for ll2 in range(0,Ngt):
                for ll3 in range(0,Ngt):
                    if (Phi_max < (Tpop_flag-Tcond3[gg,ll1,ll2,ll3]) and Ncond3[gg,ll1,ll2,ll3] > 0):
                        Phi_max = Tpop_flag-Tcond3[gg,ll1,ll2,ll3]
                        max_flag1 = ll1
                        max_flag2 = ll2
                        max_flag3 = ll3
                    flag_val = (Tpop_flag-Tcond3[gg,ll1,ll2,ll3]) -(Tpop_flag-Tcond_flag[gg,ll1]) -(Tpop_flag-Tcond_flag[gg+1,ll2]) -(Tpop_flag-Tcond_flag[gg+2,ll3])
                    if (Phi_abs < np.abs(flag_val) and Ncond3[gg,ll1,ll2,ll3] > 0):
                        Phi_abs = np.abs(flag_val)
                        
        # if (counter3 > 0 and G3_picks[counter3-1] == gg-1 and Phi_abs > Phi3):
        #     if (Phi_max_prev3[counter3-1] < Phi_abs):
        #         G3_picks[counter3-1] = gg
        #         Phi_max_prev3[counter3-1] = Phi_abs
        #         max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
        # if (counter3 > 0 and G3_picks[counter3-1] == gg-2 and Phi_abs > Phi3):
        #     if (Phi_max_prev3[counter3-1] < Phi_abs ):
        #         G3_picks[counter3-1] = gg
        #         Phi_max_prev3[counter3-1] = Phi_abs
        #         max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
        if (Phi_abs > Phi3):
            G3_picks.append(gg)
            Phi_max_prev3.append(Phi_abs)
            max_flags3.append([max_flag1,max_flag2,max_flag3])
            counter3 = counter3+1
    
    
    counter = int(0)
    for gg in G3_picks:
        for pp in range(0,Np):
            if (genomes[pp,gg,cycles] == max_flags3[counter][0] and genomes[pp,gg+1,cycles] == max_flags3[counter][1] and genomes[pp,gg+2,cycles] == max_flags3[counter][2]):
                plants_score[pp] = plants_score[pp] +1.0
        counter = counter+1
        
        
        
        
        
    
    # for gg in range(0,Ng):
    #     values = [[] for ll1 in range(0,Ngt)]
    #     for pp in range(0,Np):
    #         Tcond[gg,genomes[pp,gg,cycles]] += T_mean[pp]
    #         std_cond[gg,genomes[pp,gg,cycles]] += T_std[pp]
    #         Ncond[gg,genomes[pp,gg,cycles]] += int(1)
    #         values[genomes[pp,gg,cycles]].append(pp)
    
    #     for ll1 in range(0,Ngt):
    #         if (Ncond[gg,ll1] > 0):
    #             Tcond[gg,ll1] = Tcond[gg,ll1]/float(Ncond[gg,ll1])
    #             std_cond[gg,ll1] = np.sqrt(std_cond[gg,ll1]/float(Ncond[gg,ll1]))
    #         else:
    #             std_cond[gg,ll1] = std_pop
    #             Tcond[gg,ll1] = Tpop
        
    #     Phi_max = -100.0
    #     Phi_abs = 100.0
    #     max_flag = -2
    #     for ll1 in range(0,Ngt):
    #         if (Phi_max < (Tpop-Tcond[gg,ll1])/std_cond[gg,ll1] ):
    #             Phi_max = (Tpop-Tcond[gg,ll1])/std_cond[gg,ll1]
    #             max_flag = ll1
    #         if (Phi_abs > np.abs(Tpop-Tcond[gg,ll1])/std_cond[gg,ll1]):
    #             Phi_abs = np.abs(Tpop-Tcond[gg,ll1])/std_cond[gg,ll1]
    #     if (max_flag > -1 and Phi_abs > Phi0):
    #         G1_picks.append(gg)
    #         Phi_max1[gg] = Phi_max
    #         Gopt[gg] = max_flag
    #         Phiopt[gg] = Phi_max
        
        # for pp in values[max_flag]:
        #     plants_score[pp] = plants_score[pp] +Phiopt[gg]
        
        
        
                
            
    
    
    
    
    # #--------------------------------------------------------------------------
    # #--------------------------- Look for Dyads -------------------------------
    # counter = int(0) # Count the number of possible dyads
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks):
    #         counter += int(1)
    
    
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks and gg < Ng-1):
    #         values = [[[] for ll2 in range(0,Ngt)] for ll1 in range(0,Ngt)]
    #         for pp in range(0,Np):
    #             Tcond2[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles]] += T_mean[pp]
    #             std_cond2[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles]] += T_std[pp]
    #             Ncond2[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles]] += int(1)
    #             values[genomes[pp,gg,cycles]][genomes[pp,gg+1,cycles]].append(pp)
            
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 if (Ncond2[gg,ll1,ll2] > 0):
    #                     Tcond2[gg,ll1,ll2] = Tcond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2])
    #                     std_cond2[gg,ll1,ll2] = np.sqrt(std_cond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2]))
    #                 else:
    #                     Tcond2[gg,ll1,ll2] = Tpop
    #                     std_cond2[gg,ll1,ll2] = std_pop
            
    #         Phi_max = -100.0
    #         Phi_abs = -100.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 flag_val = np.abs((Tpop-Tcond2[gg,ll1,ll2]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]))/std_cond2[gg,ll1,ll2]
    #                 if (Phi_abs < flag_val ):
    #                     Phi_abs = np.abs(flag_val)
    #                 if (Phi_max < (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2] ):
    #                     Phi_max = (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2]
    #                     max_flag1 = ll1
    #                     max_flag2 = ll2

    #         if (counter2 > 0 and G2_picks[counter2-1] == gg-1 and Phi_abs > Phi2):
    #             if (Phi_max_prev2[counter2-1] < Phi_max):
    #                 G2_picks[counter2-1] = gg
    #                 Phi_max_prev2[counter2-1] = Phi_max
    #                 max_flags2[counter2-1][:] = [max_flag1,max_flag2]
    #         elif (Phi_abs > Phi2):
    #             G2_picks.append(gg)
    #             Phi_max_prev2.append(Phi_max)
    #             max_flags2.append([max_flag1,max_flag2])
    #             counter2 = counter2+1
    
    
    # if (counter > 0):
    #     fake_genomes = np.zeros( (Np_fake*counter*Ngt*Ngt,Ng),dtype=int)
    #     fake_genomes_real = np.zeros( (Np_fake*counter*Ngt*Ngt,Ng),dtype=np.float64)
    #     Tfake_preds = np.zeros( (ensemble_size,Np_fake*counter*Ngt*Ngt,1), dtype=float )
    #     counter1 = int(0)
    #     for gg in G1_picks:
    #         if (gg+1 in G1_picks):
    #             for ll1 in range(0,Ngt):
    #                 for ll2 in range(0,Ngt):
    #                     for pp in range(0,Np_fake):
    #                         counter = Np_fake*(Ngt*Ngt*counter1+Ngt*ll1+ll2)+pp
    #                         fake_genomes[counter,:]  = genomes[pp,:,cycles]
    #                         fake_genomes[counter,gg]   = ll1
    #                         fake_genomes[counter,gg+1] = ll2
    #                         for gg2 in range(0,Ng):
    #                             fake_genomes_real[counter,gg2] = np.float64(fake_genomes[counter,gg2])
    #             counter1 += int(1)
        
    #     for nn in range(0,ensemble_size):
    #         Tfake_preds[nn,:,:] = models[nn].predict(fake_genomes_real)
    
    # counter1 = int(0)
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks):
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for pp in range(0,Np):
    #                     Tfake_mean = 0.0
    #                     Tfake_std  = 0.0
    #                     counter = Np_fake*(Ngt*Ngt*counter1+Ngt*ll1+ll2)+pp
    #                     for nn in range(0,ensemble_size):
    #                         Tfake_mean += Tfake_preds[nn,counter,0]/float(ensemble_size)
    #                     for nn in range(0,ensemble_size):
    #                         Tfake_std  += (Tfake_preds[nn,counter,0]-Tfake_mean)*(Tfake_preds[nn,counter,0]-Tfake_mean)
    #                     Tcond2[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1]]    += Tfake_mean
    #                     std_cond2[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1]] += Tfake_std
    #                     Ncond2[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1]] += int(1)
    #         counter1 += int(1)
            
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 Tcond2[gg,ll1,ll2] = Tcond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2])
    #                 std_cond2[gg,ll1,ll2] = np.sqrt(std_cond2[gg,ll1,ll2]/float(Ncond2[gg,ll1,ll2]))
            
    #         Phi_max = -100.0
    #         Phi_abs = -100.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 flag_val = np.abs((Tpop-Tcond2[gg,ll1,ll2]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]))/std_cond2[gg,ll1,ll2]
    #                 if (Phi_abs < flag_val ):
    #                     Phi_abs = np.abs(flag_val)
    #                 if (Phi_max < (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2] ):
    #                     Phi_max = (Tpop-Tcond2[gg,ll1,ll2])/std_cond2[gg,ll1,ll2]
    #                     max_flag1 = ll1
    #                     max_flag2 = ll2
            
            
            
    #         if (counter2 > 0 and G2_picks[counter2-1] == gg-1 and Phi_abs > Phi2):
    #             if (Phi_max_prev2[counter2-1] < Phi_max):
    #                 G2_picks[counter2-1] = gg
    #                 Phi_max_prev2[counter2-1] = Phi_max
    #                 max_flags2[counter2-1][:] = [max_flag1,max_flag2]
    #         elif (Phi_abs > Phi2):
    #             G2_picks.append(gg)
    #             Phi_max_prev2.append(Phi_max)
    #             max_flags2.append([max_flag1,max_flag2])
    #             counter2 = counter2+1
                
            
    
    # for counter in range(0,np.size(G2_picks)):
    #     Gopt[G2_picks[counter]]     = max_flags2[counter][0]
    #     Gopt[G2_picks[counter]+1]   = max_flags2[counter][1]
    #     Phiopt[G2_picks[counter]]   = 5.0*Phi_max_prev2[counter]
    #     Phiopt[G2_picks[counter]+1] = 5.0*Phi_max_prev2[counter]
    
                    
    
    # # #--------------------------------------------------------------------------
    # # #--------------------------- Look for Triads ------------------------------
    # counter = int(0)
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks and gg+2 in G1_picks):
    #         counter += int(1)
    
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks and gg+2 in G1_picks and gg < Ng-2):
    #         values = [[[ [] for ll3 in range(0,Ngt) ] for ll2 in range(0,Ngt)] for ll1 in range(0,Ngt)]
    #         for pp in range(0,Np):
    #             Tcond3[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles],genomes[pp,gg+2,cycles]] += T_mean[pp]
    #             std_cond3[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles],genomes[pp,gg+2,cycles]] += T_std[pp]
    #             Ncond3[gg,genomes[pp,gg,cycles],genomes[pp,gg+1,cycles],genomes[pp,gg+2,cycles]] += int(1)
    #             values[genomes[pp,gg,cycles]][genomes[pp,gg+1,cycles]][genomes[pp,gg+2,cycles]].append(pp)
        
        
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     if (Ncond3[gg,ll1,ll2,ll3] > 0):
    #                         Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
    #                         std_cond3[gg,ll1,ll2,ll3] = np.sqrt(std_cond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3]))
    #                     else:
    #                         Tcond3[gg,ll1,ll2,ll3] = Tpop
    #                         std_cond3[gg,ll1,ll2,ll3] = std_pop
                            
    #         Phi_max = -100.0
    #         Phi_abs = -100.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         max_flag3 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     flag_val = np.abs((Tpop-Tcond3[gg,ll1,ll2,ll3]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]) -(Tpop-Tcond[gg+2,ll3]))/std_cond3[gg,ll1,ll2,ll3]
    #                     if (Phi_abs < flag_val ):
    #                         Phi_abs = np.abs(flag_val)
    #                     if (Phi_max < (Tpop-Tcond3[gg,ll1,ll2,ll3])/std_cond3[gg,ll1,ll2,ll3] ):
    #                         Phi_max = (Tpop-Tcond3[gg,ll1,ll2,ll3])/std_cond3[gg,ll1,ll2,ll3]
    #                         max_flag1 = ll1
    #                         max_flag2 = ll2
    #                         max_flag3 = ll3
            
    #         if (counter3 > 0 and G3_picks[counter3-1] == gg-1 and Phi_abs > Phi3):
    #             if (Phi_max_prev3[counter3-1] < Phi_max):
    #                 G3_picks[counter3-1] = gg
    #                 Phi_max_prev3[counter3-1] = Phi_max
    #                 max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
    #         if (counter3 > 0 and G3_picks[counter3-1] == gg-2 and Phi_abs > Phi3):
    #             if (Phi_max_prev3[counter3-1] < Phi_max ):
    #                 G3_picks[counter3-1] = gg
    #                 Phi_max_prev3[counter3-1] = Phi_max
    #                 max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
    #         elif (Phi_abs > Phi3):
    #             G3_picks.append(gg)
    #             Phi_max_prev3.append(10.0*Phi_max)
    #             max_flags3.append([max_flag1,max_flag2,max_flag3])
    #             counter3 = counter3+1
    
    
    
    # if (counter > 0):
    #     fake_genomes = np.zeros( (Np_fake*counter*Ngt*Ngt*Ngt,Ng),dtype=int)
    #     fake_genomes_real = np.zeros( (Np_fake*counter*Ngt*Ngt*Ngt,Ng),dtype=np.float64)
    #     Tfake_preds = np.zeros( (ensemble_size,Np_fake*counter*Ngt*Ngt*Ngt,1), dtype=float )
    #     counter1 = int(0)
    #     for gg in G1_picks:
    #         if (gg+1 in G1_picks and gg+2 in G1_picks):
    #             for ll1 in range(0,Ngt):
    #                 for ll2 in range(0,Ngt):
    #                     for ll3 in range(0,Ngt):
    #                         for pp in range(0,Np_fake):
    #                             counter = Np_fake*(Ngt*Ngt*Ngt*counter1+ll1*Ngt*Ngt+ll2*Ngt+ll3)+pp
    #                             fake_genomes[counter,:]  = genomes[pp,:,cycles]
    #                             fake_genomes[counter,gg] = ll1
    #                             fake_genomes[counter,gg+1] = ll2
    #                             fake_genomes[counter,gg+2] = ll3
    #                             for gg2 in range(0,Ng):
    #                                 fake_genomes_real[counter,gg2] = np.float64(fake_genomes[counter,gg2])
    #             counter1 += int(1)
        
    #     for nn in range(0,ensemble_size):
    #         Tfake_preds[nn,:,:] = models[nn].predict(fake_genomes_real)
    
    # counter1 = int(0)
    # for gg in G1_picks:
    #     if (gg+1 in G1_picks and gg+2 in G1_picks):
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     for pp in range(0,Np):
    #                         Tfake_mean = 0.0
    #                         Tfake_std  = 0.0
    #                         counter = Np_fake*(Ngt*Ngt*Ngt*counter1+Ngt*Ngt*ll1+Ngt*ll2+ll3)+pp
    #                         for nn in range(0,ensemble_size):
    #                             Tfake_mean += Tfake_preds[nn,counter,0]/float(ensemble_size)
    #                         for nn in range(0,ensemble_size):
    #                             Tfake_std  += (Tfake_preds[nn,counter,0]-Tfake_mean)*(Tfake_preds[nn,counter,0]-Tfake_mean)
    #                         Tcond3[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1],fake_genomes[counter,gg+2]]    += Tfake_mean
    #                         std_cond3[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1],fake_genomes[counter,gg+2]] += Tfake_std
    #                         Ncond3[gg,fake_genomes[counter,gg],fake_genomes[counter,gg+1],fake_genomes[counter,gg+2]]    += int(1)
    #         counter1 += int(1)
            
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     Tcond3[gg,ll1,ll2,ll3] = Tcond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3])
    #                     std_cond3[gg,ll1,ll2,ll3] = np.sqrt(std_cond3[gg,ll1,ll2,ll3]/float(Ncond3[gg,ll1,ll2,ll3]))
            
    #         Phi_max = -100.0
    #         Phi_abs = -100.0
    #         max_flag1 = -2
    #         max_flag2 = -2
    #         max_flag3 = -2
    #         for ll1 in range(0,Ngt):
    #             for ll2 in range(0,Ngt):
    #                 for ll3 in range(0,Ngt):
    #                     flag_val = np.abs((Tpop-Tcond3[gg,ll1,ll2,ll3]) -(Tpop-Tcond[gg,ll1]) -(Tpop-Tcond[gg+1,ll2]) -(Tpop-Tcond[gg+2,ll3]))/std_cond3[gg,ll1,ll2,ll3]
    #                     if (Phi_abs < flag_val ):
    #                         Phi_abs = np.abs(flag_val)
    #                     if (Phi_max < (Tpop-Tcond3[gg,ll1,ll2,ll3])/std_cond3[gg,ll1,ll2,ll3] ):
    #                         Phi_max = (Tpop-Tcond3[gg,ll1,ll2,ll3])/std_cond3[gg,ll1,ll2,ll3]
    #                         max_flag1 = ll1
    #                         max_flag2 = ll2
    #                         max_flag3 = ll3
            
    #         if (counter3 > 0 and G3_picks[counter3-1] == gg-1 and Phi_abs > Phi3):
    #             if (Phi_max_prev3[counter3-1] < Phi_max):
    #                 G3_picks[counter3-1] = gg
    #                 Phi_max_prev3[counter3-1] = Phi_max
    #                 max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
    #         if (counter3 > 0 and G3_picks[counter3-1] == gg-2 and Phi_abs > Phi3):
    #             if (Phi_max_prev3[counter3-1] < Phi_max ):
    #                 G3_picks[counter3-1] = gg
    #                 Phi_max_prev3[counter3-1] = Phi_max
    #                 max_flags3[counter3-1][:] = [max_flag1,max_flag2,max_flag3]
    #         elif (Phi_abs > Phi3):
    #             G3_picks.append(gg)
    #             Phi_max_prev3.append(10.0*Phi_max)
    #             max_flags3.append([max_flag1,max_flag2,max_flag3])
    #             counter3 = counter3+1
    
    # for counter in range(0,np.size(G3_picks)):
    #     Gopt[G3_picks[counter]]     = max_flags3[counter][0]
    #     Gopt[G3_picks[counter]+1]   = max_flags3[counter][1]
    #     Gopt[G3_picks[counter]+2]   = max_flags3[counter][2]
    #     Phiopt[G3_picks[counter]]   = 5.0*Phi_max_prev3[counter]
    #     Phiopt[G3_picks[counter]+1] = 5.0*Phi_max_prev3[counter]
    #     Phiopt[G3_picks[counter]+2] = 5.0*Phi_max_prev3[counter]
    
    
    # for gg in range(0,Ng):
    #     for pp in range(0,Np):
    #         if (genomes[pp,gg,cycles] == Gopt[gg] ):
    #             plants_score[pp] = plants_score[pp] +Phiopt[gg]
    
    
    # counter = int(0)
    # for nn in range(0,counter2):
    #     if (G2_picks[nn] >  -1):
    #         gg = G2_picks[nn]
    #         for pp in range(0,Np):
    #             if (genomes[pp,gg,cycles] == max_flags2[nn][0] and genomes[pp,gg+1,cycles] == max_flags2[nn][1]):
    #                 plants_score[pp] = plants_score[pp] +1.0
    
    
    # counter = int(0)
    # for nn in range(0,counter3):
    #     if (G3_picks[nn] >  -1):
    #         gg = G3_picks[nn]
    #         for pp in range(0,Np):
    #             if (genomes[pp,gg,cycles] == max_flags3[nn][0] and genomes[pp,gg+1,cycles] == max_flags3[nn][1] and genomes[pp,gg+2,cycles] == max_flags3[nn][2]):
    #                 plants_score[pp] = plants_score[pp] +2.0
    
    
    max_idx = np.argsort(-plants_score)[:]
    
    return max_idx




