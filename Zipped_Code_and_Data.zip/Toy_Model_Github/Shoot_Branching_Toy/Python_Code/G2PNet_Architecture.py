#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""


from G2P_Model_Cases import FCN_params
import tensorflow.keras.backend as kb
import tensorflow as tf
tf.keras.backend.set_floatx('float64')


def get_model(input_dim, output_dim, architecture, case, input_nodes, output_nodes, output_name):
    if (architecture == "FCN"):
        model = get_FCN(input_dim, output_dim, case)
    if (architecture == "LR"):
        model = get_LR(input_dim, output_dim, case)
    elif (architecture == "GNN"):
        model = get_BioGNN(input_dim,output_dim,'FCN',input_nodes,output_nodes,output_name)
    elif (architecture == "Convolution"):
        model = get_GAT(input_dim, output_dim)
    return model



def get_LR(input_dim, output_dim, case):

    # --------------------------------------------------------------------------
    # ------ 0. Initialize model with the input data and their dimension -------
    # Load hyperparameters.
    input_shape = (input_dim)  # Input dimension
    layers = [tf.keras.Input(shape=input_shape)]  # Initialize list of layers.
    
    # Output layer with no activation function.
    layers.append(tf.keras.layers.Dense(1, activation=None)(layers[-1]))

    # --------------------------------------------------------------------------
    # ----------------------- 2. Finalize model --------------------------------
    # Finalize model.
    model = tf.keras.Model(inputs=layers[0], outputs=layers[-1])

    return model

def get_FCN(input_dim, output_dim, case):

    # --------------------------------------------------------------------------
    # ------ 0. Initialize model with the input data and their dimension -------
    # Load hyperparameters.
    total_layers, layer_dims, alpha0, layer_regs = FCN_params(case)
    input_shape = (input_dim)  # Input dimension
    layers = [tf.keras.Input(shape=input_shape)]  # Initialize list of layers.

    # --------------------------------------------------------------------------
    # -------------------- 1. Construct layers of the model --------------------
    for ll in range(0, total_layers-1):  # Construct all hidden layers.
        # hidden layers
        layers.append(tf.keras.layers.Dense(
            layer_dims[ll], activation=None, kernel_regularizer=tf.keras.regularizers.L1(layer_regs[ll]))(layers[-1]))
        # Activation function.
        layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0[ll])(layers[-1]))
    # Output layer with no activation function.
    layers.append(tf.keras.layers.Dense(layer_dims[total_layers-1], activation=None,
                  kernel_regularizer=tf.keras.regularizers.L1(layer_regs[total_layers-1]))(layers[-1]))

    # --------------------------------------------------------------------------
    # ----------------------- 2. Finalize model --------------------------------
    # Finalize model.
    model = tf.keras.Model(inputs=layers[0], outputs=layers[-1])

    return model




def get_BioGNN(input_dim, output_dim,node_type,input_nodes,output_nodes,output_name):

    alpha0 = 0.01

    # --------------------------------------------------------------------------
    # ------ 0. Initialize model with the input data and their dimension -------
    input_shape = (input_dim)  # Input dimension
    layers = [tf.keras.Input(shape=input_shape)]  # Initialize list of layers.

    node_names = []
    for ii in range(0,len(output_nodes)):
        if (input_nodes[ii] != 'Genome' and not (input_nodes[ii] in node_names) ):
            node_names.append(input_nodes[ii])
        if (not (output_nodes[ii] in node_names) ):
            node_names.append(output_nodes[ii])

    ioutput = node_names.index(output_name)
    neighbor_nodes = [[] for ii in range(0,len(node_names))]
    for ii in range(0,len(output_nodes)):
        iflag = node_names.index(output_nodes[ii])
        if (not (input_nodes[ii] in neighbor_nodes) ):
            neighbor_nodes[iflag].append(input_nodes[ii])

    # Initialize the layer for each node
    node_layers = [[] for ii in range(0,len(node_names))]
    node_finished = [False for ii in range(0,len(node_names))]
    neighbors_finished = [False for ii in range(0,len(node_names))]

    # --------------------------------------------------------------------------
    # ------------ 1. Predict direct gene effects to A, S, CKb, SLb ------------
    reg_coeff = 0.0005
    for ii in range(0,len(node_names)): # Find all nodes that are directly connected with the Genome alone. 
        if ( len(neighbor_nodes[ii]) == 1 and neighbor_nodes[ii][0] == 'Genome'):
            node_layers[ii].append(tf.keras.layers.Dense(
        1, activation=None, kernel_regularizer=tf.keras.regularizers.L1(reg_coeff))(layers[-1][:, :]))
            node_finished[ii] = True
            neighbors_finished[ii] = True

    for ii in range(0,len(node_names)):
        flag = True
        for jj in neighbor_nodes[ii]:
            if (jj != 'Genome'):
                jindex = node_names.index(jj)
                if (flag == True and node_finished[jindex] == True):
                    flag = True
                else:
                    flag = False
        if (flag == True):
            neighbors_finished[ii] = True


    if (node_type == 'FCN'):
        while(all(node_finished) == False):
            for ii in range(0,len(node_names)):
                if (node_finished[ii] == False and neighbors_finished[ii] == True):
                    node_layers[ii].append(tf.keras.layers.Concatenate(axis=1)([node_layers[0][-1][:], node_layers[1][-1][:], node_layers[2][-1][:] ]))
                    node_layers[ii].append(tf.keras.layers.Dense(4, activation=None)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.LeakyReLU(alpha=alpha0)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.Dense(4, activation=None)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.LeakyReLU(alpha=alpha0)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.Dense(4, activation=None)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.LeakyReLU(alpha=alpha0)(node_layers[ii][-1]))
                    node_layers[ii].append(tf.keras.layers.Dense(1, activation=None)(node_layers[ii][-1]))
                    node_finished[ii] = True
                    for jj in range(0,len(node_names)):
                        flag = True
                        for kk in neighbor_nodes[jj]:
                            if (kk != 'Genome'):
                                kindex = node_names.index(kk)
                                if (flag == True and node_finished[kindex] == True):
                                    flag = True
                                else:
                                    flag = False
                        if (flag == True):
                            neighbors_finished[jj] = True
        
        # Finalize model.
        #model = tf.keras.Model(inputs=layers[0], outputs=layers[-1])
        model = tf.keras.Model(inputs=layers[0], outputs=node_layers[ioutput][-1][:])

    elif (node_type == 'Transformer'):
        hinput = tf.keras.layers.Concatenate(axis=1)([auxin_val, sucro_val, ckb_value, slb_value])
        
        total_attention_layers = int(5)  # Number of attention layers.
        total_attention_heads  = int(4) # Number of attention heads per layer. 
        graph_input = []
        
        for kk in range(0,total_attention_heads):
            graph_input.append(tf.keras.layers.Dense(6, activation=None)(hinput))
        
        hauxin = graph_input[0][:, 0:1]
        hsucro = graph_input[0][:, 1:2]
        hck = graph_input[0][:, 2:3]
        hsl = graph_input[0][:, 3:4]
        hi = graph_input[0][:, 4:5]
        ht = graph_input[0][:, 5:6]
        for kk in range(1,total_attention_heads):
            hauxin = tf.keras.layers.Concatenate(axis=1)([ hauxin, graph_input[kk][:, 0:1]])
            hsucro = tf.keras.layers.Concatenate(axis=1)([ hsucro, graph_input[kk][:, 1:2]])
            hck    = tf.keras.layers.Concatenate(axis=1)([ hck,    graph_input[kk][:, 2:3]])
            hsl    = tf.keras.layers.Concatenate(axis=1)([ hsl,    graph_input[kk][:, 3:4]])
            hi     = tf.keras.layers.Concatenate(axis=1)([ hi,     graph_input[kk][:, 4:5]])
            ht     = tf.keras.layers.Concatenate(axis=1)([ ht,     graph_input[kk][:, 5:6]])
    
        anet = [[] for ll in range(0,total_attention_layers)]
        final_layer = False
        for ll in range(0,total_attention_layers):
            for kk in range(0,total_attention_heads):
                anet[ll].append(tf.keras.layers.Dense(units=1, activation=None))
            if (ll == total_attention_layers-1):
                final_layer = True
            hsucro, hauxin, hck, hsl, hi, ht = attention_layer(hauxin, hsucro, hck, hsl, hi, ht, anet[ll], alpha0, total_attention_heads, final_layer)
            
        model = tf.keras.Model(inputs=layers[0], outputs=ht)
    
    return model





# A graph attention network
def get_GAT(input_dim, output_dim):
    
    alpha0 = 0.01

    # --------------------------------------------------------------------------
    # ------ 0. Initialize model with the input data and their dimension -------
    input_shape = (input_dim)  # Input dimension
    layers = [tf.keras.Input(shape=input_shape)]  # Initialize list of layers.

    total_attention_layers = int(3)
    total_attention_heads  = int(10)

    #W = []
    #a = []
    # for ll in range(0,total_attention_layers):
    #    W.append(StaticDense(6))
    #    a.append(StaticDense(1))

    #layers.append( tf.keras.layers.Dense(6,activation=None)(layers[-1][:,:]) )
    graph_input = []
    for kk in range(0,total_attention_heads):
        graph_input.append(tf.keras.layers.Dense(6, activation=None)(layers[-1][:, :]))
    hauxin = graph_input[0][:, 0:1]
    hsucro = graph_input[0][:, 1:2]
    hck = graph_input[0][:, 2:3]
    hsl = graph_input[0][:, 3:4]
    hi = graph_input[0][:, 4:5]
    ht = graph_input[0][:, 5:6]
    for kk in range(1,total_attention_heads):
        hauxin = tf.keras.layers.Concatenate(axis=1)([ hauxin, graph_input[kk][:, 0:1]])
        hsucro = tf.keras.layers.Concatenate(axis=1)([ hsucro, graph_input[kk][:, 1:2]])
        hck    = tf.keras.layers.Concatenate(axis=1)([ hck,    graph_input[kk][:, 2:3]])
        hsl    = tf.keras.layers.Concatenate(axis=1)([ hsl,    graph_input[kk][:, 3:4]])
        hi     = tf.keras.layers.Concatenate(axis=1)([ hi,     graph_input[kk][:, 4:5]])
        ht     = tf.keras.layers.Concatenate(axis=1)([ ht,     graph_input[kk][:, 5:6]])
    
    anet = [[] for ll in range(0,total_attention_layers)]
    final_layer = False
    for ll in range(0,total_attention_layers):
        for kk in range(0,total_attention_heads):
            anet[ll].append(tf.keras.layers.Dense(units=1, activation=None))
        if (ll == total_attention_layers-1):
            final_layer = True
        #anet = tf.keras.layers.Dense(units=1, activation=None)
        hsucro, hauxin, hck, hsl, hi, ht = attention_layer(hauxin, hsucro, hck, hsl, hi, ht, anet[ll], alpha0, total_attention_heads, final_layer)
    
    
    # Concatenate all final outputs to a single vector.
    #layers.append(tf.keras.layers.Concatenate(axis=1)([hauxin, hsucro, hck, hsl, ht]))
    
    # Finalize model.
    #model = tf.keras.Model(inputs=layers[0], outputs=layers[-1])
    model = tf.keras.Model(inputs=layers[0], outputs=ht)

    return model


def param_loss_yield(alpha):
    def custom_loss(y_actual, y_pred):
        #loss = tf.math.multiply_no_nan(
        #    kb.square(y_actual[:, 0:alpha]-y_pred[:, 0:alpha]), y_actual[:, alpha:2*alpha])
        loss = kb.square(y_actual[:, 0:alpha]-y_pred[:, 0:alpha])
        return loss
    return custom_loss


def sucrose_activation(x):
    return (x*x/(5.0+x*x))
    # return (0.25*x*x/(0.19+x*x))


def auxin_activation(x):
    return (x*x/(5.0+x*x))
    # return (24.89*x*x/(294.58+x*x))


def cka_activation(x):
    return (1.0/(1.0+0.96*x))
    # return (0.51-0.25*(x-1.0) +0.122*(x-1.0)*(x-1.0))


def ick_activation(x):
    # return (287.53*(1.0/1001.0 -2000.0*(x-1.0)/(1001.0*1001.0)))
    return (287.53/(1.0+1000.0*x*x))
    # return (0.28753*(3.0-2.0*x))


def isl_activation(x):
    return (x*x)
    # return (x*x/5.64)


def is_activation(x):
    return (1.0/(x*x))
    # return (x*x/5.64)


def attention_layer(hauxin, hsucro, hck, hsl, hi, ht, anet, alpha0, total_attention_head, final_layer):
    
    for kk in range(0,total_attention_head):
        esucro_sucro = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hsucro[:,kk:kk+1], hsucro[:,kk:kk+1] ])) )    
        eauxin_auxin = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hauxin[:,kk:kk+1], hauxin[:,kk:kk+1]])) )  
        eck_ck    = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hck[:,kk:kk+1], hck[:,kk:kk+1]])) )
        eck_auxin = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hck[:,kk:kk+1], hsucro[:,kk:kk+1]])) )
        eck_sucro = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hck[:,kk:kk+1], hauxin[:,kk:kk+1]])) )
        esl_sl    = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hsl[:,kk:kk+1], hsl[:,kk:kk+1]])) )
        esl_sucro = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hsl[:,kk:kk+1], hsucro[:,kk:kk+1]])) )
        ei_i      = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hi[:,kk:kk+1], hi[:,kk:kk+1]])) )
        ei_sucro  = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hi[:,kk:kk+1], hsucro[:,kk:kk+1]])) )
        ei_ck     = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hi[:,kk:kk+1], hck[:,kk:kk+1]])) )
        ei_sl     = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ hi[:,kk:kk+1], hsl[:,kk:kk+1]])) )
        et_t      = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ ht[:,kk:kk+1], ht[:,kk:kk+1]])) )
        et_i      = tf.math.exp( anet[kk](tf.keras.layers.Concatenate(axis=1)([ ht[:,kk:kk+1], hi[:,kk:kk+1]])) )
        asucro_sucro = esucro_sucro/esucro_sucro
        aauxin_auxin = eauxin_auxin/eauxin_auxin
        ack_ck    = eck_ck/(eck_ck + eck_auxin + eck_sucro)
        ack_auxin = eck_auxin/(eck_ck + eck_auxin + eck_sucro)
        ack_sucro = eck_sucro/(eck_ck + eck_auxin + eck_sucro)
        asl_sl    = esl_sl/(esl_sl + esl_sucro)
        asl_sucro = esl_sucro/(esl_sl + esl_sucro)
        ai_i     = ei_i/(ei_i + ei_sucro + ei_ck + ei_sl)
        ai_ck    = ei_ck/(ei_i + ei_sucro + ei_ck + ei_sl)
        ai_sl    = ei_sl/(ei_i + ei_sucro + ei_ck + ei_sl)
        ai_sucro = ei_i/(ei_i + ei_sucro + ei_ck + ei_sl)
        at_i = et_i/(et_i + et_t)
        at_t = et_t/(et_i + et_t)
        hauxin2 = aauxin_auxin*hauxin[:,kk:kk+1]
        hsucro2 = asucro_sucro*hsucro[:,kk:kk+1]
        hck2    = ack_auxin*hauxin[:,kk:kk+1] +ack_sucro*hsucro[:,kk:kk+1] +ack_ck*hck[:,kk:kk+1]
        hsl2    = asl_sucro*hsucro[:,kk:kk+1] +asl_sl*hsl[:,kk:kk+1]
        hi2     = ai_i*hi[:,kk:kk+1] + ai_sucro*hsucro[:,kk:kk+1] +ai_ck*hck[:,kk:kk+1] +ai_sl*hsl[:,kk:kk+1]
        ht2     = at_i*hi[:,kk:kk+1] + at_t*ht[:,kk:kk+1]
        #print(tf.size(ht2))
        
        graph_output = tf.keras.layers.Concatenate(axis=1)([ hauxin2, hsucro2, hck2, hsl2, hi2, ht2])
        if (kk == 0):
            hauxin_out = graph_output[:, 0:1]
            hsucro_out = graph_output[:, 1:2]
            hck_out    = graph_output[:, 2:3]
            hsl_out    = graph_output[:, 3:4]
            hi_out     = graph_output[:, 4:5]
            ht_out     = graph_output[:, 5:6]
        elif (kk > 0 and not(final_layer) ):
            hauxin_out = tf.keras.layers.Concatenate(axis=1)([ hauxin_out, hauxin2])
            hsucro_out = tf.keras.layers.Concatenate(axis=1)([ hsucro_out, hsucro2])
            hck_out    = tf.keras.layers.Concatenate(axis=1)([ hck_out, hck2])
            hsl_out    = tf.keras.layers.Concatenate(axis=1)([ hsl_out, hsl2])
            hi_out     = tf.keras.layers.Concatenate(axis=1)([ hi_out, hi2])
            ht_out     = tf.keras.layers.Concatenate(axis=1)([ ht_out, ht2])
        elif (kk > 0 and final_layer):
            hauxin_out = tf.math.add(hauxin_out, graph_output[:, 0:1])
            hsucro_out = tf.math.add(hsucro_out, graph_output[:, 1:2])
            hck_out    = tf.math.add(hck_out, graph_output[:, 2:3])
            hsl_out    = tf.math.add(hsl_out, graph_output[:, 3:4])
            hi_out     = tf.math.add(hi_out, graph_output[:, 4:5])
            ht_out     = tf.math.add(ht_out, graph_output[:, 5:6])

    return hsucro_out, hauxin_out, hck_out, hsl_out, hi_out, ht_out
    #return
