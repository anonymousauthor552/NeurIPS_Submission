#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
import os  # Imported to check that appropriate folders exist (and create them if not).
#import numpy as np
#import scipy.io as sio
#import matplotlib.pyplot as plt
import tensorflow as tf
tf.keras.backend.set_floatx('float64')
#from scipy.io import netcdf
#import netCDF4 as nc
#import time
#import cartopy.crs as ccrs





def train_batchfile(user_input,script_type,nn,aa):
    
    case_flag  = user_input[0]
    plant_flag = user_input[1]
    Np  = int(user_input[2])
    Ng  = int(user_input[3])
    Nc  = int(user_input[4])
    Npi = int(user_input[5])
    Na  = int(user_input[6])
    Ngt = int(user_input[7])
    Ncoeffs = int(user_input[8])
    
    train_epochs = int(user_input[11])
    train_batch  = int(user_input[12])
    validation_percentage = user_input[13]
    architecture = user_input[14]
    loss_function = user_input[15]
    optimizer = user_input[16]
    aleatoric_noise = float(user_input[17])
    alleles_distr = user_input[18]
    Nchrome = int(user_input[19])
    max_nonlinearity = int(user_input[20])
    Nnonlin = int(user_input[21])
    
        
    if (script_type == "sbatch"):
        # Name of batch file to be created
        batch_flag = "batch_"+str(case_flag)+"_run"+str(plant_flag)+"_n"+str(nn)+"_i"+str(aa)+"_Train"
        
        if (Ng < 60):
            memory_flag = "'\n#SBATCH --mem=6G'"
            time_flag = "'\n#SBATCH --time=1:00:00'"
        elif (Ng < 100):
            memory_flag = "'\n#SBATCH --mem=4G'"
            time_flag = "'\n#SBATCH --time=1:00:00'"
        elif (Ng < 200):
            memory_flag = "'\n#SBATCH --mem=8G'"
            time_flag = "'\n#SBATCH --time=2:00:00'"
        elif (Ng < 2000):
            memory_flag = "'\n#SBATCH --mem=16G'"
            time_flag = "'\n#SBATCH --time=2:00:00'"
    
        cmd_flag = "echo -e '#!/bin/bash' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -A phy220062' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH --nodes=1' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH --ntasks=1' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e "+memory_flag+" >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e "+time_flag+" >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -J train_n"+str(nn)+"_r"+str(plant_flag)+"_i"+str(aa)+"' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -o myjob.o%j' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -e myjob.e%j' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -p shared' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        #cmd_flag = "echo -e '\n#SBATCH --mail-user=alexchar@mit.edu' >> batch_files/"+batch_flag
        #os.system(cmd_flag)
        #cmd_flag = "echo -e '\n#SBATCH --mail-type=all' >> batch_files/"+batch_flag
        #os.system(cmd_flag)
        cmd_flag = "echo -e '\nmodule purge' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\nsource activate ~/miniconda3/envs/tensorflow-env' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\ncasename='TC_0'' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\necho $casename > SESSION.NAME' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        # Begin echo command to write to the batch file
        cmd_flag = "echo -e "
        # Line regarding training a realization of the neural network
#        cmd_flag += " '\npython ./G2PNet.py "+str(plant_flag)+"' "
#        # Push the text to the batch file
#        cmd_flag += " >> batch_files/"+batch_flag 
#        os.system(cmd_flag)
        
        cmd_flag += " '\npython ./G2PNet.py "+str(case_flag)+" "+str(plant_flag)+" "+str(Np)+" "+str(Ng)+ \
        " "+str(Nc)+" "+str(Npi)+" "+str(Na)+" "+str(Ngt)+" "+str(Ncoeffs)+" "+str(train_epochs)+" "+str(train_batch)+ \
        " "+str(validation_percentage)+" "+architecture+" "+loss_function+" "+optimizer+" "+str(aleatoric_noise)+" "+str(nn)+" "+str(aa)+" "+alleles_distr+" "+str(Nchrome)+" "+str(max_nonlinearity)+" "+str(Nnonlin)
        # Create file that will signal to the main process that training is done. 
        cmd_flag += "\ntouch check_files/G2PNet_Train_"+str(case_flag)+"_n"+str(nn)+"_Plant"+str(plant_flag)+"_iter"+str(aa)+".txt' " 
        # Push the text to the batch file
        cmd_flag += " >> batch_files/"+batch_flag 
        os.system(cmd_flag)
        
                    
        cmd_flag = "sbatch batch_files/"+batch_flag
        os.system(cmd_flag)
    elif (script_type == "shell"):
        # Name of batch file to be created
        batch_flag = "batch_"+str(case_flag)+"_run"+str(plant_flag)+"_n"+str(nn)+"_i"+str(aa)+"_Train"
        
        cmd_flag = "echo -e '#!/bin/bash' >> shell_files/"+batch_flag
        os.system(cmd_flag)
        
        cmd_flag = "echo -e "
        # Line regarding training a realization of the neural network
        cmd_flag += " '\npython ./G2PNet.py "+str(case_flag)+" "+str(plant_flag)+" "+str(Np)+" "+str(Ng)+ \
        " "+str(Nc)+" "+str(Npi)+" "+str(Na)+" "+str(Ngt)+" "+str(Ncoeffs)+" "+str(train_epochs)+" "+str(train_batch)+ \
        " "+str(validation_percentage)+" "+architecture+" "+loss_function+" "+optimizer+" "+str(aleatoric_noise)+" "+str(nn)+" "+str(aa)+" "+alleles_distr+" "+str(Nchrome)+" "+str(max_nonlinearity)+" "+str(Nnonlin)
        # Create file that will signal to the main process that training is done. 
        cmd_flag += "\ntouch check_files/G2PNet_Train_"+str(case_flag)+"_n"+str(nn)+"_Plant"+str(plant_flag)+"_iter"+str(aa)+".txt' " 
        # Push the text to the batch file
        cmd_flag += " >> shell_files/"+batch_flag 
        os.system(cmd_flag)
        
        cmd_flag = "chmod +x shell_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "shell_files/"+batch_flag+" > debug_files/"+batch_flag+" 2>&1 &"
        os.system(cmd_flag)
    
    
    return




#if __name__ == "__main__":
#    
#    
#    Nruns = int(sys.argv[1])
#    for rr in range(0,Nruns):
#        train_batchfile(rr,"sbatch")
#    
#    exit()






