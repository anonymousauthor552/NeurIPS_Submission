#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import sys # Imported to read input from command line.
import numpy as np
import os
import time
import netCDF4 as nc

import tensorflow as tf
tf.keras.backend.set_floatx('float64')


from G2P_Equations import cytokinin_eq
from G2P_Equations import strigonlactone_eq
from G2P_Equations import signal_integrator_eq
from G2P_Equations import bud_outgrowth_time_eq

from G2P_Model_Cases import Bertheloot_coeffs

from G2PNet_Architecture import sucrose_activation
from G2PNet_Architecture import auxin_activation
from G2PNet_Architecture import ick_activation
from G2PNet_Architecture import isl_activation
from G2PNet_Architecture import cka_activation
from G2PNet_Architecture import is_activation
#from G2PNet_Architecture import StaticDense
from G2PNet_Architecture import attention_layer


from _Parent_Selection import UQ_Parent_Selection
from _Parent_Selection import UQ_Parent_Selection_G2PNet
from _Parent_Selection import UQ_Parent_Selection_Ref


def Inference_Process(user_input,model):
    
    #--------------------------------------------------------------------------
    #--------------- 1. Initialize data for breeding process ------------------
    case_flag = user_input[0] # Name of case given by user. 
    plant_flag = user_input[1] # Identification number of individual run. 
    Np  = int(user_input[2]) # Total number of individuals per cycle. 
    Ng  = int(user_input[3]) # Total number of genes in genome. 
    Nc  = int(user_input[4]) # Total number of breeding cycles. 
    Npi = int(user_input[5]) # Number of parents to be chosen every cycle. 
    Na  = int(user_input[6]) # Total number of alleles per gene. 
    Ngt = int(user_input[7]) # Total possible genotypes per gene. 
    Ncoeffs = int(user_input[8]) # Number of coefficients directly affected by genes. 
    mean_genes_per_coeff = int(user_input[9]) # Number of genes per coefficient known by the mean model. 
    ensemble_size = int(user_input[10])
    breed_algo = user_input[11]
    aleatoric_noise = float(user_input[12])
    iter_number = int(user_input[13])
    model_architecture = user_input[14]
    alleles_distr = user_input[15]
    Nchrome = int(user_input[16])
    max_nonlinearity = int(user_input[17])
    Nnonlin = int(user_input[18])
    training_percentage = float(user_input[19])
    validation_percentage = float(user_input[20])
    testing_percentage = float(user_input[21])
    
    nonlinearity_choices = pow(Ngt,max_nonlinearity)
    
    genes_per_coeff = int(Ng//Ncoeffs) # Number of genes per coefficient in the reference model. 
    
    model_genes_per_coeff = genes_per_coeff
    if (model == "Mean"):
        model_genes_per_coeff = mean_genes_per_coeff
    elif(model == "Ref"):
        model_genes_per_coeff = genes_per_coeff
    
    genomes = np.zeros( (Np,Ng,Nc),dtype=int )
    alleles = np.zeros( (Na,Np,Ng,Nc),dtype=int )
    genome_parents = np.zeros((Npi,Ng),dtype=int)
    alleles_parents = np.zeros((Na,Npi,Ng),dtype=int)
    UU = np.zeros( (Ngt,Ng), dtype=float )
    UUall = np.zeros( (Ngt,Ng), dtype=float )
    coeffs_min = np.zeros(Ncoeffs,dtype=float)
    
    GGnonlinear = np.zeros((Nnonlin,max_nonlinearity),dtype=int)
    UUnonlinear = np.zeros((Nnonlin,nonlinearity_choices),dtype=float)
    AAnonlinear = np.zeros((Nnonlin,2),dtype=int)
    
    A = np.zeros( (Np,Nc),dtype=float)
    S = np.zeros( (Np,Nc),dtype=float)
    CK = np.zeros( (Np,Nc),dtype=float)
    CK_flag = np.zeros(Np,dtype=float)
    SL = np.zeros( (Np,Nc),dtype=float)
    I  = np.zeros( (Np,Nc),dtype=float)
    T  = np.zeros( (Np,Nc),dtype=float)
    Ucoeffs = np.zeros( (Np,Ncoeffs-2), dtype=float )

    test_index = np.zeros( Np-round(Np*training_percentage)-round(Np*validation_percentage), dtype=int )
    
    #load_file = "../Data/Germplasm_Data/Germplasm_Data_"+alleles_distr+str(Ng)+"_"+str(max_nonlinearity)+"_Plant"+plant_flag+".nc"
    load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(plant_flag)+".nc"
    ds1 = nc.Dataset(load_file)
    UU[:,:] = ds1["UU"][:,:]
    UUall[:,:] = ds1["UUall"][:,:]
    UUnonlinear[:,:] = ds1["UUnonlinear"][:,:]
    GGnonlinear[:,:] = ds1["GGnonlinear"][:,:]
    AAnonlinear[:,:] = ds1["AAnonlinear"][:,:]
    genomes[:,:,0] = ds1["genomes"][:,:]
    alleles[:,:,:,0] = ds1["alleles"][:,:,:]
    coeffs_min[:] = ds1["coeffs_min"][:]
    test_index[:] = ds1["test_index"][:]
    ds1.close()
    
    input_dim = int(10)
    flag_genome = np.zeros( (Np,input_dim),dtype=np.float64)
    # If the model is G2PNet load the appropriate trained neural network for the predictions.
    if (model_architecture == "G2PNet" and model == "G2PNet"):
        output_dim = int(5)
        models = []
        flag_output      = np.zeros( (ensemble_size,Np,output_dim),dtype=np.float64)
        T_mean = np.zeros( Np,dtype=np.float64)
        T_std  = np.zeros( Np,dtype=np.float64)
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        for nn in range(0,ensemble_size):
            model_name = "G2PNet_"+str(case_flag)+"_Plant"+str(plant_flag)+"_n"+str(nn)+"_i"+str(iter_number)
            model1 = tf.keras.models.load_model("../Neural_Nets/"+model_name+".h5",custom_objects={"attention_layer":attention_layer,"sucrose_activation":sucrose_activation,"auxin_activation":auxin_activation,"ick_activation":ick_activation,"cka_activation":cka_activation,"isl_activation":isl_activation,"is_activation":is_activation},compile=False)
            models.append(model1)
    elif (model_architecture == "FCN" and model == "G2PNet"):
        output_dim = int(1)
        models = []
        flag_output      = np.zeros( (ensemble_size,Np,output_dim),dtype=np.float64)
        T_mean = np.zeros( Np,dtype=np.float64)
        T_std  = np.zeros( Np,dtype=np.float64)
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        for nn in range(0,ensemble_size):
            model_name = "FCN_"+str(case_flag)+"_Plant"+str(plant_flag)+"_n"+str(nn)+"_i"+str(iter_number)
            model1 = tf.keras.models.load_model("../Neural_Nets/"+model_name+".h5",custom_objects={"attention_layer":attention_layer,"sucrose_activation":sucrose_activation,"auxin_activation":auxin_activation,"ick_activation":ick_activation,"cka_activation":cka_activation,"isl_activation":isl_activation,"is_activation":is_activation},compile=False)
            models.append(model1)
    
#    Phi0 = 0.0
#    Tcond = np.zeros((Ng,Ngt),dtype=float)
#    std_cond = np.zeros((Ng,Ngt),dtype=float)
#    Ncond = np.zeros((Ng,Ngt),dtype=int)
    #--------------------------------------------------------------------------
    #------------------------ 2. Carry out Nc breeding cycles -----------------
    for cycles in range(0,1): # Loop over breeding cycles.
        for pp in range(0,Np): # Loop over individual plants in population.
            A[pp,cycles] = coeffs_min[0]
            S[pp,cycles] = coeffs_min[1]
            for cc in range(0,Ncoeffs-2):
                Ucoeffs[pp,cc] = coeffs_min[cc+2]
            for gg in range(0,model_genes_per_coeff):
                A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                for kk in range(0,Ncoeffs-2):
                    Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
                    
            #for gg in range(0,Ng): # Loop over genes of plant pp. 
            #    genomes[pp,gg,cycles] = alleles[0,pp,gg,cycles] +alleles[1,pp,gg,cycles]
            #    flag_genome[pp,gg] = np.float64(genomes[pp,gg,cycles])
            flag_genome[pp,0] = A[pp,cycles]
            flag_genome[pp,1] = S[pp,cycles]
            flag_genome[pp,2] = Ucoeffs[pp,0]
            flag_genome[pp,3] = Ucoeffs[pp,1]
            for gg in range(4,10):
                flag_genome[pp,gg] = np.random.randn(1)
        
        if (model == "G2PNet"): # If the model is G2PNet, predict T using the genomes as input. 
            T_mean[:] = 0.0
            for nn in range(0,ensemble_size):
                flag_output[nn,:,:] = models[nn].predict(flag_genome)
                T_mean[:] += flag_output[nn,:,output_dim-1]
            T_mean[:] = T_mean[:]/float(ensemble_size)
            T_std[:] = 0.0
            for nn in range(0,ensemble_size):
                for pp in range(0,Np):
                    T_std[pp] += (flag_output[nn,pp,output_dim-1]-T_mean[pp])*(flag_output[nn,pp,output_dim-1]-T_mean[pp])
            T_std[:] = T_std[:]/float(ensemble_size-1)
        for pp in range(0,Np):
            
            #------------------------------------------------------------------
            #------------------ 2.a Predict T from current model --------------
            if (model == "G2PNet"): # If the model is G2PNet get T from the neural network directly. 
                T[pp,cycles]  = T_mean[pp]
            elif (model == "Mean" or model == "Ref"): # If the model is not G2PNet compute T from the evolution equations. 
                A[pp,cycles] = coeffs_min[0]
                S[pp,cycles] = coeffs_min[1]
                for cc in range(0,Ncoeffs-2):
                    Ucoeffs[pp,cc] = coeffs_min[cc+2]
                for gg in range(0,model_genes_per_coeff):
                    A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                    S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                    for kk in range(0,Ncoeffs-2):
                        Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
                
                if (max_nonlinearity > 0):
                    for nn in range(0,Nnonlin):
                        val_flag = 0.0
                        val_pos = int(0)
                        for pp2 in range(0,AAnonlinear[nn,0]):
                            val_pos += genomes[pp,GGnonlinear[nn,pp2],cycles]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                        val_flag = UUnonlinear[nn,val_pos]
                        if (GGnonlinear[nn,0] < genes_per_coeff):
                            A[pp,cycles] = A[pp,cycles] +val_flag
                        elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                            S[pp,cycles] = S[pp,cycles] +val_flag
                        elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                            Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                        else:
                            Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
                
                
                ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,:],case_flag,model)
                CK[pp,cycles] = cytokinin_eq(A[pp,cycles],S[pp,cycles],ck_input)
                SL[pp,cycles] = strigonlactone_eq(A[pp,cycles],S[pp,cycles],sl_input)
                I[pp,cycles]  = signal_integrator_eq(A[pp,cycles],S[pp,cycles],CK[pp,cycles],SL[pp,cycles],signal_input)
                T[pp,cycles]  = bud_outgrowth_time_eq(I[pp,cycles])+aleatoric_noise*np.random.randn(1)
                
            #------------------------------------------------------------------
            #--- 2.b Predict variables A,S,CK,SL,I from the reference model ---
            # This step is needed to verify the accuracy of the model as it 
            # picks what it considers optimal individuals to breed the next cycle. 
            # These variables are not used during the breeding process but only
            # for quantifying the accuracy of each model after the breeding has
            # concluded. 
            A[pp,cycles] = coeffs_min[0]
            S[pp,cycles] = coeffs_min[1]
            for cc in range(0,Ncoeffs-2):
                Ucoeffs[pp,cc] = coeffs_min[cc+2]
            for gg in range(0,genes_per_coeff):
                A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                for kk in range(0,Ncoeffs-2):
                    Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
            
            if (max_nonlinearity > 0):
                for nn in range(0,Nnonlin):
                    val_flag = 0.0
                    val_pos = int(0)
                    for pp2 in range(0,AAnonlinear[nn,0]):
                        val_pos += genomes[pp,GGnonlinear[nn,pp2],cycles]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                    val_flag = UUnonlinear[nn,val_pos]
                    
                    if (GGnonlinear[nn,0] < genes_per_coeff):
                        A[pp,cycles] = A[pp,cycles] +val_flag
                    elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                        S[pp,cycles] = S[pp,cycles] +val_flag
                    elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                        Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                    else:
                        Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
            
            
            ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,:],case_flag,"Ref")
            
            CK[pp,cycles] = cytokinin_eq(A[pp,cycles],S[pp,cycles],ck_input)
            SL[pp,cycles] = strigonlactone_eq(A[pp,cycles],S[pp,cycles],sl_input)
            I[pp,cycles]  = signal_integrator_eq(A[pp,cycles],S[pp,cycles],CK[pp,cycles],SL[pp,cycles],signal_input)
        
        
        
        if (breed_algo == "UQ"):
            if (model == "Mean" or model == "Ref"):
                T_std = np.zeros( Np,dtype=np.float64)+1.0
                models = []
                max_idx = UQ_Parent_Selection_Ref(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model)
                #max_idx = UQ_Parent_Selection_G2PNet(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,models,ensemble_size,aleatoric_noise)
            else:
                #max_idx = UQ_Parent_Selection(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model)
                max_idx = UQ_Parent_Selection_G2PNet(genomes,T_mean,T_std,cycles,Ngt,Ng,Np,Npi,models,ensemble_size,aleatoric_noise)
        
        
        
        #----------------------------------------------------------------------
        #------- 2.c Find the Npi best performers according to the model ------
        # Find the Npi best performers (they will be the parents for the next generation).
        if (breed_algo == "Naive"):
            CK_flag[:] = T[:,cycles]
            max_idx = np.argsort(CK_flag)[:] # Short the individual plants in ascending order of T.
        for pp in range(0,Npi):
            # Minimize trait
            genome_parents[pp,:] = genomes[max_idx[pp],:,cycles] # Pick the Npi plants with lowest T.
            for aa in range(0,Na):
                alleles_parents[aa,pp,:] = alleles[aa,max_idx[pp],:,cycles]
        
        
        
        #----------------------------------------------------------------------
        #------------------ 2.d Breed the new generation of plants ------------
        parents_flag = np.zeros(2,dtype=int)
        counter = 0
        for pp in range(0,Npi): # Loop over parents.
            parents_flag[0] = pp # make the first parent plant number pp.
            for pp2 in range(0,Np//Npi): # Each plant will breed Np//Npi offsprings as first parent. 
                parents_flag[1] = parents_flag[0] 
                while(parents_flag[1] == parents_flag[0]): # Ensure that the other parent is not the same plant
                    parents_flag[1] = np.random.randint(0,Npi)
                for gg in range(0,Ng): # Create genome of offspring.
                    aa1 = np.random.randint(0,2) # Randomly pick the first allele of gene gg from parent 0.
                    aa2 = np.random.randint(0,2) # Randomly pick the second allele of gene gg from parent 1.
                    alleles[0,counter,gg,cycles+1] = alleles_parents[aa1,parents_flag[0],gg]
                    alleles[1,counter,gg,cycles+1] = alleles_parents[aa2,parents_flag[1],gg]
                    genomes[counter,gg,cycles+1] = alleles[0,counter,gg,cycles+1]+alleles[1,counter,gg,cycles+1]
                counter = counter+1
    
    
    
    #--------------------------------------------------------------------------
    #--------------- 3. Save the results of the breeding process --------------
    train_genome_file = "../Data/"+model+"_Data/"+model+"_Data_"+case_flag+"_Plant"+plant_flag+".nc"
    #train_genome_file = mymodel.data_folder+"Train_Genomes_"+mymodel.case+"_"+mymodel.acq_function+"_i"+str(ii+1)+".nc"
    save_dataset = nc.Dataset(train_genome_file, 'w', format='NETCDF4')
    save_dataset.description = "Time-to-bud-outgrowth Data"
    save_dataset.history     = "Created_"+time.ctime(time.time())
    save_dataset.source      = "Breeding results from G2PNet code"
            
    save_dataset.createDimension('Np',Np)
    save_dataset.createDimension('Nc',Nc)
    save_dataset.createDimension('Ng',Ng)
    save_dataset.createDimension('Ngt',Ngt)
    save_dataset.createDimension('Na',Na)
    save_dataset.createDimension('max_nonlinearity',max_nonlinearity)
    save_dataset.createDimension('Nnonlin',Nnonlin)
    save_dataset.createDimension('nonlinearity_choices',nonlinearity_choices)
            
    genomes_nc = save_dataset.createVariable('A','f8',('Np','Nc'))
    genomes_nc.units = "Auxin"
    genomes_nc[:,:] = A[:,:]
    del genomes_nc
            
    genomes_nc = save_dataset.createVariable('S','f8',('Np','Nc'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:,:] = S[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('CK','f8',('Np','Nc'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:,:] = CK[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('SL','f8',('Np','Nc'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:,:] = SL[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('I','f8',('Np','Nc'))
    genomes_nc.units = "Signal"
    genomes_nc[:,:] = I[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('T','f8',('Np','Nc'))
    genomes_nc.units = "Outgrowth_Time"
    genomes_nc[:,:] = T[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('genomes','f8',('Np','Ng','Nc'))
    genomes_nc.units = "Genomes"
    genomes_nc[:,:,:] = genomes[:,:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UU','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UU[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUall','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUall[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUnonlinear','f8',('Nnonlin','nonlinearity_choices'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('GGnonlinear','f8',('Nnonlin','max_nonlinearity'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = GGnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('AAnonlinear','f8',('Nnonlin','Na'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = AAnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('alleles','f8',('Na','Np','Ng','Nc'))
    genomes_nc.units = "Alleles"
    genomes_nc[:,:,:,:] = alleles[:,:,:,:]
    del genomes_nc
    
    save_dataset.close()
    
    return
    

def Breeding_Process(user_input,model):
    
    #--------------------------------------------------------------------------
    #--------------- 1. Initialize data for breeding process ------------------
    case_flag = user_input[0] # Name of case given by user. 
    plant_flag = user_input[1] # Identification number of individual run. 
    Np  = int(user_input[2]) # Total number of individuals per cycle. 
    Ng  = int(user_input[3]) # Total number of genes in genome. 
    Nc  = int(user_input[4]) # Total number of breeding cycles. 
    Npi = int(user_input[5]) # Number of parents to be chosen every cycle. 
    Na  = int(user_input[6]) # Total number of alleles per gene. 
    Ngt = int(user_input[7]) # Total possible genotypes per gene. 
    Ncoeffs = int(user_input[8]) # Number of coefficients directly affected by genes. 
    mean_genes_per_coeff = int(user_input[9]) # Number of genes per coefficient known by the mean model. 
    ensemble_size = int(user_input[10])
    breed_algo = user_input[11]
    aleatoric_noise = float(user_input[12])
    iter_number = int(user_input[13])
    model_architecture = user_input[14]
    alleles_distr = user_input[15]
    Nchrome = int(user_input[16])
    max_nonlinearity = int(user_input[17])
    Nnonlin = int(user_input[18])
    training_percentage = float(user_input[19])
    validation_percentage = float(user_input[20])
    testing_percentage = float(user_input[21])
    
    nonlinearity_choices = pow(Ngt,max_nonlinearity)
    
    genes_per_coeff = int(Ng//Ncoeffs) # Number of genes per coefficient in the reference model. 
    
    model_genes_per_coeff = genes_per_coeff
    if (model == "Mean"):
        model_genes_per_coeff = mean_genes_per_coeff
    elif(model == "Ref"):
        model_genes_per_coeff = genes_per_coeff
    
    genomes = np.zeros( (Np,Ng,Nc),dtype=int )
    alleles = np.zeros( (Na,Np,Ng,Nc),dtype=int )
    genome_parents = np.zeros((Npi,Ng),dtype=int)
    alleles_parents = np.zeros((Na,Npi,Ng),dtype=int)
    UU = np.zeros( (Ngt,Ng), dtype=float )
    UUall = np.zeros( (Ngt,Ng), dtype=float )
    coeffs_min = np.zeros(Ncoeffs,dtype=float)
    
    GGnonlinear = np.zeros((Nnonlin,max_nonlinearity),dtype=int)
    UUnonlinear = np.zeros((Nnonlin,nonlinearity_choices),dtype=float)
    AAnonlinear = np.zeros((Nnonlin,2),dtype=int)
    
    A = np.zeros( (Np,Nc),dtype=float)
    S = np.zeros( (Np,Nc),dtype=float)
    CK = np.zeros( (Np,Nc),dtype=float)
    CK_flag = np.zeros(Np,dtype=float)
    SL = np.zeros( (Np,Nc),dtype=float)
    I  = np.zeros( (Np,Nc),dtype=float)
    T  = np.zeros( (Np,Nc),dtype=float)
    Ucoeffs = np.zeros( (Np,Ncoeffs-2), dtype=float )

    test_index = np.zeros( Np-round(Np*training_percentage)-round(Np*validation_percentage), dtype=int )
    
    #load_file = "../Data/Germplasm_Data/Germplasm_Data_"+alleles_distr+str(Ng)+"_"+str(max_nonlinearity)+"_Plant"+plant_flag+".nc"
    load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(plant_flag)+".nc"
    ds1 = nc.Dataset(load_file)
    UU[:,:] = ds1["UU"][:,:]
    UUall[:,:] = ds1["UUall"][:,:]
    UUnonlinear[:,:] = ds1["UUnonlinear"][:,:]
    GGnonlinear[:,:] = ds1["GGnonlinear"][:,:]
    AAnonlinear[:,:] = ds1["AAnonlinear"][:,:]
    genomes[:,:,0] = ds1["genomes"][:,:]
    alleles[:,:,:,0] = ds1["alleles"][:,:,:]
    coeffs_min[:] = ds1["coeffs_min"][:]
    test_index[:] = ds1['test_index'][:]
    ds1.close()
    
    input_dim = Ng
    flag_genome = np.zeros( (Np,input_dim),dtype=np.float64)
    # If the model is G2PNet load the appropriate trained neural network for the predictions.
    if (model_architecture == "GNN" and model == "G2PNet"):
        output_dim = int(1)
        models = []
        flag_output      = np.zeros( (ensemble_size,Np,output_dim),dtype=np.float64)
        T_mean = np.zeros( Np,dtype=np.float64)
        T_std  = np.zeros( Np,dtype=np.float64)
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        for nn in range(0,ensemble_size):
            model_name = "GNN_"+str(case_flag)+"_Plant"+str(plant_flag)+"_n"+str(nn)+"_i"+str(iter_number)
            model1 = tf.keras.models.load_model("../Neural_Nets/"+model_name+".h5",custom_objects={"attention_layer":attention_layer,"sucrose_activation":sucrose_activation,"auxin_activation":auxin_activation,"ick_activation":ick_activation,"cka_activation":cka_activation,"isl_activation":isl_activation,"is_activation":is_activation},compile=False)
            models.append(model1)
    elif (model_architecture == "FCN" and model == "G2PNet"):
        output_dim = int(1)
        models = []
        flag_output      = np.zeros( (ensemble_size,Np,output_dim),dtype=np.float64)
        T_mean = np.zeros( Np,dtype=np.float64)
        T_std  = np.zeros( Np,dtype=np.float64)
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        for nn in range(0,ensemble_size):
            model_name = "FCN_"+str(case_flag)+"_Plant"+str(plant_flag)+"_n"+str(nn)+"_i"+str(iter_number)
            model1 = tf.keras.models.load_model("../Neural_Nets/"+model_name+".h5",custom_objects={"attention_layer":attention_layer,"sucrose_activation":sucrose_activation,"auxin_activation":auxin_activation,"ick_activation":ick_activation,"cka_activation":cka_activation,"isl_activation":isl_activation,"is_activation":is_activation},compile=False)
            models.append(model1)
    elif (model_architecture == "LR" and model == "G2PNet"):
        output_dim = int(1)
        models = []
        flag_output      = np.zeros( (ensemble_size,Np,output_dim),dtype=np.float64)
        T_mean = np.zeros( Np,dtype=np.float64)
        T_std  = np.zeros( Np,dtype=np.float64)
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        for nn in range(0,ensemble_size):
            model_name = "LR_"+str(case_flag)+"_Plant"+str(plant_flag)+"_n"+str(nn)+"_i"+str(iter_number)
            model1 = tf.keras.models.load_model("../Neural_Nets/"+model_name+".h5",custom_objects={"attention_layer":attention_layer,"sucrose_activation":sucrose_activation,"auxin_activation":auxin_activation,"ick_activation":ick_activation,"cka_activation":cka_activation,"isl_activation":isl_activation,"is_activation":is_activation},compile=False)
            models.append(model1)
    
#    Phi0 = 0.0
#    Tcond = np.zeros((Ng,Ngt),dtype=float)
#    std_cond = np.zeros((Ng,Ngt),dtype=float)
#    Ncond = np.zeros((Ng,Ngt),dtype=int)
    #--------------------------------------------------------------------------
    #------------------------ 2. Carry out Nc breeding cycles -----------------
    for cycles in range(0,1): # Loop over breeding cycles.
        for pp in range(0,Np): # Loop over individual plants in population.
            A[pp,cycles] = coeffs_min[0]
            S[pp,cycles] = coeffs_min[1]
            for cc in range(0,Ncoeffs-2):
                Ucoeffs[pp,cc] = coeffs_min[cc+2]
            for gg in range(0,model_genes_per_coeff):
                A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                for kk in range(0,Ncoeffs-2):
                    Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
                    
            for gg in range(0,Ng): # Loop over genes of plant pp. 
                #genomes[pp,gg,cycles] = alleles[0,pp,gg,cycles] +alleles[1,pp,gg,cycles]
                flag_genome[pp,gg] = np.float64(genomes[pp,gg,cycles])
            #flag_genome[pp,0] = A[pp,cycles]
            #flag_genome[pp,1] = S[pp,cycles]
            #flag_genome[pp,2] = Ucoeffs[pp,0]
            #flag_genome[pp,3] = Ucoeffs[pp,1]
            #for gg in range(4,10):
            #    flag_genome[pp,gg] = np.random.randn(1)
        
        if (model == "G2PNet"): # If the model is G2PNet, predict T using the genomes as input. 
            T_mean[:] = 0.0
            for nn in range(0,ensemble_size):
                flag_output[nn,:,:] = models[nn].predict(flag_genome,verbose=0)
                T_mean[:] += flag_output[nn,:,output_dim-1]
            T_mean[:] = T_mean[:]/float(ensemble_size)
            T_std[:] = 0.0
            for nn in range(0,ensemble_size):
                for pp in range(0,Np):
                    T_std[pp] += (flag_output[nn,pp,output_dim-1]-T_mean[pp])*(flag_output[nn,pp,output_dim-1]-T_mean[pp])
            #T_std[:] = T_std[:]/float(ensemble_size-1)
        for pp in range(0,Np):
            
            #------------------------------------------------------------------
            #------------------ 2.a Predict T from current model --------------
            if (model == "G2PNet"): # If the model is G2PNet get T from the neural network directly. 
                T[pp,cycles]  = T_mean[pp]
            elif (model == "Mean" or model == "Ref"): # If the model is not G2PNet compute T from the evolution equations. 
                A[pp,cycles] = coeffs_min[0]
                S[pp,cycles] = coeffs_min[1]
                for cc in range(0,Ncoeffs-2):
                    Ucoeffs[pp,cc] = coeffs_min[cc+2]
                for gg in range(0,model_genes_per_coeff):
                    A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                    S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                    for kk in range(0,Ncoeffs-2):
                        Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
                
                if (max_nonlinearity > 0):
                    for nn in range(0,Nnonlin):
                        val_flag = 0.0
                        val_pos = int(0)
                        for pp2 in range(0,AAnonlinear[nn,0]):
                            val_pos += genomes[pp,GGnonlinear[nn,pp2],cycles]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                        val_flag = UUnonlinear[nn,val_pos]
                        if (GGnonlinear[nn,0] < genes_per_coeff):
                            A[pp,cycles] = A[pp,cycles] +val_flag
                        elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                            S[pp,cycles] = S[pp,cycles] +val_flag
                        elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                            Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                        else:
                            Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
                
                
                ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,:],case_flag,model)
                CK[pp,cycles] = cytokinin_eq(A[pp,cycles],S[pp,cycles],ck_input)
                SL[pp,cycles] = strigonlactone_eq(A[pp,cycles],S[pp,cycles],sl_input)
                I[pp,cycles]  = signal_integrator_eq(A[pp,cycles],S[pp,cycles],CK[pp,cycles],SL[pp,cycles],signal_input)
                #T[pp,cycles]  = bud_outgrowth_time_eq(I[pp,cycles])+aleatoric_noise*np.random.randn(1)
                T[pp,cycles]  = bud_outgrowth_time_eq(I[pp,cycles])
                
            #------------------------------------------------------------------
            #--- 2.b Predict variables A,S,CK,SL,I from the reference model ---
            # This step is needed to verify the accuracy of the model as it 
            # picks what it considers optimal individuals to breed the next cycle. 
            # These variables are not used during the breeding process but only
            # for quantifying the accuracy of each model after the breeding has
            # concluded. 
            A[pp,cycles] = coeffs_min[0]
            S[pp,cycles] = coeffs_min[1]
            for cc in range(0,Ncoeffs-2):
                Ucoeffs[pp,cc] = coeffs_min[cc+2]
            for gg in range(0,genes_per_coeff):
                A[pp,cycles] = A[pp,cycles] +UU[genomes[pp,gg,cycles],gg]
                S[pp,cycles] = S[pp,cycles] +UU[genomes[pp,gg+genes_per_coeff,cycles],gg+genes_per_coeff]
                for kk in range(0,Ncoeffs-2):
                    Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff,cycles],gg+(kk+2)*genes_per_coeff]
            
            if (max_nonlinearity > 0):
                for nn in range(0,Nnonlin):
                    val_flag = 0.0
                    val_pos = int(0)
                    for pp2 in range(0,AAnonlinear[nn,0]):
                        val_pos += genomes[pp,GGnonlinear[nn,pp2],cycles]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                    val_flag = UUnonlinear[nn,val_pos]
                    
                    if (GGnonlinear[nn,0] < genes_per_coeff):
                        A[pp,cycles] = A[pp,cycles] +val_flag
                    elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                        S[pp,cycles] = S[pp,cycles] +val_flag
                    elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                        Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                    else:
                        Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
            
            
            ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,:],case_flag,"Ref")
            
            CK[pp,cycles] = cytokinin_eq(A[pp,cycles],S[pp,cycles],ck_input)
            SL[pp,cycles] = strigonlactone_eq(A[pp,cycles],S[pp,cycles],sl_input)
            I[pp,cycles]  = signal_integrator_eq(A[pp,cycles],S[pp,cycles],CK[pp,cycles],SL[pp,cycles],signal_input)
        
        
        
        if (breed_algo == "UQ"):
            if (model == "Mean" or model == "Ref"):
                T_std = np.zeros( Np,dtype=np.float64)+1.0
                models = []
                max_idx = UQ_Parent_Selection_Ref(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model)
                #max_idx = UQ_Parent_Selection_G2PNet(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,models,ensemble_size,aleatoric_noise)
            else:
                #max_idx = UQ_Parent_Selection(genomes,T[:,cycles],T_std,cycles,Ngt,Ng,Np,Npi,UU,UUall,GGnonlinear,UUnonlinear,AAnonlinear,max_nonlinearity,Nnonlin,models,ensemble_size,aleatoric_noise,model)
                max_idx = UQ_Parent_Selection_G2PNet(genomes,T_mean,T_std,cycles,Ngt,Ng,Np,Npi,models,ensemble_size,aleatoric_noise)
        
        
        
        #----------------------------------------------------------------------
        #------- 2.c Find the Npi best performers according to the model ------
        # Find the Npi best performers (they will be the parents for the next generation).
        if (breed_algo == "Naive"):
            CK_flag[:] = T[:,cycles]
            max_idx = np.argsort(CK_flag)[:] # Short the individual plants in ascending order of T.
        for pp in range(0,Npi):
            # Minimize trait
            genome_parents[pp,:] = genomes[max_idx[pp],:,cycles] # Pick the Npi plants with lowest T.
            for aa in range(0,Na):
                alleles_parents[aa,pp,:] = alleles[aa,max_idx[pp],:,cycles]
        
        
        
        #----------------------------------------------------------------------
        #------------------ 2.d Breed the new generation of plants ------------
        parents_flag = np.zeros(2,dtype=int)
        counter = 0
        for pp in range(0,Npi): # Loop over parents.
            parents_flag[0] = pp # make the first parent plant number pp.
            for pp2 in range(0,Np//Npi): # Each plant will breed Np//Npi offsprings as first parent. 
                parents_flag[1] = parents_flag[0] 
                while(parents_flag[1] == parents_flag[0]): # Ensure that the other parent is not the same plant
                    parents_flag[1] = np.random.randint(0,Npi)
                for gg in range(0,Ng): # Create genome of offspring.
                    aa1 = np.random.randint(0,2) # Randomly pick the first allele of gene gg from parent 0.
                    aa2 = np.random.randint(0,2) # Randomly pick the second allele of gene gg from parent 1.
                    alleles[0,counter,gg,cycles+1] = alleles_parents[aa1,parents_flag[0],gg]
                    alleles[1,counter,gg,cycles+1] = alleles_parents[aa2,parents_flag[1],gg]
                    genomes[counter,gg,cycles+1] = alleles[0,counter,gg,cycles+1]+alleles[1,counter,gg,cycles+1]
                counter = counter+1
    
    
    
    #--------------------------------------------------------------------------
    #--------------- 3. Save the results of the breeding process --------------
    train_genome_file = "../Data/Model_Data/"+model_architecture+"_Data_"+case_flag+"_Plant"+plant_flag+".nc"
    #train_genome_file = mymodel.data_folder+"Train_Genomes_"+mymodel.case+"_"+mymodel.acq_function+"_i"+str(ii+1)+".nc"
    save_dataset = nc.Dataset(train_genome_file, 'w', format='NETCDF4')
    save_dataset.description = "Time-to-bud-outgrowth Data"
    save_dataset.history     = "Created_"+time.ctime(time.time())
    save_dataset.source      = "Breeding results from G2PNet code"
            
    save_dataset.createDimension('Np',Np)
    save_dataset.createDimension('Nc',Nc)
    save_dataset.createDimension('Ng',Ng)
    save_dataset.createDimension('Ngt',Ngt)
    save_dataset.createDimension('Na',Na)
    save_dataset.createDimension('max_nonlinearity',max_nonlinearity)
    save_dataset.createDimension('Nnonlin',Nnonlin)
    save_dataset.createDimension('nonlinearity_choices',nonlinearity_choices)
            
    genomes_nc = save_dataset.createVariable('A','f8',('Np','Nc'))
    genomes_nc.units = "Auxin"
    genomes_nc[:,:] = A[:,:]
    del genomes_nc
            
    genomes_nc = save_dataset.createVariable('S','f8',('Np','Nc'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:,:] = S[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('CK','f8',('Np','Nc'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:,:] = CK[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('SL','f8',('Np','Nc'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:,:] = SL[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('I','f8',('Np','Nc'))
    genomes_nc.units = "Signal"
    genomes_nc[:,:] = I[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('T','f8',('Np','Nc'))
    genomes_nc.units = "Outgrowth_Time"
    genomes_nc[:,:] = T[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('genomes','f8',('Np','Ng','Nc'))
    genomes_nc.units = "Genomes"
    genomes_nc[:,:,:] = genomes[:,:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UU','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UU[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUall','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUall[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUnonlinear','f8',('Nnonlin','nonlinearity_choices'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('GGnonlinear','f8',('Nnonlin','max_nonlinearity'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = GGnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('AAnonlinear','f8',('Nnonlin','Na'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = AAnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('alleles','f8',('Na','Np','Ng','Nc'))
    genomes_nc.units = "Alleles"
    genomes_nc[:,:,:,:] = alleles[:,:,:,:]
    del genomes_nc
    
    save_dataset.close()
    
    return











if __name__ == "__main__":
    
    user_input = []
    user_input.append(sys.argv[1])
    user_input.append(sys.argv[2])
    user_input.append(sys.argv[3])
    user_input.append(sys.argv[4])
    user_input.append(sys.argv[5])
    user_input.append(sys.argv[6])
    user_input.append(sys.argv[7])
    user_input.append(sys.argv[8])
    user_input.append(sys.argv[9])
    user_input.append(sys.argv[10])
    user_input.append(sys.argv[11])
    user_input.append("Naive")
    user_input.append(sys.argv[13])
    user_input.append(sys.argv[14])
    user_input.append(sys.argv[15])
    user_input.append(sys.argv[16])
    user_input.append(sys.argv[17])
    user_input.append(sys.argv[18])
    user_input.append(sys.argv[19])
    
    Breeding_Process(user_input,"Ref")
    #user_input[11] = "Naive"
    #user_input[11] = "UQ"
    #Breeding_Process(user_input,"Mean")
    user_input[11] = sys.argv[12]
    #user_input[11] = "UQ"
    Breeding_Process(user_input,"GNN")
        
    exit()

