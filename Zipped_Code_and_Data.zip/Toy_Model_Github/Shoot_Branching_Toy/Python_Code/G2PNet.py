#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import sys # Imported to read input from command line.
import os  # Imported to check that appropriate folders exist (and create them if not).
import numpy as np
import scipy.io as sio
#import matplotlib.pyplot as plt
import tensorflow as tf
tf.keras.backend.set_floatx('float64')
#from scipy.io import netcdf
import netCDF4 as nc
#import time
#import cartopy.crs as ccrs


from G2PNet_Architecture import get_model
from G2PNet_Architecture import param_loss_yield

from G2P_Equations import cytokinin_eq
from G2P_Equations import strigonlactone_eq
from G2P_Equations import signal_integrator_eq
from G2P_Equations import bud_outgrowth_time_eq

from G2P_Model_Cases import Bertheloot_coeffs

def G2PNet_Train(user_input):
    
    #--------------------------------------------------------------------------
    #---------------------- 0. Obtain input data ------------------------------
    case_flag = user_input[0]
    plant_flag = user_input[1]
    Np  = int(user_input[2])
    Ng  = int(user_input[3])
    Nc  = int(user_input[4])
    Npi = int(user_input[5])
    Na  = int(user_input[6])
    Ngt = int(user_input[7])
    Ncoeffs = int(user_input[8])
    genes_per_coeff = int(Ng//Ncoeffs)
    
    train_epochs = int(user_input[9])
    train_batch  = int(user_input[10])
    validation_percentage = float(user_input[11])
    model_architecture = user_input[12]
    model_loss = user_input[13]
    model_optimizer = user_input[14]
    aleatoric_noise = float(user_input[15])
    model_number = int(user_input[16])
    iter_number  = int(user_input[17])
    alleles_distr = user_input[18]
    Nchrome = int(user_input[19])
    max_nonlinearity = int(user_input[20])
    Nnonlin = int(user_input[21])
    training_percentage = float(user_input[23])
    validation_percentage = float(user_input[24])
    testing_percentage = float(user_input[25])
    input_nodes = user_input[26]
    output_nodes = user_input[27]
    output_variable = user_input[28]
    
    nonlinearity_choices = pow(Ngt,max_nonlinearity)
    
    GGnonlinear = np.zeros((Nnonlin,max_nonlinearity),dtype=int)
    UUnonlinear = np.zeros((Nnonlin,nonlinearity_choices),dtype=float)
    AAnonlinear = np.zeros((Nnonlin,2),dtype=int)
    
    UU = np.zeros((Ngt,Ng),dtype=float)
    genomes = np.zeros( (Np,Ng) ,dtype=int)
    A  = np.zeros(Np,dtype=float)
    S  = np.zeros(Np,dtype=float)
    SL = np.zeros(Np,dtype=float)
    CK = np.zeros(Np,dtype=float)
    I  = np.zeros(Np,dtype=float)
    T  = np.zeros(Np,dtype=float)
    coeffs_min = np.zeros(Ncoeffs,dtype=float)
    coeffs_max = np.zeros(Ncoeffs,dtype=float)
    Ucoeffs = np.zeros( (Np,Ncoeffs), dtype=float )

    Np_train = round(Np*training_percentage)
    Np_val   = round(Np*validation_percentage)

    train_index = np.zeros(Np_train,dtype=int)
    val_index   = np.zeros(Np_val,dtype=int)
    
    
    #--------------------------------------------------------------------------
    #------------------ 1. Load initial germplasm data ------------------------
    load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(plant_flag)+".nc"
    ds1 = nc.Dataset(load_file)
    genomes[:,:] = ds1["genomes"][:,:]
    UU[:,:] = ds1["UU"][:,:]
    UUnonlinear[:,:] = ds1["UUnonlinear"][:,:]
    GGnonlinear[:,:] = ds1["GGnonlinear"][:,:]
    AAnonlinear[:,:] = ds1["AAnonlinear"][:,:]
    coeffs_min[:] = ds1["coeffs_min"][:]
    coeffs_max[:] = ds1["coeffs_max"][:]
    T[:]  = ds1["T"][:]
    A[:]  = ds1["A"][:]
    S[:]  = ds1["S"][:]
    CK[:] = ds1["CK"][:]
    SL[:] = ds1["SL"][:]
    train_index[:] = ds1["train_index"][:]
    val_index[:]   = ds1["val_index"][:]
    ds1.close()
    
    #--------------------------------------------------------------------------
    #------------ 2. Create input/output training variables -------------------
    train_samples = Np
    input_dim  = Ng
    if (model_architecture=="GNN"):
        output_dim = int(1)
    elif (model_architecture=="FCN"):
        output_dim = int(1)
    elif (model_architecture=="LR"):
        output_dim = int(1)
    input_train  = np.zeros((train_samples,input_dim),dtype=float)
    output_train = np.zeros((train_samples,output_dim),dtype=float)
    
    for cycles in range(0,1):
        for pp in range(0,Np): # Loop over individual plants. 
            for gg in range(0,Ng): # Loop over genes inside a genome. 
                # Load as input of the NN the genomes of each individual plant, as float64. 
                input_train[pp,gg] = float(genomes[pp,gg]) # genome is int64 initially. 
        
        
            for cc in range(0,Ncoeffs): # Loop over coefficients directly affected by genes. 
                Ucoeffs[pp,cc] = coeffs_min[cc] # Initialize the coefficient by its minimum possible value. 
                for gg in range(0,genes_per_coeff): # Loop over genes that affect coefficient number cc. 
                    gcounter = gg+genes_per_coeff*cc # Calculate the position of the next coefficient that affects coefficient cc. 
                    Ucoeffs[pp,cc] = Ucoeffs[pp,cc] +UU[genomes[pp,gcounter],gcounter] # Add the effect gene gcounter has on coeffient cc. 
            
            
            if (max_nonlinearity > 0):
                for nn in range(0,Nnonlin):
                    val_flag = 0.0
                    val_pos = int(0)
                    for pp2 in range(0,AAnonlinear[nn,0]):
                        val_pos += genomes[pp,GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                    val_flag = UUnonlinear[nn,val_pos]
                    
                    if (GGnonlinear[nn,0] < genes_per_coeff):
                        Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                    elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                        Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
                    elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                        Ucoeffs[pp,2] = Ucoeffs[pp,2] +val_flag
                    else:
                        Ucoeffs[pp,3] = Ucoeffs[pp,3] +val_flag
            
            
            
            
            
        
            # Grab the coefficients for the evolution equations according to the case we run.
            ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,2:4],case_flag,"G2PNet")
            
            CK[pp] = cytokinin_eq(Ucoeffs[pp,0],Ucoeffs[pp,1],ck_input) # Compute cytokinin. 
            SL[pp] = strigonlactone_eq(Ucoeffs[pp,0],Ucoeffs[pp,1],sl_input) # Compute stringolactones. 
            I[pp]  = signal_integrator_eq(Ucoeffs[pp,0],Ucoeffs[pp,1],CK[pp],SL[pp],signal_input) # Compute the signal index. 
            T[pp]  = bud_outgrowth_time_eq(I[pp]) # Compute time to bud outgrowth for individual plant pp. 
        
        
            if (model_architecture=="FCN" or model_architecture == "LR" or model_architecture == "GNN"):
                #output_train[pstart_vec[pp+Np*cycles],0] = T[pp]
                #output_train[pstart_vec[pp+Np*cycles],1] = 1.0
                output_train[pp,0] = T[pp]+aleatoric_noise*np.random.randn(1)

            #elif (model_architecture=="LR"):
            #    output_train[pstart_vec[pp+Np*cycles],0] = T[pp]
            #    output_train[pstart_vec[pp+Np*cycles],1] = 1.0
            
            #elif (model_architecture=="GNN"):
                #output_train[pstart_vec[pp+Np*cycles],0] = T[pp]
                #output_train[pstart_vec[pp+Np*cycles],1] = 1.0
            #    
            #    output_train[pstart_vec[pp+Np*cycles],0] = A[pp]
            #    output_train[pstart_vec[pp+Np*cycles],1] = S[pp]
            #    output_train[pstart_vec[pp+Np*cycles],2] = CK[pp]
            #    output_train[pstart_vec[pp+Np*cycles],3] = SL[pp]
            #    output_train[pstart_vec[pp+Np*cycles],4] = T[pp]
            #    # These terms are here for a likelihood-weighted loss function. Setting them to 1 makes the loss MSE. 
            #    output_train[pstart_vec[pp+Np*cycles],5] = 1.0
            #    output_train[pstart_vec[pp+Np*cycles],6] = 1.0
            #    output_train[pstart_vec[pp+Np*cycles],7] = 1.0
            #    output_train[pstart_vec[pp+Np*cycles],8] = 1.0
            #    output_train[pstart_vec[pp+Np*cycles],9] = 1.0
        
            
        
        # 1/(1+0.96*x) = 0.51-0.25*(x-1) -0.122(x-1)^2 +... around x=1
        # 1/(1+0.96*x) = 1 -0.96*x +0.9216*x^2 -0.884736*x^3 around x=0
        # x^2/(a+b*x^2) = x^2/a -b*x^4/a^2 +b^2*x^6/a^3 +...
        # 1/(1+k3*x^2) = 1-k3*x^2+k3^2*x^4 +... around x = 0
        # 1/(1+k3*x^2) = 1/(k3+1) -2*k3*(x-1)/(k3+1)^2+... around x = 1
        
        
        
    
    #--------------------------------------------------------------------------
    #------------------ 3. Train & save neural network ------------------------
    os.environ['KMP_DUPLICATE_LIB_OK']='True'
    # Name the model.
    model_name = model_architecture+"_"+str(case_flag)+"_Plant"+str(plant_flag)
    train_end   = round(train_samples*(1.0-validation_percentage)) # Train on 95% of samples and validate on the rest 5%. 
    model1 = get_model(input_dim,output_dim,model_architecture,case_flag,input_nodes,output_nodes,output_variable) # Grab the correct neural network architecture. 
    #model1.compile(loss=model_loss,optimizer=model_optimizer) # Compile the neural network with chosen loss function and optimizer.
    weights_folder = "../Neural_Nets/Weights_"+model_name+"_n"+str(model_number)
    if not os.path.exists(weights_folder):
        os.makedirs(weights_folder)
    #filepath_name = weights_folder+'/Weights_Epoch{epoch:05d}_Batch{batch:05d}.hdf5'
    #checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath_name,verbose=0,save_best_only=False,save_weights_only=True,mode='auto',save_freq=100,options=None,initial_value_threshold=None)
    filepath_name = weights_folder+'/Weights_Epoch{epoch:05d}.hdf5'
    save_best_model = SaveBestModel()
    #checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath_name,verbose=0,save_best_only=False,save_weights_only=True,mode='auto',period=500,options=None,initial_value_threshold=None)
    model1.compile(loss=param_loss_yield(output_dim),optimizer=model_optimizer)
    # Train the neural network. 
    hist1 = model1.fit(input_train[train_index[:],:], output_train[train_index[:],:], batch_size=train_batch, epochs=train_epochs, validation_data=(input_train[val_index[:],:],output_train[val_index[:],:]), callbacks=[save_best_model],verbose=0)
    # Save the trained neural network. 
    model1.set_weights(save_best_model.best_weights)
    model1.save("../Neural_Nets/"+model_name+"_n"+str(model_number)+"_i"+str(iter_number)+".h5")
    # Save training and validation loss history in a separate .mat file.
    sio.savemat("../Neural_Nets/Training_History_"+model_name+"_n"+str(model_number)+"_i"+str(iter_number)+".mat",{
                    "hist1":hist1.history},format='5',do_compression=True)
    
    #model_weights = model1.get_weights()
    #Wga  = model_weights[0]
    #Vga  = model_weights[1]
    #Wgs  = model_weights[2]
    #Vgs  = model_weights[3]
    #Wgck = model_weights[4]
    #Vgck = model_weights[5]
    #Wgsl = model_weights[6]
    #Vgsl = model_weights[7]
    #
    #sio.savemat("../Neural_Nets/Weights_Final_"+model_name+"_n"+str(model_number)+"_i"+str(iter_number)+".mat",{
    #                "Wga":Wga,"Wgs":Wgs,"Wgck":Wgck,"Wgsl":Wgsl,"Vga":Vga,"Vgs":Vgs,"Vgck":Vgck,"Vgsl":Vgsl,"Uref":UU},format='5',do_compression=True)
    
    del input_train, output_train # clear input/output data from memory. 
    
    return



class SaveBestModel(tf.keras.callbacks.Callback):
    def __init__(self, save_best_metric='val_loss', this_max=False):
        self.save_best_metric = save_best_metric
        self.max = this_max
        if this_max:
            self.best = float('-inf')
        else:
            self.best = float('inf')

    def on_epoch_end(self, epoch, logs=None):
        metric_value = logs[self.save_best_metric]
        if self.max:
            if metric_value > self.best:
                self.best = metric_value
                self.best_weights = self.model.get_weights()

        else:
            if metric_value < self.best:
                self.best = metric_value
                self.best_weights= self.model.get_weights()


if __name__ == "__main__":
    
    user_input = []
    user_input.append(sys.argv[1])
    user_input.append(sys.argv[2])
    user_input.append(sys.argv[3])
    user_input.append(sys.argv[4])
    user_input.append(sys.argv[5])
    user_input.append(sys.argv[6])
    user_input.append(sys.argv[7])
    user_input.append(sys.argv[8])
    user_input.append(sys.argv[9])
    user_input.append(sys.argv[10]) # Training epochs
    user_input.append(sys.argv[11]) # Batch size during training
    user_input.append(sys.argv[12]) # Validation percentage of initial data. 
    user_input.append(sys.argv[13]) # Model Architecture
    user_input.append(sys.argv[14]) # Loss function
    user_input.append(sys.argv[15]) # Optimizer
    user_input.append(sys.argv[16]) # Number of neural network in the ensemble.
    user_input.append(sys.argv[17])
    user_input.append(sys.argv[18])
    user_input.append(sys.argv[19])
    user_input.append(sys.argv[20])
    user_input.append(sys.argv[21])
    user_input.append(sys.argv[22])
    G2PNet_Train(user_input)
    
    
    exit()


