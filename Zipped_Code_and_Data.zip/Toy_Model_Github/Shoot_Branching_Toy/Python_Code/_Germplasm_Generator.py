#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
An implementation of the Bertheloot et al 2020 model.

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
import numpy as np
#import scipy.io as sio
#from scipy.interpolate import griddata
#import os
import time
import netCDF4 as nc
import random

from G2P_Equations import cytokinin_eq
from G2P_Equations import strigonlactone_eq
from G2P_Equations import signal_integrator_eq
from G2P_Equations import bud_outgrowth_time_eq

from G2P_Model_Cases import Bertheloot_coeffs


def Germplasm_Generator(user_input):
    
    #--------------------------------------------------------------------------
    #---------------------- 0. Obtain input data ------------------------------
    Np = user_input[0] # Total number of individual plants.
    Ng = user_input[1] # Total number of genes in genome. 
    Na = user_input[2] # Total number of different alleles per gene. 
    Ngt = user_input[3] # Total number of genotypes per gene. 
    Ncoeffs = user_input[4] # Total number of coefficient directly affected by the genome. 
    coeffs_min = user_input[5]
    coeffs_max = user_input[6]
    case_flag  = user_input[7]
    plant_flag = user_input[8]
    alleles_freqs = user_input[9]
    genes_per_coeff = int(Ng//Ncoeffs)
    aleatoric_noise = float(user_input[10])
    alleles_distr = user_input[11]
    Nchrome = int(user_input[12])
    max_nonlinearity = int(user_input[13])
    Nnonlin = int(user_input[14])
    training_percentage = float(user_input[15])
    validation_percentage = float(user_input[16])
    testing_percentage = float(user_input[17])
    genes_per_chrome = Ng//Nchrome
    nonlinearity_choices = pow(Ngt,max_nonlinearity)
    
    
    #--------------------------------------------------------------------------
    #--------- 1. Start by sampling independent effects for all genes ---------
    min_cutoff = np.zeros(2*Ncoeffs,dtype=int)
    genomes = np.zeros( (Np,Ng),dtype=int )
    alleles = np.zeros( (Na,Np,Ng),dtype=int )
    UU = np.zeros( (Ngt,Ng), dtype=float )
    UUnon = [np.zeros((Ngt,Ng),dtype=float) for ii in range(2,max_nonlinearity+1)]
    UUall = np.zeros( (Ngt,Ng), dtype=float )
    sum_flag = np.zeros(Ncoeffs,dtype=float)
    for cc in range(0,Ncoeffs): # Loop over coefficient directly effected by the genome. 
        flag_vals = np.abs(np.random.randn(genes_per_chrome))
        max_idx = np.argsort(-flag_vals)[:]
        min_cutoff[cc*2+0] = max_idx[0]+cc*genes_per_chrome
        min_cutoff[cc*2+1] = max_idx[1]+cc*genes_per_chrome
        for gg in range(0,genes_per_coeff): # Loop over genes affecting coefficient cc
            gcounter = gg+genes_per_coeff*cc # Find position of particular gene
            # Randomly decide which of the two (homozygous) genotypes will have positive effect.
            aa = int(2)*np.random.randint(0,2) # randint is low inclusive and high exclusive!
            #UU[aa,gcounter] = np.random.uniform(low=0.0,high=1.0) # Randomly decide the magnitude of the effect. 
            #UU[aa,gcounter] = np.abs(np.random.randn(1)) # Randomly decide the magnitude of the effect. 
            UU[aa,gcounter] = flag_vals[gg]
            sum_flag[cc] = sum_flag[cc]+UU[aa,gcounter] # Keep track of total effect of all genes on coefficient cc. 
            UU[2-aa,gcounter] = 0.0 # The other genotype has no effect. 
            UU[1,gcounter]   = UU[aa,gcounter]/2.0 # The heterozygous genome has an effect equal to the mean of the two homozygous. 
        for gg in range(0,genes_per_coeff):
            gcounter = gg+genes_per_coeff*cc
            UU[0,gcounter] = (coeffs_max[cc]-coeffs_min[cc])*UU[0,gcounter]/sum_flag[cc]
            UU[1,gcounter] = (coeffs_max[cc]-coeffs_min[cc])*UU[1,gcounter]/sum_flag[cc]
            UU[2,gcounter] = (coeffs_max[cc]-coeffs_min[cc])*UU[2,gcounter]/sum_flag[cc]
    
    #UUall[:,:] = UU[:,:]
    
    
    #--------------------------------------------------------------------------
    #----------- 1.b Introduce deleterious interactions between genes ---------
    #AAnonlinear = []
    AAnonlinear = np.zeros((Nnonlin,2),dtype=int)
    GGnonlinear = np.zeros((Nnonlin,max_nonlinearity),dtype=int)
    UUnonlinear = np.zeros((Nnonlin,pow(3,max_nonlinearity)),dtype=float)
    #GGnonlinear = []
    #UUnonlinear = []
    valid_points = [True for ii in range(0,Ng)]
    if (max_nonlinearity > 0):
        for nn in range(0,Nnonlin): # Loop over the number of nonlinearities we want to introduce.
            #Randomly decide on the size of each nonlinearity between 2 and max_nonlinearity
            aa = np.random.randint(2,max_nonlinearity+1)
            # Save the size of the nonlinearity and how many possible different values the group can take.
            AAnonlinear[nn,0] = aa
            AAnonlinear[nn,1] = pow(Ngt,aa)
            #AAnonlinear.append([aa,pow(Ngt,aa)])
            # Initialize an array to store the genes of the nonlinearity
            #GGnonlinear.append(np.zeros(aa,dtype=int) )
            # Randomly sample the first gene
            
            GGnonlinear[nn,0] = min_cutoff[np.random.randint(0,2*Ncoeffs-1)]
            while (  valid_points[GGnonlinear[nn,0]] == False  ):
                GGnonlinear[nn,0] = min_cutoff[np.random.randint(0,2*Ncoeffs-1)]
            valid_points[GGnonlinear[nn,0]] = False
            if (  (GGnonlinear[nn,0] // genes_per_chrome) == ( (GGnonlinear[nn,0]+AAnonlinear[nn,0]) //genes_per_chrome)  ):
                for pp in range(1,AAnonlinear[nn,0]):
                    GGnonlinear[nn,pp] = GGnonlinear[nn,pp-1]+int(1)
                    valid_points[GGnonlinear[nn,pp]] = False
            else:
                for pp in range(1,AAnonlinear[nn,0]):
                    GGnonlinear[nn,pp] = GGnonlinear[nn,pp-1]-int(1)
                    valid_points[GGnonlinear[nn,pp]] = False
            
            
            # GGnonlinear[nn,0] = np.random.randint(0,Ng-AAnonlinear[nn,0]-1)
            # while ( valid_points[GGnonlinear[nn,0]] == False  or (GGnonlinear[nn,0] // genes_per_chrome) != ( (GGnonlinear[nn,0]+AAnonlinear[nn,0]) //genes_per_chrome) ): # Make sure the first gene is appropriate
            #     GGnonlinear[nn,0] = np.random.randint(0,Ng-AAnonlinear[nn,0]-1)
            # valid_points[GGnonlinear[nn,0]] = False
            if ( GGnonlinear[nn,0] < max_nonlinearity ):
                for zz in range(0,GGnonlinear[nn,0]):
                    valid_points[zz] = False
            else:
                for zz in range(GGnonlinear[nn,0]-max_nonlinearity,GGnonlinear[nn,0]):
                    valid_points[zz] = False
            # for pp in range(1,AAnonlinear[nn,0]):
            #     GGnonlinear[nn,pp] = GGnonlinear[nn,pp-1]+int(1)
            #     valid_points[GGnonlinear[nn,pp]] = False
            # valid_points[GGnonlinear[nn,0]+AAnonlinear[nn,0]] = False
        
            for pp in range(0,AAnonlinear[nn,1]):
                val_flag = 0.0
                val_pos = pp
                for pp2 in range(0,AAnonlinear[nn,0]):
                    val_flag += UU[val_pos//pow(3,AAnonlinear[nn,0]-pp2-1),GGnonlinear[nn,pp2]]
                    val_pos = val_pos % pow(3,AAnonlinear[nn,0]-pp2-1)
                UUnonlinear[nn,pp] = val_flag
        
            val_pos1 = 0
            val_pos2 = 0
            for pp2 in range(0,AAnonlinear[nn,0]):
                val_pos = np.argmax(UU[:,GGnonlinear[nn,pp2]])
                val_pos1 += val_pos*pow(3,AAnonlinear[nn,0]-pp2-1)
                val_pos2 += (2-val_pos)*pow(3,AAnonlinear[nn,0]-pp2-1)
            val_flag = UUnonlinear[nn,val_pos1]
            UUnonlinear[nn,val_pos2] = val_flag
            UUnonlinear[nn,val_pos1] = 0.0
    
        for gg in range(0,Ng):
            for nn in range(0,Nnonlin):
                if (gg in GGnonlinear[nn,:]):
                    for aa in range(0,Ngt):
                        UUall[aa,gg] = UU[aa,gg]
                        UU[aa,gg] = 0.0
    
#    GGnonlinear = np.zeros((max_nonlinearity,Nnonlin),dtype=int)
#    UUnonlinear = np.zeros((nonlinearity_choices,Nnonlin),dtype=float)
#    for nn in range(0,Nnonlin):
#        GGnonlinear[0,nn] = np.random.randint(0,Ng)
#        while ( ((GGnonlinear[0,nn] // genes_per_chrome) != ((GGnonlinear[0,nn]+max_nonlinearity-1) // genes_per_chrome)) or (  GGnonlinear[0,nn] in GGnonlinear[:,0:nn] ) or ( GGnonlinear[0,nn]+max_nonlinearity-1 in GGnonlinear[:,0:nn] )  ):
#            GGnonlinear[0,nn] = np.random.randint(0,Ng)
#        for pp in range(1,max_nonlinearity):
#            GGnonlinear[pp,nn] += GGnonlinear[pp-1,nn]+1
#        
#        
#        for pp in range(0,nonlinearity_choices):
#            val_flag = 0.0
#            val_pos = pp
#            for pp2 in range(0,max_nonlinearity):
#                val_flag += UU[val_pos//pow(3,max_nonlinearity-pp2-1),GGnonlinear[pp2,nn]]
#                val_pos = val_pos % pow(3,max_nonlinearity-pp2-1)
#            UUnonlinear[pp,nn] = val_flag
#        
#        val_pos1 = 0
#        val_pos2 = 0
#        for pp2 in range(0,max_nonlinearity):
#            val_pos = np.argmax(UU[:,GGnonlinear[pp2,nn]])
#            val_pos1 += val_pos*pow(3,max_nonlinearity-pp2-1)
#            val_pos2 += (2-val_pos)*pow(3,max_nonlinearity-pp2-1)
#        val_flag = UUnonlinear[val_pos1,nn]
#        UUnonlinear[val_pos2,nn] = val_flag
#        UUnonlinear[val_pos1,nn] = 0.0
#            
#    for cc in range(0,Ncoeffs): # Loop over coefficient directly effected by the genome. 
#        for gg in range(0,genes_per_coeff): # Loop over genes affecting coefficient cc
#            gcounter = gg+genes_per_coeff*cc # Find position of particular gene
#            if (gcounter in GGnonlinear):
#                for aa in range(0,Ngt):
#                    UUall[aa,gcounter] = UU[aa,gcounter]
#                    UU[aa,gcounter] = 0.0
    
    
    
    
    #--------------------------------------------------------------------------
    #--------------- 2. Sample genes for each individual plant ----------------
    for pp in range(0,Np): # Loop over individual plants. 
        for gg in range(0,Ng): # Loop over genes. 
            for aa in range(0,2): # Loop over possible alleles. 
                aflag = np.random.uniform(low=0.0,high=1.0)
                if (alleles_freqs[gg] > aflag): # Sample alleles with the frequency given by the user.
                    aa_flag = int(1)
                else:
                    aa_flag = int(0)
                alleles[aa,pp,gg] = aa_flag # Set the sampled value of the allele. 
            # Set the correct genotype value for the allele combination.
            genomes[pp,gg] = alleles[0,pp,gg] +alleles[1,pp,gg]
    
    
    
    #--------------------------------------------------------------------------
    #---------- 3. Calculate reference state variables for all plants ---------
    A = np.zeros( Np,dtype=float)
    S = np.zeros( Np,dtype=float)
    CK_basis = np.zeros( Np,dtype=float)
    SL_basis = np.zeros( Np,dtype=float)
    CK = np.zeros( Np,dtype=float)
    SL = np.zeros( Np,dtype=float)
    I  = np.zeros( Np,dtype=float)
    T  = np.zeros( Np,dtype=float)
    Ucoeffs = np.zeros( (Np,Ncoeffs-2), dtype=float )
    
    for pp in range(0,Np):
        for gg in range(0,genes_per_coeff):
            A[pp] = A[pp] +UU[genomes[pp,gg],gg]
            S[pp] = S[pp] +UU[genomes[pp,gg+genes_per_coeff],gg+genes_per_coeff]
            for kk in range(0,Ncoeffs-2):
                Ucoeffs[pp,kk] = Ucoeffs[pp,kk] +UU[genomes[pp,gg+(kk+2)*genes_per_coeff],gg+(kk+2)*genes_per_coeff]
        
        
        if (max_nonlinearity > 0):
            for nn in range(0,Nnonlin):
                val_flag = 0.0
                val_pos = int(0)
                for pp2 in range(0,AAnonlinear[nn,0]):
                    val_pos += genomes[pp,GGnonlinear[nn,pp2]]*pow(Ngt,AAnonlinear[nn,0]-pp2-1)
                val_flag = UUnonlinear[nn,val_pos]
                
                if (GGnonlinear[nn,0] < genes_per_coeff):
                    A[pp] = A[pp] +val_flag
                elif (GGnonlinear[nn,0] < 2*genes_per_coeff):
                    S[pp] = S[pp] +val_flag
                elif (GGnonlinear[nn,0] < 3*genes_per_coeff):
                    Ucoeffs[pp,0] = Ucoeffs[pp,0] +val_flag
                else:
                    Ucoeffs[pp,1] = Ucoeffs[pp,1] +val_flag
                
        
        ck_input, sl_input, signal_input = Bertheloot_coeffs(Ucoeffs[pp,:],case_flag,"Ref")
        CK[pp] = cytokinin_eq(A[pp],S[pp],ck_input)
        SL[pp] = strigonlactone_eq(A[pp],S[pp],sl_input)
        I[pp]  = signal_integrator_eq(A[pp],S[pp],CK[pp],SL[pp],signal_input)
        T[pp]  = bud_outgrowth_time_eq(I[pp])
    
    
    
    # Creating training/validation/testing data
    Np_train = round(training_percentage*Np)
    Np_val   = round(validation_percentage*Np)
    Np_test  = Np -Np_train -Np_val
    training_index = np.zeros( Np_train, dtype=int)
    validation_index = np.zeros( Np_val, dtype=int)
    testing_index = np.zeros( Np_test, dtype=int)
    index = np.zeros(Np, dtype=int)
    for ii in range(0,Np):
        index[ii] = ii
    random.shuffle(index)
    training_index = index[0:Np_train]
    validation_index = index[Np_train:Np_train+Np_val]
    testing_index = index[Np_train+Np_val:Np]
    
    
    #--------------------------------------------------------------------------
    #-------------------- 4. Save data of generated germplasm -----------------
    #train_genome_file = "../Data/Germplasm_Data/Germplasm_Data_"+alleles_distr+str(Ng)+"_"+str(max_nonlinearity)+"_Plant"+plant_flag+".nc"
    train_genome_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(plant_flag)+".nc"
    save_dataset = nc.Dataset(train_genome_file, 'w', format='NETCDF4')
    save_dataset.description = "Initial Germplasm"
    save_dataset.history     = "Created_"+time.ctime(time.time())
    save_dataset.source      = "Germplasm data produced by _Germplasm_Generator.py"
            
    save_dataset.createDimension('Np',Np)
    save_dataset.createDimension('Ng',Ng)
    save_dataset.createDimension('Ngt',Ngt)
    save_dataset.createDimension('Na',Na)
    save_dataset.createDimension('Ncoeffs',Ncoeffs)
    save_dataset.createDimension('max_nonlinearity',max_nonlinearity)
    save_dataset.createDimension('Nnonlin',Nnonlin)
    save_dataset.createDimension('nonlinearity_choices',nonlinearity_choices)
    save_dataset.createDimension('Np_train',Np_train)
    save_dataset.createDimension('Np_val'  ,Np_val)
    save_dataset.createDimension('Np_test' ,Np_test)
    
    genomes_nc = save_dataset.createVariable('genomes','f8',('Np','Ng'))
    genomes_nc.units = "Genomes"
    genomes_nc[:,:] = genomes[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UU','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UU[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUall','f8',('Ngt','Ng'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUall[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('UUnonlinear','f8',('Nnonlin','nonlinearity_choices'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = UUnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('GGnonlinear','f8',('Nnonlin','max_nonlinearity'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = GGnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('AAnonlinear','f8',('Nnonlin','Na'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = AAnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('alleles','f8',('Na','Np','Ng'))
    genomes_nc.units = "Alleles"
    genomes_nc[:,:,:] = alleles[:,:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('coeffs_min','f8',('Ncoeffs'))
    genomes_nc.units = "Alleles"
    genomes_nc[:] = coeffs_min[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('coeffs_max','f8',('Ncoeffs'))
    genomes_nc.units = "Alleles"
    genomes_nc[:] = coeffs_max[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('A','f8',('Np'))
    genomes_nc.units = "Auxin"
    genomes_nc[:] = A[:]
    del genomes_nc
            
    genomes_nc = save_dataset.createVariable('S','f8',('Np'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:] = S[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('CK','f8',('Np'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:] = CK[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('SL','f8',('Np'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:] = SL[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('I','f8',('Np'))
    genomes_nc.units = "Signal"
    genomes_nc[:] = I[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('T','f8',('Np'))
    genomes_nc.units = "Outgrowth_Time"
    genomes_nc[:] = T[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('train_index','i8',('Np_train'))
    genomes_nc.units = "index"
    genomes_nc[:] = training_index[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('val_index','i8',('Np_val'))
    genomes_nc.units = "index"
    genomes_nc[:] = validation_index[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('test_index','i8',('Np_test'))
    genomes_nc.units = "index"
    genomes_nc[:] = testing_index[:]
    del genomes_nc
    
    save_dataset.close()
    
    
    
    return






