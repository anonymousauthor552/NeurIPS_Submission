#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import time # Imported for the sleep function. 

import _Germplasm_Generator
import _batch_Breeding
import _Plotting_Data
import _batch_G2PNet
import _batch_active_learning
import _Plotting_Script
import G2PNet
import G2P_Breeding

class g2p_model:
    def __init__(self, config=None):
        self.script_type  = config["script_type"]
        self.germ_config  = config["Germplasm"]
        self.breed_config = config["Breeding"]
        self.model_config = config["Model"]
        self.nn_config    = config["neural_network"]
        
        
        
        
        
        #----------------------------------------------------------------------
        #----------------- Load info related to the Germplasm -----------------
        if "Np" in self.germ_config:
            self.Np = int(self.germ_config["Np"])
        else:
            raise Exception("No size of population defined.")
        
        if "Ng" in self.germ_config:
            self.Ng = int(self.germ_config["Ng"])
        else:
            raise Exception("No size of genome defined.")
        
        if "Nchrome" in self.germ_config:
            self.Nchrome = int(self.germ_config["Nchrome"])
        else:
            raise Exception("No number of chromosomes defined.")
            
        if "max_nonlinearity" in self.germ_config:
            self.max_nonlinearity = int(self.germ_config["max_nonlinearity"])
        else:
            raise Exception("No number of chromosomes defined.")
        
        if "Nnonlin" in self.germ_config:
            self.Nnonlin = int(self.germ_config["Nnonlin"])
        else:
            raise Exception("No number of chromosomes defined.")
        
        if "Na" in self.germ_config:
            self.Na = int(self.germ_config["Na"])
        else:
            raise Exception("No number of possible alleles per gene defined.")
        
        if "Ngt" in self.germ_config:
            self.Ngt = int(self.germ_config["Ngt"])
        else:
            raise Exception("No number of possible genotype per gene defined.")
        
        
        if "Nruns" in self.germ_config:
            self.Nruns = int(self.germ_config["Nruns"])
        else:
            raise Exception("No number of independent experiments to be performed.")
        
        if "Nstart" in self.germ_config:
            self.Nstart = int(self.germ_config["Nstart"])
        else:
            raise Exception("No number of independent experiments to be performed.")
        
        if "Nend" in self.germ_config:
            self.Nend = int(self.germ_config["Nend"])
        else:
            raise Exception("No number of independent experiments to be performed.")
        
        if "case" in self.germ_config:
            self.case = self.germ_config["case"]
        else:
            raise Exception("No g2p case defined.")
        
        if "alleles_freqs" in self.germ_config:
            self.alleles_freqs = self.germ_config["alleles_freqs"]
        else:
            raise Exception("No g2p case defined.")
        
        if "alleles_distr" in self.germ_config:
            self.alleles_distr = self.germ_config["alleles_distr"]
        else:
            raise Exception("No g2p case defined.")
        
        
        
        #----------------------------------------------------------------------
        #-------------- Load info related to the breeding process -------------
        if "Nc" in self.breed_config:
            self.Nc = int(self.breed_config["Nc"])
        else:
            raise Exception("No number of independent experiments to be performed.")
        
        if "Npi" in self.breed_config:
            self.Npi = int(self.breed_config["Npi"])
        else:
            raise Exception("No number of independent experiments to be performed.")
        
        if "breed_algo" in self.breed_config:
            self.breed_algo = self.breed_config["breed_algo"]
        else:
            raise Exception("No breeding algorithm defined.")
        
        
        
        
        
        #----------------------------------------------------------------------
        #---- Load info related to the modeling of the evolution equations ----
        if "Ncoeffs" in self.model_config:
            self.Ncoeffs = int(self.model_config["Ncoeffs"])
        else:
            raise Exception("No number of coefficients affected by genotypes.")
        
        if "coeffs_min" in self.model_config:
            self.coeffs_min = self.model_config["coeffs_min"]
        else:
            raise Exception("No number of coefficients affected by genotypes.")
            
        if "coeffs_max" in self.model_config:
            self.coeffs_max = self.model_config["coeffs_max"]
        else:
            raise Exception("No number of coefficients affected by genotypes.")
        
        if "mean_genes_per_coeff" in self.model_config:
            self.mean_genes_per_coeff = int(self.model_config["mean_genes_per_coeff"])
        else:
            raise Exception("No number of coefficients affected by genotypes.")
        
        if "aleatoric_noise" in self.model_config:
            self.aleatoric_noise = self.model_config["aleatoric_noise"]
        else:
            raise Exception("No aleatoric noise level defined (var: aleatoric_noise).")

        if "Network" in self.model_config:
            self.Network = self.model_config["Network"]
        else:
            raise Exception("No Network defined for the system (var: Network).")

        if "input_nodes" in self.model_config:
            self.input_nodes = self.model_config["input_nodes"]
        else:
            raise Exception("No input_nodes defined for the system (var: input_nodes).")

        if "output_nodes" in self.model_config:
            self.output_nodes = self.model_config["output_nodes"]
        else:
            raise Exception("No output_nodes defined for the system (var: output_nodes).")

        if "output_variable" in self.model_config:
            self.output_variable = self.model_config["output_variable"]
        else:
            raise Exception("No output_variable defined for the system (var: output_variable).")
        
        
        #----------------------------------------------------------------------
        #------------- Load info related to the neural network ----------------
        if "train_epochs" in self.nn_config:
            self.train_epochs = int(self.nn_config["train_epochs"])
        else:
            raise Exception("No number of training epochs specified (var: train_epochs).")
        
        if "train_batch" in self.nn_config:
            self.train_batch = int(self.nn_config["train_batch"])
        else:
            raise Exception("No batch size during training specified (var: train_batch).")
        
        if "validation_percentage" in self.nn_config:
            self.validation_percentage = float(self.nn_config["validation_percentage"])
        else:
            raise Exception("No percentage of data used for validation specified (var: validation_percentage).")
        
        if "training_percentage" in self.nn_config:
            self.training_percentage = float(self.nn_config["training_percentage"])
        else:
            raise Exception("No percentage of data used for training specified (var: training_percentage).")
        
        if "testing_percentage" in self.nn_config:
            self.testing_percentage = float(self.nn_config["testing_percentage"])
        else:
            raise Exception("No percentage of data used for testing specified (var: testing_percentage).")
            
        if "architecture" in self.nn_config:
            self.architecture = self.nn_config["architecture"]
        else:
            raise Exception("No neural network architecture specified (var: architecture).")
        
        if "loss_function" in self.nn_config:
            self.loss_function = self.nn_config["loss_function"]
        else:
            raise Exception("No loss function to be used during training specified (var: loss_function).")
        
        if "optimizer" in self.nn_config:
            self.optimizer = self.nn_config["optimizer"]
        else:
            raise Exception("No optimizer to be used during training specified (var: optimizer).")
        
        if "ensemble_size" in self.nn_config:
            self.ensemble_size = int(self.nn_config["ensemble_size"])
        else:
            raise Exception("No total number of neural networks to be trained per run specified (var: ensemble_size).")
        
        if "train_cycles" in self.nn_config:
            self.train_cycles = int(self.nn_config["train_cycles"])
        else:
            raise Exception("No total number of neural networks to be trained per run specified (var: ensemble_size).")
            
        if "cycle_start" in self.nn_config:
            self.cycle_start = int(self.nn_config["cycle_start"])
        else:
            raise Exception("No total number of neural networks to be trained per run specified (var: ensemble_size).")
        
        
    
    def Germplasm_Generation(self):
        user_input = []
        user_input.append(self.Np)
        user_input.append(self.Ng)
        user_input.append(self.Na)
        user_input.append(self.Ngt)
        user_input.append(self.Ncoeffs)
        user_input.append(self.coeffs_min)
        user_input.append(self.coeffs_max)
        user_input.append(self.case)
        user_input.append(str(""))
        user_input.append(self.alleles_freqs)
        user_input.append(self.aleatoric_noise)
        user_input.append(self.alleles_distr)
        user_input.append(self.Nchrome)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Nnonlin)
        user_input.append(self.training_percentage)
        user_input.append(self.validation_percentage)
        user_input.append(self.testing_percentage)
        for ii in range(self.Nstart,self.Nend):
            user_input[8] = str(ii)
            _Germplasm_Generator.Germplasm_Generator(user_input)
        return
    
    
    def G2P_Breeding(self,iter_number):
        user_input = []
        user_input.append(self.case)
        user_input.append("")
        user_input.append(self.Np)
        user_input.append(self.Ng)
        user_input.append(self.Nc)
        user_input.append(self.Npi)
        user_input.append(self.Na)
        user_input.append(self.Ngt)
        user_input.append(self.Ncoeffs)
        user_input.append(self.mean_genes_per_coeff)
        user_input.append(self.ensemble_size)
        user_input.append(self.breed_algo)
        user_input.append(self.aleatoric_noise)
        user_input.append(0)
        user_input.append(self.architecture)
        user_input.append(self.alleles_distr)
        user_input.append(self.Nchrome)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Nnonlin)
        user_input.append(self.training_percentage)
        user_input.append(self.validation_percentage)
        user_input.append(self.testing_percentage)
        for rr in range(self.Nstart,self.Nend):
            user_input[1] = str(rr)
            print('Testing '+self.architecture+' model for germplasm simulation #'+str(rr)+' of '+str(self.Nend)+' ...',end=' ')
            #_batch_Breeding.breed_batchfile(user_input,self.script_type,iter_number)
            G2P_Breeding.Breeding_Process(user_input,'G2PNet')
            print('done',end='\n')
            #time.sleep(0.50)
        return
    
    
    def Active_Learning(self,aa):
        user_input = []
        user_input.append(self.case)
        user_input.append("")
        user_input.append(self.Np)
        user_input.append(self.Ng)
        user_input.append(self.Nc)
        user_input.append(self.Npi)
        user_input.append(self.Na)
        user_input.append(self.Ngt)
        user_input.append(self.Ncoeffs)
        user_input.append(self.mean_genes_per_coeff)
        user_input.append(self.ensemble_size)
        user_input.append(self.breed_algo)
        user_input.append(self.aleatoric_noise)
        user_input.append(self.architecture)
        user_input.append(self.alleles_distr)
        user_input.append(self.Nchrome)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Nnonlin)
        for rr in range(self.Nstart,self.Nend):
            user_input[1] = str(rr)
            _batch_active_learning.active_learning_batchfile(user_input,self.script_type,aa)
            time.sleep(0.50)
        return
    
    
    def G2P_Training(self,aa):
        user_input = []
        user_input.append(self.case)
        user_input.append("")
        user_input.append(self.Np)
        user_input.append(self.Ng)
        user_input.append(self.Nc)
        user_input.append(self.Npi)
        user_input.append(self.Na)
        user_input.append(self.Ngt)
        user_input.append(self.Ncoeffs)
        #user_input.append(self.coeffs_min)
        #user_input.append(self.coeffs_max)
        user_input.append(self.train_epochs)
        user_input.append(self.train_batch)
        user_input.append(self.validation_percentage)
        user_input.append(self.architecture)
        user_input.append(self.loss_function)
        user_input.append(self.optimizer)
        user_input.append(self.aleatoric_noise)
        user_input.append(0)
        user_input.append(0)
        user_input.append(self.alleles_distr)
        user_input.append(self.Nchrome)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Nnonlin)
        user_input.append(0)
        user_input.append(self.training_percentage)
        user_input.append(self.validation_percentage)
        user_input.append(self.testing_percentage)
        user_input.append(self.input_nodes)
        user_input.append(self.output_nodes)
        user_input.append(self.output_variable)
        for rr in range(self.Nstart,self.Nend):
            user_input[1] = str(rr)
            for nn in range(0,self.ensemble_size):
                user_input[16] = nn
                print('Training '+self.architecture+' model for germplasm simulation #'+str(rr)+' of '+str(self.Nend)+' ...',end=' ')
                start_time = time.time()
                G2PNet.G2PNet_Train(user_input)
                end_time   = time.time()
                print('completed in '+str(round(int(end_time-start_time)))+' [sec]',end='\n')
        
        return
    
    def G2P_Plotting_Data(self):
        user_input = []
        user_input.append(self.case)
        user_input.append(self.Nruns)
        user_input.append(self.Np)
        user_input.append(self.Ng)
        user_input.append(self.Nc)
        user_input.append(self.Npi)
        user_input.append(self.Na)
        user_input.append(self.Ngt)
        user_input.append(self.Ncoeffs)
        user_input.append(self.coeffs_min)
        user_input.append(self.coeffs_max)
        user_input.append(self.alleles_distr)
        user_input.append(self.Nstart)
        user_input.append(self.Nend)
        user_input.append(self.Nchrome)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Nnonlin)
        _Plotting_Data.Ref_Plot_Data(user_input,"Ref")
        #_Plotting_Data.Ref_Plot_Data(user_input,"Mean")
        _Plotting_Data.Ref_Plot_Data(user_input,"G2PNet")
        return
    
    def G2P_Plotting_Script(self):
        user_input = []
        user_input.append(self.Nc)
        user_input.append(self.Na)
        user_input.append(self.Nruns)
        user_input.append(self.Ng//self.Ncoeffs)
        user_input.append(self.Ng)
        user_input.append(self.max_nonlinearity)
        user_input.append(self.Np)
        user_input.append(self.training_percentage)
        user_input.append(self.validation_percentage)
        user_input.append(self.testing_percentage)
        #_Plotting_Script.Plotting_Script(user_input, self.case)
        _Plotting_Script.Plotting_Scatterplot(user_input, self.case)
        return
    
    
    
    
    
    
        
