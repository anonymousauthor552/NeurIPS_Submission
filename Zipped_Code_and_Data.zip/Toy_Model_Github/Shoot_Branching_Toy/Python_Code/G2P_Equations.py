#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
#import numpy as np
#import scipy.io as sio
#from scipy.interpolate import griddata
#import os
#import time
#import netCDF4 as nc


def cytokinin_eq(A,S,ck_coeffs):
    
    # Synthesis base rate of CK without sucrose and auxin.
    #c1 = 0.79 # in [mol sec^{-1}].
    c1 = ck_coeffs[0]
    # Strength of CK synthesis inhibition by auxin.
    #b1 = 0.96 # in [mol^{-1}].
    b1 = ck_coeffs[1]
    # Maximum induction of CK synthesis by sucrose.
    #a1 = 0.25 # in [mol sec^{-1}].
    a1 = ck_coeffs[2]
    # Parameter of the Hill function relating sucrose and CK synthesis.
    #k1 = 0.19 # in [mol^2].
    k1 = ck_coeffs[3]
    # CK degradation rate.
    #d1 = 0.99 # in [sec^{-1}].
    d1 = ck_coeffs[4]
    
    CK = ( c1/(1.0+b1*A) +a1*S*S/(k1+S*S) )/d1
    
    return CK


def strigonlactone_eq(A,S,sl_coeffs):
    
    # Base synthesis rate of SL without auxin.
    #c2 = 0.34 # in [mol sec^{-1}].
    c2 = sl_coeffs[0]
    # Maximum induction of SL synthesis rate by auxin.
    #a2 = 24.89 # in [mol sec^{-1}].
    a2 = sl_coeffs[1]
    # Parameter of the Hill function relating auxin and SL synthesis.
    #k2 = 294.58 # in [mol^2].
    k2 = sl_coeffs[2]
    # SL degradation rate.
    #d2 = 0.86 # in [sec^{-1}].
    d2 = sl_coeffs[3]
    
    SL = ( c2 +a2*A*A/(k2+A*A) )/d2
    
    #SL = 0.0
    #dt = 0.1
    #SL_rhs = c2 +a2*A*A/(k2+A*A) -d2*SL
    #SL = SL +dt*SL_rhs
    
    return SL



def signal_integrator_eq(A,S,CK,SL,signal_coeffs):
    
    # Base production rate of I.
    #c3 = 0.33 # in [mol sec^{-1}].
    c3 = signal_coeffs[0]
    # Parameter relating the production rate of I to SL and sucrose.
    a3 = 5.64 # in [mol^{-1} sec^{-1}].
    a3 = signal_coeffs[1]
    # Minimum inhibiting effect of sucrose on SL response. 
    u1 = 4.8*pow(10.0,-13) # [mol^{-2}].
    u1 = signal_coeffs[2]
    # Strength of sucrose inhibiting effect on SL response.
    u2 = 7.10 # in [mol^{-4}].
    u2 = signal_coeffs[3]
    # Parameter relating the production rate of I to CK.
    #a4 = 287.53 # in [mol sec^{-1}].
    a4 = signal_coeffs[4]
    # Strength of CK effect on I production.
    k3 = 1000.0 # in [mol^{-2}].
    k3 = signal_coeffs[5]
    # Constant degradation rate of I.
    d3 = 0.99 # in [sec^{-1}].
    d3 = signal_coeffs[6]
    
    I = ( c3 +a3*SL*SL/(1.0+(u1+u2*S*S)*SL*SL) +a4/(1.0+k3*CK*CK) )/d3
    
    #I = 0.0
    #dt = 0.1
    #I_rhs = c3 +a3*SL*SL/(1.0+(u1+u2*S*S)*SL*SL) +a4/(1.0+k3*CK*CK) -d3*I
    #I = I +dt*I_rhs
    
    return I


def bud_outgrowth_time_eq(I):
    
    
    
    # Intercept of the linear relationship between T and I.
    m0 = -2.2 # in [days].
    # Sensitivity of the time at which elongation starts to I.
    m1 = 3.5 # in [day mol^{-1}].
    # Threshold of I above which bud elongation is completely prevented. 
    I0 = 3.0 # in [mol].
    
    #T = m0+m1*I0
    
    T = m0 +m1*I
    if (I < I0):
        T = m0 +m1*I
    
    return T










