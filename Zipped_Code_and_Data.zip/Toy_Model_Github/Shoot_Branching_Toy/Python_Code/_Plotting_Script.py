#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
import numpy as np
#import scipy.io as sio
#from scipy.interpolate import griddata
#import os
import time
import netCDF4 as nc
import matplotlib.pyplot as plt



def Plotting_Scatterplot(user_input,case_flag):
    
    Nc = int(user_input[0])
    Na = int(user_input[1])
    Nruns = int(user_input[2])
    genes_per_coeff = int(user_input[3])
    Ng = int(user_input[4])
    max_nonlinearity = int(user_input[5])
    Np  = int(user_input[6])
    training_percentage = float(user_input[7])
    validation_percentage = float(user_input[8])
    testing_percentage = float(user_input[9])
    cycle_axis = np.linspace(1,Nc-1,num=Nc)
    if (Ng < 100):
        cycle_vals = [0, 4, 9, 29]
    else:
        cycle_vals = [0, 9, 29, 99]
    
    # Plotting parameters
    size_mult = 1.5 # Figure resizing parameter
    mean_linewidth = 1.5 # Linewidth value of mean lines
    a_color = [0.8,0.0,0.0] # Color of auxin 
    s_color = [0.0,0.6,0.0] # Color of sucrose
    ck_color = [0.0,0.5,1.0] # Color of cytokinin
    sl_color = [0.929,0.694,0.125] # Color of strigolactone
    i_color  = [0.2,0.2,0.2] # Color of integrated signal
    mean_linestyle = '-' # Linestyle of mean lines
    font_size = int(12)
    breeding_xlabel = 'Selection Cycle'
    breeding_ylabel = 'Population Genetic Mean'
    title_labels = []
    title_labels.append('Ref. Model - Max Sampling')
    title_labels.append('ENN - Max Sampling')
    title_labels.append('GAT - Max Sampling')
    #title_labels.append('ENN - UQ Sampling')
    alpha_coeff = 0.2 # Transparency parameter for envelopes
    marker_size = int(4) # Size of markers used for genes

    Np_test = Np-round(Np*training_percentage)-round(Np*validation_percentage)
    test_index = np.zeros( Np_test, dtype=int )
    
    T_ref = np.zeros((Np_test,Nc),dtype=float)
    T_lr  = np.zeros((Np_test,Nc),dtype=float)
    T_fcn = np.zeros((Np_test,Nc),dtype=float)
    T_gnn = np.zeros((Np_test,Nc),dtype=float)

    mse_lr_mean  = 0.0
    mse_fcn_mean = 0.0
    mse_gnn_mean = 0.0
    mae_lr_mean  = 0.0
    mae_fcn_mean = 0.0
    mae_gnn_mean = 0.0

    mse_lr_std  = 0.0
    mse_fcn_std = 0.0
    mse_gnn_std = 0.0
    mae_lr_std  = 0.0
    mae_fcn_std = 0.0
    mae_gnn_std = 0.0

    mse_lr  = []
    mse_fcn = []
    mse_gnn = []
    mae_lr  = []
    mae_fcn = []
    mae_gnn = []

    for pp in range(0,Nruns):
        load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(pp)+".nc"
        ds1 = nc.Dataset(load_file)
        test_index[:] = ds1["test_index"][:]
        T_ref[:,0] = ds1["T"][test_index[:]]
        ds1.close()
        # LR model
        load_file = "../Data/Model_Data/LR_Data_"+str(case_flag)+"_Plant"+str(pp)+".nc"
        ds1 = nc.Dataset(load_file)
        T_lr[:,0] = ds1["T"][test_index[:],0]
        ds1.close()
        # FCN model
        load_file = "../Data/Model_Data/FCN_Data_"+str(case_flag)+"_Plant"+str(pp)+".nc"
        ds1 = nc.Dataset(load_file)
        T_fcn[:,0] = ds1["T"][test_index[:],0]
        ds1.close()
        # Bio_GNN model
        load_file = "../Data/Model_Data/GNN_Data_"+str(case_flag)+"_Plant"+str(pp)+".nc"
        ds1 = nc.Dataset(load_file)
        T_gnn[:,0] = ds1["T"][test_index[:],0]
        ds1.close()
        
        mse_lr.append(0.0)
        mse_fcn.append(0.0)
        mse_gnn.append(0.0)
        mae_lr.append(0.0)
        mae_fcn.append(0.0)
        mae_gnn.append(0.0)
        for ii in range(0,len(test_index)):
            mse_lr[pp]  += (T_ref[ii,0] -T_lr[ii,0])*(T_ref[ii,0]-T_lr[ii,0])
            mse_fcn[pp] += (T_ref[ii,0] -T_fcn[ii,0])*(T_ref[ii,0]-T_fcn[ii,0])
            mse_gnn[pp] += (T_ref[ii,0] -T_gnn[ii,0])*(T_ref[ii,0]-T_gnn[ii,0])
            mae_lr[pp]  += np.abs(T_ref[ii,0] -T_lr[ii,0])
            mae_fcn[pp] += np.abs(T_ref[ii,0] -T_fcn[ii,0])
            mae_gnn[pp] += np.abs(T_ref[ii,0] -T_gnn[ii,0])
        mse_lr[pp]  = np.sqrt(mse_lr[pp]/float(len(test_index)))
        mse_fcn[pp] = np.sqrt(mse_fcn[pp]/float(len(test_index)))
        mse_gnn[pp] = np.sqrt(mse_gnn[pp]/float(len(test_index)))
        mae_lr[pp]  = mae_lr[pp]/float(len(test_index))
        mae_fcn[pp] = mae_fcn[pp]/float(len(test_index))
        mae_gnn[pp] = mae_gnn[pp]/float(len(test_index))
        mse_lr_mean  += mse_lr[pp]/float(Nruns)
        mse_fcn_mean += mse_fcn[pp]/float(Nruns)
        mse_gnn_mean += mse_gnn[pp]/float(Nruns)
        mae_lr_mean  += mae_lr[pp]/float(Nruns)
        mae_fcn_mean += mae_fcn[pp]/float(Nruns)
        mae_gnn_mean += mae_gnn[pp]/float(Nruns)

    for pp in range(0,Nruns):
        mse_lr_std  += np.sqrt((mse_lr[pp]-mse_lr_mean)*(mse_lr[pp]-mse_lr_mean)/float(Nruns))
        mse_fcn_std += np.sqrt((mse_fcn[pp]-mse_fcn_mean)*(mse_fcn[pp]-mse_fcn_mean)/float(Nruns))
        mse_gnn_std += np.sqrt((mse_gnn[pp]-mse_gnn_mean)*(mse_gnn[pp]-mse_gnn_mean)/float(Nruns))
        mae_lr_std  += np.sqrt((mae_lr[pp]-mae_lr_mean)*(mae_lr[pp]-mae_lr_mean)/float(Nruns))
        mae_fcn_std += np.sqrt((mae_fcn[pp]-mae_fcn_mean)*(mae_fcn[pp]-mae_fcn_mean)/float(Nruns))
        mae_gnn_std += np.sqrt((mae_gnn[pp]-mae_gnn_mean)*(mae_gnn[pp]-mae_gnn_mean)/float(Nruns))

    print('MAE for LR: '+str(mae_lr_mean)+', FCN: '+str(mae_fcn_mean)+', GNN: '+str(mae_gnn_mean))
    print('MAE-std for LR: '+str(mae_lr_std)+', FCN: '+str(mae_fcn_std)+', GNN: '+str(mae_gnn_std))
    print('MSE for LR: '+str(mse_lr_mean)+', FCN: '+str(mse_fcn_mean)+', GNN: '+str(mse_gnn_mean))
    print('MSE-std for LR: '+str(mse_lr_std)+', FCN: '+str(mse_fcn_std)+', GNN: '+str(mse_gnn_std))
        
    
    figure1 = plt.figure(num=1,figsize=(6.0,7.33*(1440/2560)) )

    plt.plot([0,20],[0,20],linewidth=2,color='red')
    plt.scatter(T_ref[:,0], T_lr[:,0],s=4,color=[0,0.5,1])
    plt.xlabel('Observation')
    plt.ylabel('Prediction')
    plt.title('Scatterplot for LR model, simulation #'+str(0))
    plt.xlim([0,20])
    plt.ylim([0,20])
    plt.grid(visible=True)
    #ax[0].set(xlabel='Observation', ylabel='Prediction',title='Scatterplot for LR model, simulation #'+str(0))
    save_name = "../Plots/Ref_LR_scatterplot_"+case_flag+".pdf"
    plt.savefig(save_name)
    plt.close()
    
    
    figure1 = plt.figure(num=1,figsize=(6.0,7.33*(1440/2560)) )

    plt.plot([0,20],[0,20],linewidth=2,color='red')
    plt.scatter(T_ref[:,0], T_fcn[:,0],s=4,color=[0,0.5,1])
    plt.xlabel('Observation')
    plt.ylabel('Prediction')
    plt.title('Scatterplot for FCN model, simulation #'+str(0))
    plt.xlim([0,20])
    plt.ylim([0,20])
    plt.grid(visible=True)
    save_name = "../Plots/Ref_FCN_scatterplot_"+case_flag+".pdf"
    plt.savefig(save_name)
    plt.close()
    
    figure1 = plt.figure(num=1,figsize=(6.0,7.33*(1440/2560)) )

    plt.plot([0,20],[0,20],linewidth=2,color='red')
    plt.scatter(T_ref[:,0], T_gnn[:,0],s=4,color=[0,0.5,1])
    plt.xlabel('Observation')
    plt.ylabel('Prediction')
    plt.title('Scatterplot for GNN model, simulation #'+str(0))
    plt.xlim([0,20])
    plt.ylim([0,20])
    plt.grid(visible=True)
    save_name = "../Plots/Ref_GNN_scatterplot_"+case_flag+".pdf"
    plt.savefig(save_name)
    plt.close()
    
    return
    
    





def Plotting_Script(user_input,case_flag):
    
    Nc = int(user_input[0])
    Na = int(user_input[1])
    Nruns = int(user_input[2])
    genes_per_coeff = int(user_input[3])
    Ng = int(user_input[4])
    max_nonlinearity = int(user_input[5])
    cycle_axis = np.linspace(1,Nc-1,num=Nc)
    if (Ng < 100):
        cycle_vals = [0, 4, 9, 29]
    else:
        cycle_vals = [0, 9, 29, 99]
    
    # Plotting parameters
    size_mult = 1.5 # Figure resizing parameter
    mean_linewidth = 1.5 # Linewidth value of mean lines
    a_color = [0.8,0.0,0.0] # Color of auxin 
    s_color = [0.0,0.6,0.0] # Color of sucrose
    ck_color = [0.0,0.5,1.0] # Color of cytokinin
    sl_color = [0.929,0.694,0.125] # Color of strigolactone
    i_color  = [0.2,0.2,0.2] # Color of integrated signal
    mean_linestyle = '-' # Linestyle of mean lines
    font_size = int(12)
    breeding_xlabel = 'Selection Cycle'
    breeding_ylabel = 'Population Genetic Mean'
    title_labels = []
    title_labels.append('Ref. Model - Max Sampling')
    title_labels.append('ENN - Max Sampling')
    title_labels.append('GAT - Max Sampling')
    #title_labels.append('ENN - UQ Sampling')
    alpha_coeff = 0.2 # Transparency parameter for envelopes
    marker_size = int(4) # Size of markers used for genes
    
    Amean = []
    Amax  = []
    Amin  = []
    
    Smean = []
    Smax  = []
    Smin  = []
    
    CKmean = []
    CKmax  = []
    CKmin  = []
    
    SLmean = []
    SLmax  = []
    SLmin  = []
    
    Imean  = []
    
    Gene_eff  = []
    Gene_freq = []
    Gene_eff_nonlinear  = []
    Gene_freq_nonlinear = []
    
    model_names = ['Ref','G2PNet','G2PNet']
    case_names  = [case_flag,'case1','case1']
    for pp in range(0,3):
        load_file = "../Data/Plot_Data/"+model_names[pp]+"_Data_"+case_names[pp]+"_Plot.nc"
        ds = nc.Dataset(load_file)
        Amean.append(ds['Amean'][:])
        Amax.append(ds['Amax'][:])
        Amin.append(ds['Amin'][:])
        Smean.append(ds['Smean'][:])
        Smax.append(ds['Smax'][:])
        Smin.append(ds['Smin'][:])
        
        CKmean.append(ds['CKmean'][:])
        CKmax.append(ds['CKmax'][:])
        CKmin.append(ds['CKmin'][:])
        
        SLmean.append(ds['SLmean'][:])
        SLmax.append(ds['SLmax'][:])
        SLmin.append(ds['SLmin'][:])
        
        Imean.append(ds['Imean'][:])
        flag_resize = 0.5/Imean[pp][0]
        for ii in range(0,Nc):
            Imean[pp][ii] = flag_resize*Imean[pp][ii]
        
        Gene_eff.append(ds['Gene_eff'][:])
        Gene_freq.append(ds['Gene_freq'][:])
        Gene_eff_nonlinear.append(ds['Gene_eff_nonlinear'][:,:])
        Gene_freq_nonlinear.append(ds['Gene_freq_nonlinear'][:,:])
        
        for gg in range(0,Ng*Na*Nruns):
            if (Gene_eff[pp][gg] < 0.0001):
                Gene_eff[pp][gg] = -10.0
            if (max_nonlinearity > 1):
                if (Gene_eff_nonlinear[pp][1,gg] < 0.0001):
                    Gene_eff_nonlinear[pp][1,gg] = -10.0
            if (max_nonlinearity > 2):
                if (Gene_eff_nonlinear[pp][2,gg] < 0.0001):
                    Gene_eff_nonlinear[pp][2,gg] = -10.0
        
        ds.close()
    
    figure1 = plt.figure(num=1,figsize=(6.0*size_mult,7.33*(1440/2560)*size_mult) )
    
    subfigs = figure1.subfigures(2,1)
    
    
    ax = []
    for pp in range(0,3):
        pflag = 130+pp+1
        ax.append(subfigs[0].add_subplot(pflag))
        if (pp == 0):
            plt.subplots_adjust(bottom=0.25, left=0.07, right=0.98,top=0.9)
        ax[pp].fill_between(cycle_axis, Amax[pp] , Amin[pp] , color=a_color , alpha=alpha_coeff)
        ax[pp].fill_between(cycle_axis, Smax[pp] , Smin[pp] , color=s_color , alpha=alpha_coeff)
        ax[pp].fill_between(cycle_axis, CKmax[pp], CKmin[pp], color=ck_color, alpha=alpha_coeff)
        ax[pp].fill_between(cycle_axis, SLmax[pp], SLmin[pp], color=sl_color, alpha=alpha_coeff)
        line_a,  = ax[pp].plot(cycle_axis,Amean[pp] ,linewidth=mean_linewidth,color=a_color ,linestyle=mean_linestyle)
        line_s,  = ax[pp].plot(cycle_axis,Smean[pp] ,linewidth=mean_linewidth,color=s_color ,linestyle=mean_linestyle)
        line_ck, = ax[pp].plot(cycle_axis,CKmean[pp],linewidth=mean_linewidth,color=ck_color,linestyle=mean_linestyle)
        line_sl, = ax[pp].plot(cycle_axis,SLmean[pp],linewidth=mean_linewidth,color=sl_color,linestyle=mean_linestyle)
        line_i,  = ax[pp].plot(cycle_axis,Imean[pp] ,linewidth=mean_linewidth,color=i_color ,linestyle=mean_linestyle)
        if (Ng < 100):
            plt.xlim([0.5,30+0.5])
            plt.xticks(ticks=[1,5,10,15,20,25,30])
        else:
            plt.xlim([0.5,100+0.5])
            plt.xticks(ticks=[1,20,40,60,80,100])
        plt.ylim([-0.1,1.1])
        plt.xlabel(xlabel=breeding_xlabel,fontsize=font_size)
        if (pp == 0):
            plt.ylabel(ylabel=breeding_ylabel,fontsize=font_size)
        plt.title(label=title_labels[pp],fontsize=font_size)
        plt.grid(visible=True,alpha=0.3)
        
        if (pp == 0):
            ax[pp].legend(handles=(line_a,line_s,line_ck,line_sl,line_i),labels=('Auxin', 'Sucrose', 'Cytokinins', 'Strigolactones', 'Signal Integrator'),ncols=5,loc=(-0.15,-0.39),fontsize=font_size,frameon=False)
    
    
    subfigsb = subfigs[1].subfigures(1,3)
    
    ax = []
    for pp in range(0,4):
        pflag = 140+pp+1
        for xx in range(0,3):
            xflag = 2-xx
            ax.append(subfigsb[xflag].add_subplot(pflag))
            pstart = 0*Na*Nruns*genes_per_coeff
            pend   = (0+1)*Na*Nruns*genes_per_coeff
            plt.scatter(Gene_freq[xflag][pstart:pend,cycle_vals[pp]],Gene_eff[xflag][pstart:pend],color=a_color,s=marker_size-1)
            plt.text(x=0.17,y=1.15,s='#'+str(cycle_vals[pp]+1), fontsize=font_size )
            
            pstart = 1*Na*Nruns*genes_per_coeff
            pend   = (1+1)*Na*Nruns*genes_per_coeff
            plt.scatter(Gene_freq[xflag][pstart:pend,cycle_vals[pp]],Gene_eff[xflag][pstart:pend],color=s_color,s=marker_size-1)
            
            pstart = 2*Na*Nruns*genes_per_coeff
            pend   = (2+1)*Na*Nruns*genes_per_coeff
            plt.scatter(Gene_freq[xflag][pstart:pend,cycle_vals[pp]],Gene_eff[xflag][pstart:pend],color=ck_color,s=marker_size-1)
            
            pstart = 3*Na*Nruns*genes_per_coeff
            pend   = (3+1)*Na*Nruns*genes_per_coeff
            plt.scatter(Gene_freq[xflag][pstart:pend,cycle_vals[pp]],Gene_eff[xflag][pstart:pend],color=sl_color,s=marker_size-1)
            
            if (max_nonlinearity > 1):
                pstart = 0*Na*Nruns*genes_per_coeff
                pend   = (0+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][1,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][1,pstart:pend],color=a_color,s=marker_size,marker="x",linewidths=0.5)
                #plt.text(x=0.18,y=1.15,s='# '+str(cycle_vals[pp]+1), fontsize=font_size )
                
                pstart = 1*Na*Nruns*genes_per_coeff
                pend   = (1+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][1,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][1,pstart:pend],color=s_color,s=marker_size,marker="x",linewidths=0.5)
                
                pstart = 2*Na*Nruns*genes_per_coeff
                pend   = (2+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][1,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][1,pstart:pend],color=ck_color,s=marker_size,marker="x",linewidths=0.5)
                
                pstart = 3*Na*Nruns*genes_per_coeff
                pend   = (3+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][1,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][1,pstart:pend],color=sl_color,s=marker_size,marker="x",linewidths=0.5)
            
            if (max_nonlinearity > 2):
                pstart = 0*Na*Nruns*genes_per_coeff
                pend   = (0+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][2,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][2,pstart:pend],color=a_color,s=marker_size,marker="^",linewidths=0.5)
                #plt.text(x=0.18,y=1.15,s='# '+str(cycle_vals[pp]+1), fontsize=font_size )
                
                pstart = 1*Na*Nruns*genes_per_coeff
                pend   = (1+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][2,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][2,pstart:pend],color=s_color,s=marker_size,marker="^",linewidths=0.5)
                
                pstart = 2*Na*Nruns*genes_per_coeff
                pend   = (2+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][2,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][2,pstart:pend],color=ck_color,s=marker_size,marker="^",linewidths=0.5)
                
                pstart = 3*Na*Nruns*genes_per_coeff
                pend   = (3+1)*Na*Nruns*genes_per_coeff
                plt.scatter(Gene_freq_nonlinear[xflag][2,pstart:pend,cycle_vals[pp]],Gene_eff_nonlinear[xflag][2,pstart:pend],color=sl_color,s=marker_size,marker="^",linewidths=0.5)
            
            
            if (xflag == 0 and pp == 0):
                plt.ylabel(ylabel='Genetic Effect Size',fontsize=font_size)
            
            if (xflag == 2 and pp == 3):
                subfigsb[xflag].subplots_adjust(bottom=0.15, left=0.14, right=0.95,top=0.9)
            if (xflag == 1 and pp == 3):
                subfigsb[xflag].subplots_adjust(bottom=0.15, left=0.17, right=0.98,top=0.9)
            if (xflag == 0 and pp == 3):
                subfigsb[xflag].subplots_adjust(bottom=0.15, left=0.21, right=1.00,top=0.9)
            
            
            if (pp == 0):
                plt.text(x=1.4, y=-0.3, s='Allele Frequency', fontsize = font_size)
                ax[xx].spines['right'].set_visible(False)
                ax[xx].spines['top'].set_visible(False)
                #plt.subplots_adjust(bottom=0.25, left=0.17, right=0.98,top=0.9)
            if (pp > 0):
                ax[3*pp+xx].spines['right'].set_visible(False)
                ax[3*pp+xx].spines['top'].set_visible(False)
                ax[3*pp+xx].spines['left'].set_visible(False)
                ax[3*pp+xx].tick_params(axis='y', which='both', length=0)
            
            
            plt.xlim([-0.1,1.1])
            plt.ylim([-0.1,1.1])
            plt.xticks(ticks=[0,0.5,1],labels=['0','0.5','1'])
            if (pp == 0):
                plt.yticks(ticks=[0,0.2,0.4,0.6,0.8,1.0])
            else:
                plt.yticks(ticks=[0.0,0.2,0.4,0.6,0.8,1.0],labels=[])
            plt.grid(visible=True,alpha=0.3,ydata=[0,0.2,0.4,0.6,0.8,1.0])
            
        
    
    
    
    save_name = "../Plots/NeurIPS_Naive_UQ_Comp_"+case_flag+".pdf"
    plt.savefig(save_name)
    
    return