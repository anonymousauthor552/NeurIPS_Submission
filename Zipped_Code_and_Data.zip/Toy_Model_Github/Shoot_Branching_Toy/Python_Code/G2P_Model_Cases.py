#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This is the file to create cases you want to simulate for G2PNet. To create a 
case, you can copy and paste one of the cases seen below and then change its
name to the desired one. You can then proceed to change all parameter values to
the ones you like. In terms, of parameters there are the following general 
groups:
    
    1. Germplasm parameters: 
        - Np: The total number of individual plants per generation. 
        - Ng: The total number of genes in the genome. 
        - Na: the number of possible different alleles per gene. 
        - Ngt: total number of genotypes. 
        - case: the name of the case (is automatically set as the one you gave)
        - Nruns: total number of independent runs (each run has different equations)
        - alleles_freqs: frequencies of each alleles for each gene in the starting germplasm. 
    
    2. Breeding parameters:
        - Nc: The total number of breeding cycles. 
        - Npi: The total number of plants used as parents for the next cycle. 
        - breed_algo: Algorithm used to pick parents. Can be "Naive" or "UQ"
    
    3. Model parameters:
        - Ncoeffs: Number of coefficients in the evolution equations to be directly effected by genes. 
        - coeffs_min: Minimum possible values for each of the (Ncoeffs) coefficients. 
        - coeffs_max: Maximum possible values for each of the (Ncoeffs) coefficients. 
        - mean_genes_per_coeff: Number of genes affecting a particular coefficient in the MEAN model. 
        - aleatoric_noise: variance of aleatoric noise in the time-to-bud-outgrowth variable. 
    
    4. neural_network parameters:
        - train_epochs: Total number of training epochs for training.
        - train_batch: Batch-size during training. 
        - validation_percentage: Percentage of initial germplasm used for validation.
        - architecture: Name of the neural network architecture. Can be "FCN" or "G2PNet"
        - loss_function: Loss function used during training. 
        - optimizer: Optimizer used during training. 
        - ensemble_size: Total number of neural networks to be trained per run. 


@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import numpy as np # Imported to do math.
import pandas as pd # Imported to load the metabolic network. 

def Define_G2P_Model(config,user_input):
    
    config["script_type"] = user_input[5]
    config["Germplasm"] = {}
    config["Breeding"]  = {}
    config["Model"]     = {}
    config["Model"]["Network"] = user_input[3]
    config["Model"]["output_variable"] = user_input[4]
    df = pd.read_csv('../Data/Network_Data/'+config["Model"]["Network"]+'.csv')
    input_nodes = []
    output_nodes = []
    for ii in range(0,len(df['input_node'][:])):
        input_nodes.append(df['input_node'][ii])
        output_nodes.append(df['output_node'][ii])
    config["Model"]["input_nodes"]  = input_nodes
    config["Model"]["output_nodes"] = output_nodes
    config["neural_network"] = {}
    
    
    #--------------------------------------------------------------------------
    #--------------- case1: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "statistical_reproduction"):
        config["Germplasm"]["Np"] = int(2000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(160) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(user_input[2]) # Total number of independent runs (each run has different equations). 
        #config["Germplasm"]["Nruns"] = int(3) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Equal" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 1.00
        
        config["neural_network"]["train_epochs"] = int(300) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["training_percentage"]   = 0.30 # Percentage of germplasm to be used as training.
        config["neural_network"]["validation_percentage"] = 0.10 # Percentage of germplasm to be used as validation.
        config["neural_network"]["testing_percentage"]    = 1.0-config["neural_network"]["training_percentage"]-config["neural_network"]["validation_percentage"] # Percentage of germplasm to be used as testing.
        config["neural_network"]["architecture"] = "LR" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(1) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(1)      
    
    
    #--------------------------------------------------------------------------
    #--------------- case1: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case2"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Equal" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "UQ" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.00
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(5) 
    
    
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case3"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(10)
        config["neural_network"]["train_cycles"] = int(20) 
    
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case4"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "UQ" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(10)
        config["neural_network"]["train_cycles"] = int(15) 
    
    
    
    
    
    
    
    
    
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case5"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(1000) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(105) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(20)
        config["neural_network"]["train_cycles"] = int(30) 
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case6"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(1000) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(2) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(105) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "UQ" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(5) 
    
    
    
    
    #--------------------------------------------------------------------------
    #----------------- case2: Ng = 40 and allele frequencies are at 0.5. ------
    if (user_input[1] == "case7"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(3) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Equal" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.00
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(10)
        config["neural_network"]["train_cycles"] = int(20)  
    
    
    
    #--------------------------------------------------------------------------
    #----------------- case2: Ng = 40 and allele frequencies are at 0.5. ------
    if (user_input[1] == "case8"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(3) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Equal" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "UQ" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.00
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(5)  
    
    
    if (user_input[1] == "case9"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Equal" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.00
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(10)
        config["neural_network"]["train_cycles"] = int(15)    
    
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case10"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(40) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(35) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(10) 
    
    
    #--------------------------------------------------------------------------
    #--------------- case5: Ng = 40 and allele frequencies are at 0.5 ---------
    if (user_input[1] == "case11"):
        config["Germplasm"]["Np"] = int(1000) # Total number of individual plants per generation. 
        config["Germplasm"]["Ng"] = int(1000) # Total number of genes in genome. 
        config["Germplasm"]["Nchrome"] = int(4) # Total number of chromosomes.
        config["Germplasm"]["max_nonlinearity"] = int(0) # Maximum number of genes that can be nonlinearly dependent between them.
        config["Germplasm"]["Nnonlin"] = int(2) # Total number of nonlinear clusters.
        config["Germplasm"]["Na"] = int(2) # Total number of possible different alleles per gene. 
        config["Germplasm"]["Ngt"] = int(3) # Total number of genotypes. 
        config["Germplasm"]["case"] = user_input[1] # Name of case. 
        config["Germplasm"]["Nruns"] = int(10) # Total number of independent runs (each run has different equations). 
        config["Germplasm"]["Nstart"] = int(0)
        config["Germplasm"]["Nend"]   = config["Germplasm"]["Nstart"]+config["Germplasm"]["Nruns"]
        config["Germplasm"]["alleles_distr"] = "Uniform" # Equal or Uniform
        config["Germplasm"]["alleles_freqs"] = [] # Frequencies of each alleles for each gene in the starting germplasm.  
        for ii in range(0,config["Germplasm"]["Ng"]):
            if (config["Germplasm"]["alleles_distr"] == "Equal"):
                config["Germplasm"]["alleles_freqs"].append(0.5) # Generate frequencies for each allele. 
            elif (config["Germplasm"]["alleles_distr"] == "Uniform"):
                config["Germplasm"]["alleles_freqs"].append(np.random.uniform(low=0.01,high=0.99))
        
        config["Breeding"]["Nc"]  = int(105) # Total number of breeding cycles. 
        config["Breeding"]["Npi"] = int(100) # Total number of plants used as parents for the next cycle. 
        config["Breeding"]["breed_algo"] = "Naive" # Naive Pick the Npi best performers, UQ: use ensemble.
        
        config["Model"]["Ncoeffs"] = int(4) # Total number of coefficients in the evolution equations to be directly effected by genes. 
        config["Model"]["coeffs_min"] = [0.0, 0.0, 0.0, 0.0] # Minimum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["coeffs_max"] = [2.5, 2.5, 1.1, 1.0] # Maximum possible value for each of the (Ncoeffs) coefficients. 
        config["Model"]["mean_genes_per_coeff"] = int(10) # Number of genes affecting a particular coefficient in the MEAN model. 
        config["Model"]["aleatoric_noise"] = 0.50
        
        config["neural_network"]["train_epochs"] = int(500) # Total number of epochs used during training. 
        config["neural_network"]["train_batch"]  = int(8) # Batch-size during training. 
        config["neural_network"]["validation_percentage"] = 0.30 # Percentage of germplasm to be used as validation.
        config["neural_network"]["architecture"] = "FCN" # Name of architecture to be used for the neural network. (G2PNet or FCN)
        config["neural_network"]["loss_function"] = "mse" # Loss function used during training. 
        config["neural_network"]["optimizer"] = "adam" # Optimizer used during training. 
        config["neural_network"]["ensemble_size"] = int(2) # Total number of neural networks to be trained per run. 
        config["neural_network"]["cycle_start"] = int(0)
        config["neural_network"]["train_cycles"] = int(20) 
    
    return config




def Bertheloot_coeffs(Ucoeffs,case_flag,model_flag):
    
    ##--------------------------- Case1 - STAR ------------------------------##
    if (model_flag == "Ref"):
        ck_input = [Ucoeffs[0], 0.96, 0.25, 0.19, 0.99]
        sl_input = [Ucoeffs[1], 24.89, 294.58, 0.86]
        signal_input = [0.33, 5.64, 4.8*pow(10.0,-13), 7.10, 287.53, 1000.0, 0.99]
    
    if (model_flag == "Mean"):
        ck_input = [Ucoeffs[0], 0.96, 0.25, 0.19, 0.99]
        sl_input = [Ucoeffs[1], 24.89, 294.58, 0.86]
        signal_input = [0.33, 5.64, 4.8*pow(10.0,-13), 7.10, 287.53, 1000.0, 0.99]
    
    if (model_flag == "G2PNet"):
        ck_input = [Ucoeffs[0], 0.96, 0.25, 0.19, 0.99]
        sl_input = [Ucoeffs[1], 24.89, 294.58, 0.86]
        signal_input = [0.33, 5.64, 4.8*pow(10.0,-13), 7.10, 287.53, 1000.0, 0.99]
    ##--------------------------- Case1 - END -------------------------------##
    
    return ck_input, sl_input, signal_input



def FCN_params(case):
    
    if (case == "case9" or case == "case10" or case == "case11"):
        total_layers = int(1) # Total number of fully-connected layers used.
        layer_dims = [1] # Output dimension of each layer. 
        alpha0     = [1.00] # Parameters for leaky ReLU.
        layer_regs = [0.00] # L1 regularization coefficients.
    else:
        total_layers = int(8) # Total number of fully-connected layers used.
        layer_dims = [40, 40, 40, 40, 20, 10, 4, 1] # Output dimension of each layer. 
        alpha0     = [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01] # Parameters for leaky ReLU.
        layer_regs = [0.0005, 0.0005, 0.0005, 0.0005, 0.0005, 0.0005, 0.0005, 0.0005] # L1 regularization coefficients.
    
#    total_layers = int(6) # Total number of fully-connected layers used.
#    layer_dims = [10, 8, 6, 5, 4, 1] # Output dimension of each layer. 
#    alpha0     = [0.01, 0.01, 0.01, 0.01, 0.01] # Parameters for leaky ReLU.
#    layer_regs = [0.0005, 0.0005, 0.0005, 0.0005, 0.0005, 0.0005] # L1 regularization coefficients.
#    #layer_regs = [0.000, 0.000, 0.000, 0.000, 0.000, 0.000] # L1 regularization coefficients.
    
    return total_layers, layer_dims, alpha0, layer_regs








