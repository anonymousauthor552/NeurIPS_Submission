#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 14:37:28 2023

@author: gopwp
"""

import sys # Imported to read input from command line.
import os  # Imported to check that appropriate folders exist (and create them if not).
import numpy as np
import scipy.io as sio
#import matplotlib.pyplot as plt
import tensorflow as tf
tf.keras.backend.set_floatx('float64')
#from scipy.io import netcdf
import netCDF4 as nc

import tensorflow.keras.backend as kb


def Bertheloot_Model(A,S,CKb,SLb):
    
    #-------------------------------------------------------------------------#
    #----------- 1. Parameters of the equations - START ----------------------#
    # Strength of CK synthesis inhibition by auxin.
    b1 = 0.96 # in [mol^{-1}].
    # Maximum induction of CK synthesis by sucrose.
    a1 = 0.25 # in [mol sec^{-1}].
    # Parameter of the Hill function relating sucrose and CK synthesis.
    k1 = 0.19 # in [mol^2].
    # CK degradation rate.
    d1 = 0.99 # in [sec^{-1}].
    
    # Maximum induction of SL synthesis rate by auxin.
    a2 = 24.89 # in [mol sec^{-1}].
    # Parameter of the Hill function relating auxin and SL synthesis.
    k2 = 294.58 # in [mol^2].
    # SL degradation rate.
    d2 = 0.86 # in [sec^{-1}].
    
    
    # Intercept of the linear relationship between T and I.
    m0 = -2.2 # in [days].
    # Sensitivity of the time at which elongation starts to I.
    m1 = 3.5 # in [day mol^{-1}].
    # Threshold of I above which bud elongation is completely prevented. 
    I0 = 3.0 # in [mol].
    
    # Base production rate of I.
    c3 = 0.33 # in [mol sec^{-1}].
    # Parameter relating the production rate of I to SL and sucrose.
    a3 = 5.64 # in [mol^{-1} sec^{-1}].
    # Minimum inhibiting effect of sucrose on SL response. 
    u1 = 4.8*pow(10.0,-13) # [mol^{-2}].
    # Strength of sucrose inhibiting effect on SL response.
    u2 = 7.10 # in [mol^{-4}].
    # Parameter relating the production rate of I to CK.
    a4 = 287.53 # in [mol sec^{-1}].
    # Strength of CK effect on I production.
    k3 = 1000.0 # in [mol^{-2}].
    # Constant degradation rate of I.
    d3 = 0.99 # in [sec^{-1}].
    
    # Intercept of the linear relationship between T and I.
    m0 = -2.2 # in [days].
    # Sensitivity of the time at which elongation starts to I.
    m1 = 3.5 # in [day mol^{-1}].
    # Threshold of I above which bud elongation is completely prevented. 
    I0 = 3.0 # in [mol].
    #----------- 1. Parameters of the equations - END ------------------------#
    #-------------------------------------------------------------------------#
    
    
    
    #-------------------------------------------------------------------------#
    #-------------------- 2. Model equations - START -------------------------#
    # Compute cytokinin levels.
    CK = ( CKb/(1.0+b1*A) +a1*S*S/(k1+S*S) )/d1
    # Compute strigolactone levels.
    SL = ( SLb +a2*A*A/(k2+A*A) )/d2
    # Compute the signal integrator. 
    I = ( c3 +a3*SL*SL/(1.0+(u1+u2*S*S)*SL*SL) +a4/(1.0+k3*CK*CK) )/d3
    
    # Compute time-to-bud-outgrowth. 
    if (I < I0): # If this is true, a new branch will grow. 
        T = m0 +m1*I
    else: # Otherwise, no branch will grow. 
        T = m0+m1*I0 # Instead of setting it to infinity, we just cap the value of T to make training viable. 
    #-------------------- 2. Model equations - END ---------------------------#
    #-------------------------------------------------------------------------#
    
    return CK, SL, I, T






def get_NN(input_dim,output_dim):
    
    alpha0 = 0.01 # Parameter for leaky ReLUs
    
    #--------------------------------------------------------------------------
    #------ 0. Initialize model with the input data and their dimension -------  
    input_shape = (input_dim) # Input dimension
    layers = [tf.keras.Input(shape=input_shape)] # Initialize list of layers.
    
    
    
    #--------------------------------------------------------------------------
    #---------------- 1. Predict CK using the input nodes ---------------------
    # Concatenate the four variables in a single vector.
    ck_layers = [layers[-1]] # 2. Fake linkage between sl base synthesis rate and cytokinins
    ck_layers.append( tf.keras.layers.Dense(5,activation=None)(ck_layers[-1]))
    ck_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(ck_layers[-1]))
    ck_layers.append( tf.keras.layers.Dense(4,activation=None)(ck_layers[-1]))
    ck_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(ck_layers[-1]))
    ck_layers.append( tf.keras.layers.Dense(3,activation=None)(ck_layers[-1]))
    ck_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(ck_layers[-1]))
    ck_layers.append( tf.keras.layers.Dense(2,activation=None)(ck_layers[-1]))
    ck_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(ck_layers[-1]))
    ck_value = tf.keras.layers.Dense(1,activation=None)(ck_layers[-1])
    
    
    
    #--------------------------------------------------------------------------
    #---------------- 2. Predict SL using the input nodes ---------------------
    sl_layers = [layers[-1]] # 3. Fake linkage between sl and cytokinin base synthesis rate
    sl_layers.append( tf.keras.layers.Dense(4,activation=None)(sl_layers[-1]))
    sl_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(sl_layers[-1]))
    sl_layers.append( tf.keras.layers.Dense(3,activation=None)(sl_layers[-1]))
    sl_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(sl_layers[-1]))
    sl_layers.append( tf.keras.layers.Dense(2,activation=None)(sl_layers[-1]))
    sl_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(sl_layers[-1]))
    sl_value = tf.keras.layers.Dense(1,activation=None)(sl_layers[-1])
    
    
    
    #--------------------------------------------------------------------------
    #------- 3. Predict I as a function of CK, SL and the input nodes ---------
    i_layers = [ tf.keras.layers.Concatenate(axis=1)( [ ck_value, sl_value, layers[-1] ] )  ] # the signal integrator is a function of CK, SL and the input nodes. 
    i_layers.append( tf.keras.layers.Dense(4,activation=None)(layers[-1]))
    i_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(i_layers[-1]))
    i_layers.append( tf.keras.layers.Dense(3,activation=None)(i_layers[-1]))
    i_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(i_layers[-1]))
    i_layers.append( tf.keras.layers.Dense(2,activation=None)(i_layers[-1]))
    i_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0  )(i_layers[-1]))
    i_value = tf.keras.layers.Dense(1,activation=None)(i_layers[-1])
    
    
    
    #--------------------------------------------------------------------------
    #------- 4. Predict T as a function of I and the input nodes --------------
    t_layers = [ tf.keras.layers.Concatenate(axis=1)( [ i_value, layers[-1] ] ) ]
    t_layers.append(tf.keras.layers.Dense(4,activation=None)(t_layers[-1]))
    t_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0 )(t_layers[-1]))
    t_layers.append(tf.keras.layers.Dense(3,activation=None)(t_layers[-1]))
    t_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0 )(t_layers[-1]))
    t_layers.append(tf.keras.layers.Dense(2,activation=None)(t_layers[-1]))
    t_layers.append(tf.keras.layers.LeakyReLU(alpha=alpha0 )(t_layers[-1]))
    t_value = tf.keras.layers.Dense(1,activation=None)(t_layers[-1])
    
    
    
    #--------------------------------------------------------------------------
    #----- 5. Concatenate output of states [CK,SL,I,T] & finalize model -------
    layers.append( tf.keras.layers.Concatenate(axis=1)( [ ck_value, sl_value, i_value, t_value ] ) ) # Concatenate all final outputs to a single vector.     
    model = tf.keras.Model(inputs=layers[0], outputs=layers[-1]) # Finalize model. 
    
    return model









if __name__ == "__main__":
    
    #-------------------------------------------------------------------------#
    #----------- 1. Generate & Save reference data - START -------------------#
    
    Np = int(1000) # Number of plant (each with different genome to simulate)
    A  = np.zeros(Np,dtype=float)  # Auxin levels for each plant. 
    S  = np.zeros(Np,dtype=float)  # Sucrose levels for each plant.
    CKb = np.zeros(Np,dtype=float) # Synthesis base rate of CK without sucrose and auxin, in [mol sec^{-1}].
    SLb = np.zeros(Np,dtype=float) # Base synthesis rate of SL without auxin, in [mol sec^{-1}].
    
    CK = np.zeros(Np,dtype=float) # Cytokinin levels for each plant. 
    SL = np.zeros(Np,dtype=float) # Strigolactone levels for each plant. 
    I  = np.zeros(Np,dtype=float) # Signal integrator for each plant. 
    T  = np.zeros(Np,dtype=float) # Time-to-bud-outgrowth for each plant.
    
    for pp in range(0,Np): # Loop over all plants. 
        # Since we don't use gene information, we sample the input data randomly. 
        A[pp] = np.random.uniform(low=0.0,high=2.5)
        S[pp] = np.random.uniform(low=0.0,high=2.5)
        CKb[pp] = np.random.uniform(low=0.0,high=1.1)
        SLb[pp] = np.random.uniform(low=0.0,high=1.0)
        # Predict the intermediate and final traits from the input data. 
        CK[pp], SL[pp], I[pp], T[pp] = Bertheloot_Model(A[pp],S[pp],CKb[pp],SLb[pp])
    
    #----------- 1. Generate & Save reference data - END ---------------------#
    #-------------------------------------------------------------------------#
    
    
    
    #-------------------------------------------------------------------------#
    #--------------- 2. Create redundant nodes - START -----------------------#
    input_dim  = int(10) # Total number of input nodes. Only 4 are real (A,S,CKb,SLb)
    output_dim = int(4) # Output dimension (CK,SL,I,T)
    
    input_data  = np.zeros((Np,input_dim),dtype=float)
    output_data = np.zeros((Np,output_dim),dtype=float)
    
    # Add the real node information to the input
    for pp in range(0,Np):
        input_data[pp,0] = A[pp]
        input_data[pp,1] = S[pp]
        input_data[pp,2] = CKb[pp]
        input_data[pp,3] = SLb[pp]
    
    # Add redundant nodes - Changes this as you want. 
    for pp in range(0,Np):
        for nn in range(4,input_dim):
            input_data[pp,nn] = np.random.randn(1) # Add noise to each redundant noise. 
        # Add some fake connections to actual input data. 
        input_data[pp,4] += 0.2*A[pp]
        input_data[pp,5] += 0.1*S[pp]*CKb[pp]
        input_data[pp,6] += 0.25*SLb[pp]
    
    
    # Add the target traits to the output
    for pp in range(0,Np):
        output_data[pp,0] = CK[pp]
        output_data[pp,1] = SL[pp]
        output_data[pp,2] = I[pp]
        output_data[pp,3] = T[pp]
    #--------------- 2. Create redundant nodes - END -------------------------#
    #-------------------------------------------------------------------------#
    
    
    
    #-------------------------------------------------------------------------#
    #--------------- 3. Train a neural network - START -----------------------#
    
    train_samples = round(0.8*Np)
    validation_percentage = 0.20
    train_end = round(train_samples*(1.0-validation_percentage) )
    
    
    
    os.environ['KMP_DUPLICATE_LIB_OK']='True'
    # Name the model.
    model_name = "ElliNet"
    train_end   = round(train_samples*(1.0-validation_percentage)) # Train on 95% of samples and validate on the rest 5%. 
    model = get_NN(input_dim,output_dim) # Grab the correct neural network architecture. 
    #model1.compile(loss=model_loss,optimizer=model_optimizer) # Compile the neural network with chosen loss function and optimizer.
    model.compile(loss='mse',optimizer='adam')
    # Train the neural network. 
    hist1 = model.fit(input_data[0:train_end,:], output_data[0:train_end,:], batch_size=32, epochs=100, validation_data=(input_data[train_end:train_samples,:],output_data[train_end:train_samples,:]), callbacks=[])
    # Save the trained neural network. 
    model.save(model_name+".h5")
    
    
    #--------------- 3. Train a neural network - END -------------------------#
    #-------------------------------------------------------------------------#
    
    
    
    exit()



