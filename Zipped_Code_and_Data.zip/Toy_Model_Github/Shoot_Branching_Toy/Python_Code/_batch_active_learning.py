#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
import os  # Imported to check that appropriate folders exist (and create them if not).
#import numpy as np
#import scipy.io as sio
#import matplotlib.pyplot as plt
import tensorflow as tf
tf.keras.backend.set_floatx('float64')
#from scipy.io import netcdf
#import netCDF4 as nc
#import time
#import cartopy.crs as ccrs





def active_learning_batchfile(user_input,script_type,aa):
    
    case_flag  = user_input[0]
    plant_flag = user_input[1]
    Np  = int(user_input[2])
    Ng  = int(user_input[3])
    Nc  = int(user_input[4])
    Npi = int(user_input[5])
    Na  = int(user_input[6])
    Ngt = int(user_input[7])
    Ncoeffs = int(user_input[8])
    mean_genes_per_coeffs = int(user_input[9])
    ensemble_size = int(user_input[10])
    breed_algo = user_input[11]
    aleatoric_noise = user_input[12]
    architecture = user_input[13]
    alleles_distr = user_input[14]
    Nchrome = int(user_input[15])
    max_nonlinearity = int(user_input[16])
    Nnonlin = int(user_input[17])
        
    if (script_type == "sbatch"):
        # Name of batch file to be created
        batch_flag = "batch_"+case_flag+"_r"+str(plant_flag)+"_i"+str(aa)+"_Active_Learning"
        
        memory_flag = "'\n#SBATCH --mem=8G'"
        time_flag = "'\n#SBATCH --time=0:45:00'"
    
        cmd_flag = "echo -e '#!/bin/bash' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -A phy220062' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH --nodes=1' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH --ntasks=1' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e "+memory_flag+" >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e "+time_flag+" >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -J al_r"+str(plant_flag)+"_i"+str(aa)+"' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -o myjob.o%j' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -e myjob.e%j' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\n#SBATCH -p shared' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        #cmd_flag = "echo -e '\n#SBATCH --mail-user=alexchar@mit.edu' >> batch_files/"+batch_flag
        #os.system(cmd_flag)
        #cmd_flag = "echo -e '\n#SBATCH --mail-type=all' >> batch_files/"+batch_flag
        #os.system(cmd_flag)
        cmd_flag = "echo -e '\nmodule purge' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\nsource activate ~/miniconda3/envs/tensorflow-env' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\ncasename='TC_0'' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "echo -e '\necho $casename > SESSION.NAME' >> batch_files/"+batch_flag
        os.system(cmd_flag)
        # Begin echo command to write to the batch file
        cmd_flag = "echo -e "
        # Line regarding training a realization of the neural network
        cmd_flag += " '\npython ./_Active_Learning.py "+str(case_flag)+" "+str(plant_flag) \
        +" "+str(Np)+" "+str(Ng)+" "+str(Nc)+" "+str(Npi)+" "+str(Na)+" "+str(Ngt) \
        +" "+str(Ncoeffs)+" "+str(mean_genes_per_coeffs)+" "+str(ensemble_size) \
        +" "+str(breed_algo)+" "+str(aleatoric_noise)+" "+str(architecture)+" "+str(aa)+" "+alleles_distr+" "+str(Nchrome)+" "+str(max_nonlinearity)+" "+str(Nnonlin)
        # Create file that will signal to the main process that training is done. 
        cmd_flag += "\ntouch check_files/Active_Learning_"+str(case_flag)+"_r"+str(plant_flag)+"_iter"+str(aa)+".txt' " 
        # Push the text to the batch file
        cmd_flag += " >> batch_files/"+batch_flag 
        os.system(cmd_flag)
                    
        cmd_flag = "sbatch batch_files/"+batch_flag
        os.system(cmd_flag)
    elif (script_type == "shell"):
        # Name of batch file to be created
        batch_flag = "batch_"+case_flag+"_r"+str(plant_flag)+"_i"+str(aa)+"_Active_Learning"
        
        cmd_flag = "echo -e '#!/bin/bash' >> shell_files/"+batch_flag
        os.system(cmd_flag)
        
        cmd_flag = "echo -e "
        # Line regarding training a realization of the neural network
        cmd_flag += " '\npython ./_Active_Learning.py "+str(case_flag)+" "+str(plant_flag) \
        +" "+str(Np)+" "+str(Ng)+" "+str(Nc)+" "+str(Npi)+" "+str(Na)+" "+str(Ngt) \
        +" "+str(Ncoeffs)+" "+str(mean_genes_per_coeffs)+" "+str(ensemble_size) \
        +" "+str(breed_algo)+" "+str(aleatoric_noise)+" "+str(architecture)+" "+str(aa)+" "+alleles_distr+" "+str(Nchrome)+" "+str(max_nonlinearity)+" "+str(Nnonlin)
        # Create file that will signal to the main process that training is done. 
        cmd_flag += "\ntouch check_files/Active_Learning_"+str(case_flag)+"_r"+str(plant_flag)+"_iter"+str(aa)+".txt' " 
        # Push the text to the batch file
        cmd_flag += " >> shell_files/"+batch_flag 
        os.system(cmd_flag)
        
        cmd_flag = "chmod +x shell_files/"+batch_flag
        os.system(cmd_flag)
        cmd_flag = "shell_files/"+batch_flag+" > debug_files/"+batch_flag+" 2>&1 &"
        os.system(cmd_flag)
    
    
    return



