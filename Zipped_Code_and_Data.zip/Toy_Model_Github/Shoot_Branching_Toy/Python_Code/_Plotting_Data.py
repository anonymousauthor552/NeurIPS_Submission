#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

#import sys # Imported to read input from command line.
import numpy as np
#import scipy.io as sio
#from scipy.interpolate import griddata
#import os
import time
import netCDF4 as nc

from G2P_Equations import cytokinin_eq
from G2P_Equations import strigonlactone_eq
from G2P_Equations import signal_integrator_eq
from G2P_Equations import bud_outgrowth_time_eq

from G2P_Model_Cases import Bertheloot_coeffs

def Ref_Plot_Data(user_input,model_name):
    
    
    case_flag = user_input[0]
    Nruns =  int(user_input[1])
    Np  = int(user_input[2])
    Ng  = int(user_input[3])
    Nc  = int(user_input[4])
    Npi = int(user_input[5])
    Na  = int(user_input[6])
    Ngt = int(user_input[7])
    Ncoeffs = int(user_input[8])
    coeffs_min = user_input[9]
    coeffs_max = user_input[10]
    alleles_distr = user_input[11]
    Nstart = int(user_input[12])
    Nend   = int(user_input[13])
    Nchrome = int(user_input[14])
    max_nonlinearity = int(user_input[15])
    Nnonlin = int(user_input[16])
    nonlinearity_choices = pow(Ngt,max_nonlinearity)
    
    
    genes_per_coeff = int(Ng//Ncoeffs)
    
    
    genomes = np.zeros( (Np,Ng,Nc),dtype=int )
    alleles = np.zeros( (Na,Np,Ng,Nc),dtype=int )
    UU = np.zeros( (Ngt,Ng), dtype=float )
    UUall = np.zeros( (Ngt,Ng), dtype=float )
    GGnonlinear = np.zeros((Nnonlin,max_nonlinearity),dtype=int)
    UUnonlinear = np.zeros((Nnonlin,nonlinearity_choices),dtype=float)
    AAnonlinear = np.zeros((Nnonlin,2),dtype=int)
    
    Gene_freq = np.zeros((Nruns*Ng*Na,Nc),dtype=float)
    Gene_eff  = np.zeros(Nruns*Ng*Na,dtype=float)
    
    Gene_freq_nonlinear = np.zeros((max_nonlinearity,Nruns*Ng*Na,Nc),dtype=float)
    Gene_eff_nonlinear  = np.zeros((max_nonlinearity,Nruns*Ng*Na),dtype=float)
    
    A = np.zeros((Np,Nc),dtype=float)
    S = np.zeros((Np,Nc),dtype=float)
    CK = np.zeros((Np,Nc),dtype=float)
    SL = np.zeros((Np,Nc),dtype=float)
    I = np.zeros((Np,Nc),dtype=float)
    
    a_max = coeffs_max[0]
    a_min = coeffs_min[0]
    
    s_max = coeffs_max[1]
    s_min = coeffs_min[1]
    
    ck_input_max, sl_input_max, signal_input_max = Bertheloot_coeffs(coeffs_max[2:4],case_flag,"Ref")
    ck_input_min, sl_input_min, signal_input_min = Bertheloot_coeffs(coeffs_min[2:4],case_flag,"Ref")
        
    
    ck_max = cytokinin_eq(a_min,s_max,ck_input_max)
    ck_min = cytokinin_eq(a_max,s_min,ck_input_min)
    
    sl_max = strigonlactone_eq(a_max,s_min,sl_input_max)
    sl_min = strigonlactone_eq(a_min,s_max,sl_input_min)
    
    
    i_max = signal_integrator_eq(a_max,s_min,ck_min,sl_max,signal_input_max)
    i_min = signal_integrator_eq(a_min,s_max,ck_max,sl_min,signal_input_min)
    
    Amean = np.zeros(Nc,dtype=float)
    Amax  = np.zeros(Nc,dtype=float)
    Amin  = np.zeros(Nc,dtype=float)+100.0
    
    Smean = np.zeros(Nc,dtype=float)
    Smax  = np.zeros(Nc,dtype=float)
    Smin  = np.zeros(Nc,dtype=float)+100.0
    
    CKmean = np.zeros(Nc,dtype=float)
    CKmax  = np.zeros(Nc,dtype=float)
    CKmin  = np.zeros(Nc,dtype=float)+100.0
    
    SLmean = np.zeros(Nc,dtype=float)
    SLmax  = np.zeros(Nc,dtype=float)
    SLmin  = np.zeros(Nc,dtype=float)+100.0
    
    Imean = np.zeros(Nc,dtype=float)
    Imax  = np.zeros(Nc,dtype=float)
    Imin  = np.zeros(Nc,dtype=float)+100.0
    
    max_flag = 0.0
    for rr in range(0,Nruns):
        #load_file = "../Data/Germplasm_Data/Germplasm_Data_"+alleles_distr+str(Ng)+"_"+str(max_nonlinearity)+"_Plant"+str(rr+Nstart)+".nc"
        load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(rr+Nstart)+".nc"
        ds1 = nc.Dataset(load_file)
        UU[:,:] = ds1["UU"][:,:]
        UUall[:,:] = ds1["UUall"][:,:]
        UUnonlinear[:,:] = ds1["UUnonlinear"][:,:]
        GGnonlinear[:,:] = ds1["GGnonlinear"][:,:]
        AAnonlinear[:,:] = ds1["AAnonlinear"][:,:]
        ds1.close()
        
        max_flag2 = np.max(UU[:,:])
        if (max_flag2 > max_flag):
            max_flag = max_flag2
        
        max_flag2 = np.max(UUall[:,:])
        if (max_flag2 > max_flag):
            max_flag = max_flag2
    
    for rr in range(0,Nruns):
        #load_file = "../Data/Germplasm_Data/Germplasm_Data_"+alleles_distr+str(Ng)+"_"+str(max_nonlinearity)+"_Plant"+str(rr+Nstart)+".nc"
        load_file = "../Data/Germplasm_Data/Germplasm_Data_"+str(case_flag)+"_Plant"+str(rr+Nstart)+".nc"
        ds1 = nc.Dataset(load_file)
        UU[:,:] = ds1["UU"][:,:]
        UUall[:,:] = ds1["UUall"][:,:]
        UUnonlinear[:,:] = ds1["UUnonlinear"][:,:]
        GGnonlinear[:,:] = ds1["GGnonlinear"][:,:]
        AAnonlinear[:,:] = ds1["AAnonlinear"][:,:]
        ds1.close()
        
        load_file = "../Data/"+model_name+"_Data/"+model_name+"_Data_"+case_flag+"_Plant"+str(rr+Nstart)+".nc"
        ds1 = nc.Dataset(load_file)
        alleles[:,:,:,:] = ds1["alleles"][:,:,:,:]
        A[:,:] = ds1["A"][:,:]
        S[:,:] = ds1["S"][:,:]
        CK[:,:] = ds1["CK"][:,:]
        SL[:,:] = ds1["SL"][:,:]
        I[:,:]  = ds1["I"][:,:]
        ds1.close()
        
        #for cc in range(0,Ncoeffs):
        #    UU[:,cc*genes_per_coeff:(cc+1)*genes_per_coeff] = (UU[:,cc*genes_per_coeff:(cc+1)*genes_per_coeff] -0.0*coeffs_min[cc]/float(genes_per_coeff))/(coeffs_max[cc]-coeffs_min[cc])
        
        #max_flag = np.max(UU[:,:])
        
        for gg in range(0,Ng):
            counter_flag = Na*Nruns*gg+rr 
            Gene_eff[counter_flag] = UU[0,gg]/max_flag
            Gene_eff[counter_flag+Nruns] = UU[2,gg]/max_flag
            for cc in range(0,Nc):
                for pp in range(0,Np):
                    counter_flag = Na*Nruns*gg +Nruns*alleles[0,pp,gg,cc] +rr
                    Gene_freq[counter_flag,cc] += 1.0/float(2*Np)
                    counter_flag = Na*Nruns*gg +Nruns*alleles[1,pp,gg,cc] +rr
                    Gene_freq[counter_flag,cc] += 1.0/float(2*Np)
        
        
        #for cc in range(0,Ncoeffs):
        #    UUall[:,cc*genes_per_coeff:(cc+1)*genes_per_coeff] = (UUall[:,cc*genes_per_coeff:(cc+1)*genes_per_coeff] -0.0*coeffs_min[cc]/float(genes_per_coeff))/(coeffs_max[cc]-coeffs_min[cc])
        
        #max_flag = np.max(UUall[:,:])
        
        for nn in range(0,Nnonlin):
            for gg in range(0,AAnonlinear[nn,0]):
                counter_flag = Na*Nruns*GGnonlinear[nn,gg]+rr
                Gene_eff_nonlinear[AAnonlinear[nn,0]-1,counter_flag] = UUall[0,GGnonlinear[nn,gg]]/max_flag
                Gene_eff_nonlinear[AAnonlinear[nn,0]-1,counter_flag+Nruns] = UUall[2,GGnonlinear[nn,gg]]/max_flag
                for cc in range(0,Nc):
                    for pp in range(0,Np):
                        counter_flag = Na*Nruns*GGnonlinear[nn,gg] +Nruns*alleles[0,pp,GGnonlinear[nn,gg],cc] +rr
                        Gene_freq_nonlinear[AAnonlinear[nn,0]-1,counter_flag,cc] += 1.0/float(2*Np)
                        counter_flag = Na*Nruns*GGnonlinear[nn,gg] +Nruns*alleles[1,pp,GGnonlinear[nn,gg],cc] +rr
                        Gene_freq_nonlinear[AAnonlinear[nn,0]-1,counter_flag,cc] += 1.0/float(2*Np)
        
        
#        for gg in range(0,Ng):
#            counter_flag = Na*Nruns*gg+rr 
#            Gene_eff_nonlinear[counter_flag] = UUall[0,gg]/max_flag
#            Gene_eff_nonlinear[counter_flag+Nruns] = UUall[2,gg]/max_flag
#            for cc in range(0,Nc):
#                for pp in range(0,Np):
#                    counter_flag = Na*Nruns*gg +Nruns*alleles[0,pp,gg,cc] +rr
#                    Gene_freq_nonlinear[counter_flag,cc] += 1.0/float(2*Np)
#                    counter_flag = Na*Nruns*gg +Nruns*alleles[1,pp,gg,cc] +rr
#                    Gene_freq_nonlinear[counter_flag,cc] += 1.0/float(2*Np)
        
                    
        for cc in range(0,Nc):
            sum_flag = np.sum(A[:,cc],0)/float(Np)
            Amean[cc] += sum_flag/float(Nruns)
            if (sum_flag > Amax[cc]):
                Amax[cc] = sum_flag
            if (sum_flag < Amin[cc]):
                Amin[cc] = sum_flag
            
            sum_flag = np.sum(S[:,cc],0)/float(Np)
            Smean[cc] += sum_flag/float(Nruns)
            if (sum_flag > Smax[cc]):
                Smax[cc] = sum_flag
            if (sum_flag < Smin[cc]):
                Smin[cc] = sum_flag
                
            sum_flag = np.sum(CK[:,cc],0)/float(Np)
            CKmean[cc] += sum_flag/float(Nruns)
            if (sum_flag > CKmax[cc]):
                CKmax[cc] = sum_flag
            if (sum_flag < CKmin[cc]):
                CKmin[cc] = sum_flag
            
            sum_flag = np.sum(SL[:,cc],0)/float(Np)
            SLmean[cc] += sum_flag/float(Nruns)
            if (sum_flag > SLmax[cc]):
                SLmax[cc] = sum_flag
            if (sum_flag < SLmin[cc]):
                SLmin[cc] = sum_flag
            
            sum_flag = np.sum(I[:,cc],0)/float(Np)
            Imean[cc] += sum_flag/float(Nruns)
        
    for cc in range(0,Nc):
        Amean[cc] = (Amean[cc]-a_min)/(a_max-a_min)
        Amin[cc] = (Amin[cc]-a_min)/(a_max-a_min)
        Amax[cc] = (Amax[cc]-a_min)/(a_max-a_min)
        Smean[cc] = (Smean[cc]-s_min)/(s_max-s_min)
        Smin[cc] = (Smin[cc]-s_min)/(s_max-s_min)
        Smax[cc] = (Smax[cc]-s_min)/(s_max-s_min)
        CKmean[cc] = (CKmean[cc]-ck_min)/(ck_max-ck_min)
        CKmin[cc] = (CKmin[cc]-ck_min)/(ck_max-ck_min)
        CKmax[cc] = (CKmax[cc]-ck_min)/(ck_max-ck_min)
        SLmean[cc] = (SLmean[cc]-sl_min)/(sl_max-sl_min)
        SLmin[cc] = (SLmin[cc]-sl_min)/(sl_max-sl_min)
        SLmax[cc] = (SLmax[cc]-sl_min)/(sl_max-sl_min)
        Imean[cc] = (Imean[cc]-i_min)/(i_max-i_min)
        
    
    train_genome_file = "../Data/Plot_Data/"+model_name+"_Data_"+case_flag+"_Plot.nc"
    #train_genome_file = mymodel.data_folder+"Train_Genomes_"+mymodel.case+"_"+mymodel.acq_function+"_i"+str(ii+1)+".nc"
    save_dataset = nc.Dataset(train_genome_file, 'w', format='NETCDF4')
    save_dataset.description = "Yield Data"
    save_dataset.history     = "Created_"+time.ctime(time.time())
    save_dataset.source      = "Post-processed_data_provided_by_PNNL"
            
    save_dataset.createDimension('Ngt',Nruns*Ng*Na)
    save_dataset.createDimension('Nc',Nc)
    save_dataset.createDimension('Na',Na)
    save_dataset.createDimension('max_nonlinearity',max_nonlinearity)
    save_dataset.createDimension('Nnonlin',Nnonlin)
    save_dataset.createDimension('nonlinearity_choices',nonlinearity_choices)
            
    genomes_nc = save_dataset.createVariable('Gene_freq','f8',('Ngt','Nc'))
    genomes_nc.units = "Gene_freq"
    genomes_nc[:,:] = Gene_freq[:,:]
    del genomes_nc
            
    genomes_nc = save_dataset.createVariable('Gene_eff','f8',('Ngt'))
    genomes_nc.units = "Gene_eff"
    genomes_nc[:] = Gene_eff[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Gene_freq_nonlinear','f8',('max_nonlinearity','Ngt','Nc'))
    genomes_nc.units = "Gene_freq"
    genomes_nc[:,:] = Gene_freq_nonlinear[:,:]
    del genomes_nc
            
    genomes_nc = save_dataset.createVariable('Gene_eff_nonlinear','f8',('max_nonlinearity','Ngt'))
    genomes_nc.units = "Gene_eff"
    genomes_nc[:] = Gene_eff_nonlinear[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('GGnonlinear','f8',('Nnonlin','max_nonlinearity'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = GGnonlinear[:,:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('AAnonlinear','f8',('Nnonlin','Na'))
    genomes_nc.units = "Gen_eff"
    genomes_nc[:,:] = AAnonlinear[:,:]
    del genomes_nc
    
    
    genomes_nc = save_dataset.createVariable('Amean','f8',('Nc'))
    genomes_nc.units = "Auxin"
    genomes_nc[:] = Amean[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Amin','f8',('Nc'))
    genomes_nc.units = "Auxin"
    genomes_nc[:] = Amin[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Amax','f8',('Nc'))
    genomes_nc.units = "Auxin"
    genomes_nc[:] = Amax[:]
    del genomes_nc
    
    
    genomes_nc = save_dataset.createVariable('Smean','f8',('Nc'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:] = Smean[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Smin','f8',('Nc'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:] = Smin[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Smax','f8',('Nc'))
    genomes_nc.units = "Sucrose"
    genomes_nc[:] = Smax[:]
    del genomes_nc
    
    
    genomes_nc = save_dataset.createVariable('CKmean','f8',('Nc'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:] = CKmean[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('CKmin','f8',('Nc'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:] = CKmin[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('CKmax','f8',('Nc'))
    genomes_nc.units = "Cytokinin"
    genomes_nc[:] = CKmax[:]
    del genomes_nc
    
    
    genomes_nc = save_dataset.createVariable('SLmean','f8',('Nc'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:] = SLmean[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('SLmin','f8',('Nc'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:] = SLmin[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('SLmax','f8',('Nc'))
    genomes_nc.units = "Strigolactone"
    genomes_nc[:] = SLmax[:]
    del genomes_nc
    
    genomes_nc = save_dataset.createVariable('Imean','f8',('Nc'))
    genomes_nc.units = "signal_integrator"
    genomes_nc[:] = Imean[:]
    del genomes_nc
    
    
    
    save_dataset.close()
    
    
    return



