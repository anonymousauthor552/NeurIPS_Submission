#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This is the main python file for running genotype-to-phenotype (G2P) simulations
under the G2PNet framework. To run it, simply run 
    python ./G2P_Model.py case
where case is the name of the particular setup you want to run. To view the 
available cases and their details see file "G2P_Model_Cases.py". To create a 
new case, add the case with its name and parameters to the same file. 

In general, a G2P simulation follows  the steps below:
 - Step 0: Define an appropriate object and load the details of the case specified
by the user. The case will dictate the equations to be used, the number of different
cases (Nruns), each with different parameters in the evolution equations and with a 
total population of Np individual plants per case. 

 - Step 1: Generate the starting germplasm (initial plant population) for each
one of the total (Nruns) cases.

 - Step 2: Use the starting germplasm to train a G2PNet, one for each one of the 
 Nruns cases. Details about the G2PNet architecture and hyperparameters are set
 by the specified case parameters in "G2P_Model_Cases.py". File "G2PNet_Train.py"
 is called for each run separately and creates a batch file that is submitted as 
 an independent process. The batch file calls G2PNet.py and the architecture of the
 model is in G2PNet_Architecture.py. 
 
  - Step 3: Breeds optimal population for the reference model, the mean model 
  and the G2PNet model. For details regarding breeding see file "G2P_Breeding.py".
  
  - Step 4: Gather data needed to plot results and save them. For details regarding
  gathering the data, see file "_Plotting_Data.py"

@author: Alexis Charalampopoulos <alexcharalamp@gmail.com>
"""

import sys # Imported to read input from command line.
import os # Imported to check if particular files exists during the execution of the code. 
import time # Imported for the sleep function. 

from G2P_Model_Cases import Define_G2P_Model
from G2P_Model_Class import g2p_model

def g2p_runs(user_input):  
    
    #--------------------------------------------------------------------------
    #----------- Step 0: Define an object for the runs ------------------------
    config = {} # Initialize an object for the simulation.
    # Via the user input, find the extra parameters of the flow from "Test_Cases.py"
    config = Define_G2P_Model(config,user_input) 
    mymodel = g2p_model(config)
    
    
    #--------------------------------------------------------------------------
    #---------------- Step 1: Generate Germplasm for all cases ----------------
    mymodel.Germplasm_Generation()
     
     
    
    #--------------------------------------------------------------------------
    #---------------- Step 2: Train G2PNets for each case ---------------------
    #aa = int(0)
    #mymodel.Active_Learning(aa)
    #checker = []
    #for nn in range(mymodel.Nstart,mymodel.Nend):
    #    checker.append(os.path.isfile('check_files/Active_Learning_'+mymodel.case+'_r'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #while (False in checker):
    #    checker = []
    #    for nn in range(mymodel.Nstart,mymodel.Nend):
    #        checker.append(os.path.isfile('check_files/Active_Learning_'+mymodel.case+'_r'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #    time.sleep(30)

    test_architectures = ['FCN','LR','GNN']
    for model in test_architectures:
        # Submit processes for training each neural network.
        # Each process is independent from one another.
        mymodel.architecture = model
        mymodel.G2P_Training(0) # Submit training jobs.
        
        # Because each process is independent, we need to ensure that all of them
        # finish before we proceed. To that end, each process creates an empty .txt
        # file with a particular name when it finishes. The loop below checks that
        # all txt files have been created and thus all training processes have finished.
        checker = []
        for nn in range(mymodel.Nstart,mymodel.Nend):
            for ii in range(0,mymodel.ensemble_size):
                checker.append(os.path.isfile('check_files/G2PNet_Train_'+mymodel.case+'_n'+str(ii)+'_Plant'+str(nn)+'_iter'+str(0)+'.txt' ))
        while (False in checker):
            checker = []
            for nn in range(mymodel.Nstart,mymodel.Nend):
                for ii in range(0,mymodel.ensemble_size):
                    checker.append(os.path.isfile('check_files/G2PNet_Train_'+mymodel.case+'_n'+str(ii)+'_Plant'+str(nn)+'_iter'+str(0)+'.txt' ))
            time.sleep(30)
            
        cmd_flag = "rm check_files/*"
        os.system(cmd_flag)

    # for aa in range(mymodel.cycle_start,mymodel.train_cycles):
    #     mymodel.Active_Learning(aa)
    #     checker = []
    #     for nn in range(mymodel.Nstart,mymodel.Nend):
    #         checker.append(os.path.isfile('check_files/Active_Learning_'+mymodel.case+'_r'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #     while (False in checker):
    #         checker = []
    #         for nn in range(mymodel.Nstart,mymodel.Nend):
    #             checker.append(os.path.isfile('check_files/Active_Learning_'+mymodel.case+'_r'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #         time.sleep(30)
    
    #     # Submit processes for training each neural network.
    #     # Each process is independent from one another.
    #     mymodel.G2P_Training(aa) # Submit training jobs.
        
    #     # Because each process is independent, we need to ensure that all of them
    #     # finish before we proceed. To that end, each process creates an empty .txt
    #     # file with a particular name when it finishes. The loop below checks that
    #     # all txt files have been created and thus all training processes have finished.
    #     checker = []
    #     for nn in range(mymodel.Nstart,mymodel.Nend):
    #         for ii in range(0,mymodel.ensemble_size):
    #             checker.append(os.path.isfile('check_files/G2PNet_Train_'+mymodel.case+'_n'+str(ii)+'_Plant'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #     while (False in checker):
    #         checker = []
    #         for nn in range(mymodel.Nstart,mymodel.Nend):
    #             for ii in range(0,mymodel.ensemble_size):
    #                 checker.append(os.path.isfile('check_files/G2PNet_Train_'+mymodel.case+'_n'+str(ii)+'_Plant'+str(nn)+'_iter'+str(aa)+'.txt' ))
    #         time.sleep(30)

    for model in test_architectures:
        #--------------------------------------------------------------------------
        #---------- Step 3: Breed optimal populations with each method ------------
        # Submit a breeding process for each case. Each process will sequentially
        # repeat breeding for (i) the reference model, (ii) the mean model, and
        # (iii) the trained G2PNet of Step 2.
        mymodel.architecture = model
        mymodel.G2P_Breeding(mymodel.train_cycles-1)

        # Because each process is independent, we need to ensure that all of them
        # finish before we proceed. To that end, each process creates an empty .txt
        # file with a particular name when it finishes. The loop below checks that
        # all txt files have been created and thus all breeding processes have finished.
        #
        checker = []
        for nn in range(mymodel.Nstart,mymodel.Nend):
            checker.append(os.path.isfile('check_files/'+mymodel.case+'_Plant'+str(nn)+'.txt' ))
        while (False in checker):
            checker = []
            for nn in range(mymodel.Nstart,mymodel.Nend):
                checker.append(os.path.isfile('check_files/'+mymodel.case+'_Plant'+str(nn)+'.txt' ))
            time.sleep(30)
        cmd_flag = "rm check_files/*"
        os.system(cmd_flag)


    
    #--------------------------------------------------------------------------
    #------- Step 4: Gather and save plotting data for each case & method -----
    #mymodel.G2P_Plotting_Data()
    #mymodel.G2P_Plotting_Script()
    
    
    
    #--------------------------------------------------------------------------
    #------------------------ Step 5: Clean intermediate ----------------------
    cmd_flag = "rm shell_files/*"
    os.system(cmd_flag)
    cmd_flag = "rm check_files/*"
    os.system(cmd_flag)
    cmd_flag = "rm debug_files/*"
    os.system(cmd_flag)
    cmd_flag = "rm myjob.*"
    os.system(cmd_flag)
    
    
    return


if __name__ == "__main__":
    
    user_input = [] # Initialize a list for user input. 
    user_input.append(sys.argv[0]) # Empty argument. 
    user_input.append(sys.argv[1]) # Test-case you want to run. See file "G2P_Model_Cases.py" 
    user_input.append(sys.argv[2]) # Can be sbatch or shell
    
    g2p_runs(user_input) # Call the simulation process with the user input. 
    
    exit()